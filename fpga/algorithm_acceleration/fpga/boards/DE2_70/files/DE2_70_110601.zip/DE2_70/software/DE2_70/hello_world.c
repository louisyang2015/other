/*
 * "Hello World" example.
 *
 * This example prints 'Hello from Nios II' to the STDOUT stream. It runs on
 * the Nios II 'standard', 'full_featured', 'fast', and 'low_cost' example
 * designs. It runs with or without the MicroC/OS-II RTOS and requires a STDOUT
 * device in your system's hardware.
 * The memory footprint of this hosted application is ~69 kbytes by default
 * using the standard reference design.
 *
 * For a reduced footprint version of this template, and an explanation of how
 * to reduce the memory footprint for a given application, see the
 * "small_hello_world" template.
 *
 */

#include "io.h"
#include "system.h"
#include "sys/alt_irq.h"

#include <stdio.h>

static void timer_interrupt(void* context);

typedef struct TimeValue {
	int seconds;
	int seconds_10th;
	int seconds_100th;
} TimeValue;

static void timer_interrupt(void* context)
{
    volatile TimeValue* time_val = (volatile TimeValue*) context;

    time_val->seconds_100th = time_val->seconds_100th + 1;
    if(time_val->seconds_100th >= 10)
    {
        time_val->seconds_100th = 0;
        time_val->seconds_10th = time_val->seconds_10th + 1;
    }
    if(time_val->seconds_10th >= 10)
    {
        time_val->seconds_10th = 0;
        time_val->seconds = time_val->seconds + 1;
    }
    if(time_val->seconds >= 16) time_val->seconds = 0;

    IOWR(HEXDISPLAY_0_BASE, 0, time_val->seconds_10th);
    IOWR(HEXDISPLAY_0_BASE, 1, time_val->seconds);

    // The timer overflow value is 2^20 = 1,048,576
    IOWR(TIMER_0_BASE, 0, 48576); //writes 1,048,576 - one million
}


int main()
{
	TimeValue time_val;
    int switch_in;

    time_val.seconds = 0;
    time_val.seconds_10th = 0;
    time_val.seconds_100th = 0;

    // interrupt registration
    void* contex_ptr = (void*) &time_val;
    alt_ic_isr_register(TIMER_0_IRQ_INTERRUPT_CONTROLLER_ID,
            TIMER_0_IRQ, timer_interrupt, contex_ptr, 0x0);

	// HEX display initialization:
	int i = 0;
	for(i = 0; i < 8; i++) IOWR(HEXDISPLAY_0_BASE, i, i);

	printf("Program is starting ...\n");

	while (1)
    {
        switch_in = IORD(SWITCHES_0_BASE, 0);
        if(switch_in & 0x01)
        	IOWR(TIMER_0_BASE, 1, 1); // set timer run flag to 1
        else
        {
        	IOWR(TIMER_0_BASE, 1, 0); // set timer run flag to 0
            time_val.seconds = 0;
            time_val.seconds_10th = 0;
            time_val.seconds_100th = 0;
        }
    }

	return 0;
}
