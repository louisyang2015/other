﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AEC_PC3
{
    class TestResult
    {
        public bool success;
        public string message;

        public TestResult()
        {
            success = false;
            message = "";
        }

        public TestResult(bool success_val, string message_val)
        {
            success = success_val;
            message = message_val;
        }
    }
}
