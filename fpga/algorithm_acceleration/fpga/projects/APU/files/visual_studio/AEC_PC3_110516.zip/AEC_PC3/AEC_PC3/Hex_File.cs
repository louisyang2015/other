﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.IO;

namespace AEC_PC3
{
    /// <summary>
    /// Currently this class only takes in an int[] array and produce 
    /// a text file in "hex" format. This class does not read a text file
    /// in "hex" format and produce an int[] array.
    /// </summary>
    class Hex_File
    {
        int[] data;

        /// <summary>
        /// It's assumed that the "data" length is divisible by 8
        /// </summary>
        public Hex_File(int[] data)
        {
            this.data = data;
        }

        /// <summary>
        /// If the "data" length is not divisble by 8, the function will
        /// return false.
        /// </summary>
        public bool write_to(string file_name)
        {
            if (data.Length % 8 != 0) return false;

            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < data.Length; i = i + 8)
            {
                sb.Append(":20"); //start of a line

                int sum = 32; //for checksum of this line; "20hex" = 32 decimal
                byte[] four_bytes = {0, 0, 0, 0}; //for checksum computation

                //address:
                byte[] address = BitConverter.GetBytes(i);
                sb.Append(address[1].ToString("X2"));
                sb.Append(address[0].ToString("X2"));

                four_bytes[0] = address[1]; 
                sum += BitConverter.ToInt32(four_bytes, 0); 
                four_bytes[0] = address[0];
                sum += BitConverter.ToInt32(four_bytes, 0);

                //record type: 00 = data record
                sb.Append("00");

                //data values:
                for (int j = 0; j < 8; j++)
                {
                    byte[] value = BitConverter.GetBytes(data[i + j]);
                    sb.Append(value[3].ToString("X2")); //value[3] is the MSB
                    sb.Append(value[2].ToString("X2"));
                    sb.Append(value[1].ToString("X2"));
                    sb.Append(value[0].ToString("X2"));

                    four_bytes[0] = value[3];
                    sum += BitConverter.ToInt32(four_bytes, 0);
                    four_bytes[0] = value[2];
                    sum += BitConverter.ToInt32(four_bytes, 0);
                    four_bytes[0] = value[1];
                    sum += BitConverter.ToInt32(four_bytes, 0);
                    four_bytes[0] = value[0];
                    sum += BitConverter.ToInt32(four_bytes, 0);
                }

                //checksum:
                sum = -1 * sum;
                byte[] checksum = BitConverter.GetBytes(sum);
                sb.Append(checksum[0].ToString("X2"));

                sb.Append("\r\n");
            }
            sb.Append(":00000001FF \r\n"); //end of file

            File.WriteAllText(file_name, sb.ToString());

            return true;
        }

        /// <summary>
        /// In this variant, the data[] array is meant for storage in 64-bit
        /// memory. {data[0], data[1]} is stored as a single word, with data[0]
        /// being the most significant word. The only real difference from "write_to"
        /// is that the address goes up half as fast.
        /// If the "data" length is not divisble by 8, the function will
        /// return false.
        /// </summary>
        public bool write_to64(string file_name)
        {
            if (data.Length % 8 != 0) return false;

            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < data.Length; i = i + 8)
            {
                sb.Append(":20"); //start of a line

                int sum = 32; //for checksum of this line; "20hex" = 32 decimal
                byte[] four_bytes = { 0, 0, 0, 0 }; //for checksum computation

                //address:
                byte[] address = BitConverter.GetBytes(i / 2);
                sb.Append(address[1].ToString("X2"));
                sb.Append(address[0].ToString("X2"));

                four_bytes[0] = address[1];
                sum += BitConverter.ToInt32(four_bytes, 0);
                four_bytes[0] = address[0];
                sum += BitConverter.ToInt32(four_bytes, 0);

                //record type: 00 = data record
                sb.Append("00");

                //data values:
                for (int j = 0; j < 8; j++)
                {
                    byte[] value = BitConverter.GetBytes(data[i + j]);
                    sb.Append(value[3].ToString("X2")); //value[3] is the MSB
                    sb.Append(value[2].ToString("X2"));
                    sb.Append(value[1].ToString("X2"));
                    sb.Append(value[0].ToString("X2"));

                    four_bytes[0] = value[3];
                    sum += BitConverter.ToInt32(four_bytes, 0);
                    four_bytes[0] = value[2];
                    sum += BitConverter.ToInt32(four_bytes, 0);
                    four_bytes[0] = value[1];
                    sum += BitConverter.ToInt32(four_bytes, 0);
                    four_bytes[0] = value[0];
                    sum += BitConverter.ToInt32(four_bytes, 0);
                }

                //checksum:
                sum = -1 * sum;
                byte[] checksum = BitConverter.GetBytes(sum);
                sb.Append(checksum[0].ToString("X2"));

                sb.Append("\r\n");
            }
            sb.Append(":00000001FF \r\n"); //end of file

            File.WriteAllText(file_name, sb.ToString());

            return true;
        }
    }
}
