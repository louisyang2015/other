﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.IO;

namespace AEC_PC3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private MyRS232 serial_port;
        private int[] file_sector_addr = new int[] { 8, 39, 70, 101 };
        // private int[] file_length = new int[] { 512000, 512000, 512000, 425166 };

        private void Form1_Load(object sender, EventArgs e)
        {
            serial_port = new MyRS232("COM1");
        }

        private void Browse_button_Click(object sender, EventArgs e)
        {
            if (openFileDialog1.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                FileName_textBox.Text = openFileDialog1.FileName;
                FileInfo f = new FileInfo(openFileDialog1.FileName);
                FileLength_label.Text = "File size: " + f.Length.ToString("N0") + " bytes";
            }
        }

        private void Download_button_Click(object sender, EventArgs e)
        {
            if (FileNumber_comboBox.SelectedIndex < 0 || FileNumber_comboBox.SelectedIndex > 3) return;

            int sector_number = file_sector_addr[FileNumber_comboBox.SelectedIndex];
            this.Cursor = Cursors.WaitCursor;

            serial_port.write_integer(100); //enter flash_test()

            Flash my_flash = new Flash(serial_port);

            TestResult test_result = my_flash.write_file(FileName_textBox.Text, sector_number);

            if (test_result.success) Output_textBox.Text += "File download successful \r\n";
            else Output_textBox.Text += "File download failed \r\n";

            Output_textBox.Text += test_result.message + "\r\n";

            serial_port.write_integer(0); //leave flash_test()

            this.Cursor = Cursors.Default;
        }

        private void Verify_button_Click(object sender, EventArgs e)
        {
            if (FileNumber_comboBox.SelectedIndex < 0 || FileNumber_comboBox.SelectedIndex > 3) return;

            int sector_number = file_sector_addr[FileNumber_comboBox.SelectedIndex];
            this.Cursor = Cursors.WaitCursor;

            serial_port.write_integer(100); //enter flash_test()

            Flash my_flash = new Flash(serial_port);
            TestResult test_result = my_flash.verify_file(FileName_textBox.Text, sector_number);
            Output_textBox.Text += test_result.message + "\r\n";

            serial_port.write_integer(0); //leave flash_test()

            this.Cursor = Cursors.Default;
        }

        private void AEC_Flash_menuItem_Click(object sender, EventArgs e)
        {
            this.Cursor = Cursors.WaitCursor;
            AEC my_aec = new AEC(serial_port);
            TestResult test_result = my_aec.Flash_Test(file_sector_addr[0], file_sector_addr[1],
                        file_sector_addr[2], 1750);
            if (test_result.success) Output_textBox.Text += "AEC Flash Test successful \r\n";
            else Output_textBox.Text += "AEC Flash Test failed \r\n";

            Output_textBox.Text += test_result.message + "\r\n\r\n";
            this.Cursor = Cursors.Default;
        }

    }
}
