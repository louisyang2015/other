﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.IO.Ports;

namespace AEC_PC3
{
    class MyRS232
    {
        public SerialPort serial_port;

        private void init(string portName, int baudRate, Parity parity, int dataBits, StopBits stopBits)
        {
            serial_port = new SerialPort(portName, baudRate, parity, dataBits, stopBits);
            serial_port.Open();
        }
        public MyRS232()
        {
            init("COM1", 115200, Parity.None, 8, StopBits.One);
        }
        public MyRS232(string port_name)
        {
            init(port_name, 115200, Parity.None, 8, StopBits.One);
        }

        
        ~MyRS232()
        {
            if(serial_port != null) serial_port.Close();
        }
        public void Close()
        {
            if (serial_port != null) serial_port.Close();
        }
        public void Open()
        {
            if (serial_port != null) serial_port.Open();
        }

        /// <summary>
        /// Wait for "n" number of bytes; the time_out is in ms
        /// </summary>
        public bool wait_for_bytes(int n, long time_out_in_ms)
        {
            //try 10 times read first
            int i = 10;
            while ((serial_port.BytesToRead < n) && (i > 0))
            {
                i--;
            }

            //now try to wait for time out
            if (serial_port.BytesToRead < n)
            {
                long now1 = DateTime.Now.Ticks;
                long now2 = now1;
                long time_out_in_ticks = time_out_in_ms * 10L * 1000L; //one tick = 100ns

                while ((serial_port.BytesToRead < n) && (now2 - now1 < time_out_in_ticks))
                {
                    System.Threading.Thread.Sleep(100); //just to unblock this thread
                    now2 = DateTime.Now.Ticks;
                }
            }

            if (serial_port.BytesToRead < n) return false;

            return true; //no reply received
        }

        //wait for one byte and check for its expected value
        public bool wait_for_one_byte(byte expected_value, int time_out_in_ms)
        {
            bool result = wait_for_bytes(1, time_out_in_ms);
            if (result)
            {
                //check the byte
                if (serial_port.BytesToRead == 1)
                {
                    int val = serial_port.ReadByte();
                    int expected_int = expected_value;
                    if (val != expected_int) result = false;
                }
                else
                    result = false;
            }
            return result;
        }


        public void write_integer(int val)
        {
            byte[] bytes = BitConverter.GetBytes(val);
            serial_port.Write(bytes, 0, 4);
        }
        public bool read_integer(out int val)
        {
            if (serial_port.BytesToRead >= 4)
            {
                byte[] bytes = new byte[4];
                serial_port.Read(bytes, 0, 4);
                val = BitConverter.ToInt32(bytes, 0);
                return true;
            }

            //else:
            val = 0;
            return false;
        }

        /// <summary>
        /// Wait for 4 bytes, check to see if it's the expected value. Returns
        /// "true" if the expected value is found. Returns "false" if there's no
        /// reply, or the reply is not the "expected_value"
        /// </summary>
        public bool wait_for_reply(int expected_value, int time_out_ms)
        {
            bool result = wait_for_bytes(4, time_out_ms);
            if (result == false) return false;
            int reply;
            result = read_integer(out reply);
            if (result == false) return false;
            if (reply != expected_value) return false;
            return true;
        }
    }
}
