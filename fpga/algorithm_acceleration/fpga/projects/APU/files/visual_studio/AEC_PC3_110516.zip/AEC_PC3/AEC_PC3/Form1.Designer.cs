﻿namespace AEC_PC3
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.Output_tabPage = new System.Windows.Forms.TabPage();
            this.Output_textBox = new System.Windows.Forms.TextBox();
            this.Flash_tabPage = new System.Windows.Forms.TabPage();
            this.label3 = new System.Windows.Forms.Label();
            this.FileLength_label = new System.Windows.Forms.Label();
            this.Verify_button = new System.Windows.Forms.Button();
            this.Download_button = new System.Windows.Forms.Button();
            this.Browse_button = new System.Windows.Forms.Button();
            this.FileName_textBox = new System.Windows.Forms.TextBox();
            this.FileNumber_comboBox = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.commandsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.AEC_Flash_menuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.tabControl1.SuspendLayout();
            this.Output_tabPage.SuspendLayout();
            this.Flash_tabPage.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.Output_tabPage);
            this.tabControl1.Controls.Add(this.Flash_tabPage);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabControl1.Location = new System.Drawing.Point(0, 33);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(594, 365);
            this.tabControl1.TabIndex = 0;
            // 
            // Output_tabPage
            // 
            this.Output_tabPage.Controls.Add(this.Output_textBox);
            this.Output_tabPage.Location = new System.Drawing.Point(4, 34);
            this.Output_tabPage.Name = "Output_tabPage";
            this.Output_tabPage.Padding = new System.Windows.Forms.Padding(3);
            this.Output_tabPage.Size = new System.Drawing.Size(586, 327);
            this.Output_tabPage.TabIndex = 0;
            this.Output_tabPage.Text = "Output";
            this.Output_tabPage.UseVisualStyleBackColor = true;
            // 
            // Output_textBox
            // 
            this.Output_textBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Output_textBox.Location = new System.Drawing.Point(3, 3);
            this.Output_textBox.Multiline = true;
            this.Output_textBox.Name = "Output_textBox";
            this.Output_textBox.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.Output_textBox.Size = new System.Drawing.Size(580, 321);
            this.Output_textBox.TabIndex = 0;
            // 
            // Flash_tabPage
            // 
            this.Flash_tabPage.Controls.Add(this.label3);
            this.Flash_tabPage.Controls.Add(this.FileLength_label);
            this.Flash_tabPage.Controls.Add(this.Verify_button);
            this.Flash_tabPage.Controls.Add(this.Download_button);
            this.Flash_tabPage.Controls.Add(this.Browse_button);
            this.Flash_tabPage.Controls.Add(this.FileName_textBox);
            this.Flash_tabPage.Controls.Add(this.FileNumber_comboBox);
            this.Flash_tabPage.Controls.Add(this.label2);
            this.Flash_tabPage.Controls.Add(this.label1);
            this.Flash_tabPage.Location = new System.Drawing.Point(4, 34);
            this.Flash_tabPage.Name = "Flash_tabPage";
            this.Flash_tabPage.Padding = new System.Windows.Forms.Padding(3);
            this.Flash_tabPage.Size = new System.Drawing.Size(586, 327);
            this.Flash_tabPage.TabIndex = 1;
            this.Flash_tabPage.Text = "Flash";
            this.Flash_tabPage.UseVisualStyleBackColor = true;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(31, 212);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(280, 25);
            this.label3.TabIndex = 8;
            this.label3.Text = "File #: 1=xn; 2=dn; 3=fpga_out";
            // 
            // FileLength_label
            // 
            this.FileLength_label.AutoSize = true;
            this.FileLength_label.Location = new System.Drawing.Point(420, 138);
            this.FileLength_label.Name = "FileLength_label";
            this.FileLength_label.Size = new System.Drawing.Size(108, 25);
            this.FileLength_label.TabIndex = 7;
            this.FileLength_label.Text = "File Length";
            // 
            // Verify_button
            // 
            this.Verify_button.Location = new System.Drawing.Point(223, 130);
            this.Verify_button.Name = "Verify_button";
            this.Verify_button.Size = new System.Drawing.Size(161, 41);
            this.Verify_button.TabIndex = 6;
            this.Verify_button.Text = "Verify File";
            this.Verify_button.UseVisualStyleBackColor = true;
            this.Verify_button.Click += new System.EventHandler(this.Verify_button_Click);
            // 
            // Download_button
            // 
            this.Download_button.Location = new System.Drawing.Point(14, 130);
            this.Download_button.Name = "Download_button";
            this.Download_button.Size = new System.Drawing.Size(161, 41);
            this.Download_button.TabIndex = 5;
            this.Download_button.Text = "Download File";
            this.Download_button.UseVisualStyleBackColor = true;
            this.Download_button.Click += new System.EventHandler(this.Download_button_Click);
            // 
            // Browse_button
            // 
            this.Browse_button.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Browse_button.Location = new System.Drawing.Point(444, 63);
            this.Browse_button.Name = "Browse_button";
            this.Browse_button.Size = new System.Drawing.Size(116, 39);
            this.Browse_button.TabIndex = 4;
            this.Browse_button.Text = "Browse";
            this.Browse_button.UseVisualStyleBackColor = true;
            this.Browse_button.Click += new System.EventHandler(this.Browse_button_Click);
            // 
            // FileName_textBox
            // 
            this.FileName_textBox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.FileName_textBox.Location = new System.Drawing.Point(98, 67);
            this.FileName_textBox.Name = "FileName_textBox";
            this.FileName_textBox.Size = new System.Drawing.Size(332, 30);
            this.FileName_textBox.TabIndex = 3;
            // 
            // FileNumber_comboBox
            // 
            this.FileNumber_comboBox.FormattingEnabled = true;
            this.FileNumber_comboBox.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4"});
            this.FileNumber_comboBox.Location = new System.Drawing.Point(98, 17);
            this.FileNumber_comboBox.Name = "FileNumber_comboBox";
            this.FileNumber_comboBox.Size = new System.Drawing.Size(121, 33);
            this.FileNumber_comboBox.TabIndex = 2;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(11, 70);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(81, 25);
            this.label2.TabIndex = 1;
            this.label2.Text = "Source:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(9, 25);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(65, 25);
            this.label1.TabIndex = 0;
            this.label1.Text = "File #:";
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.commandsToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(594, 33);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // commandsToolStripMenuItem
            // 
            this.commandsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.AEC_Flash_menuItem});
            this.commandsToolStripMenuItem.Name = "commandsToolStripMenuItem";
            this.commandsToolStripMenuItem.Size = new System.Drawing.Size(116, 29);
            this.commandsToolStripMenuItem.Text = "&Commands";
            // 
            // AEC_Flash_menuItem
            // 
            this.AEC_Flash_menuItem.Name = "AEC_Flash_menuItem";
            this.AEC_Flash_menuItem.Size = new System.Drawing.Size(205, 30);
            this.AEC_Flash_menuItem.Text = "&AEC from Flash";
            this.AEC_Flash_menuItem.Click += new System.EventHandler(this.AEC_Flash_menuItem_Click);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.Filter = "Bin Files|*.bin|All Files|*.*";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(594, 398);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "AEC PC Side (32kHz version)";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.tabControl1.ResumeLayout(false);
            this.Output_tabPage.ResumeLayout(false);
            this.Output_tabPage.PerformLayout();
            this.Flash_tabPage.ResumeLayout(false);
            this.Flash_tabPage.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage Output_tabPage;
        private System.Windows.Forms.TextBox Output_textBox;
        private System.Windows.Forms.TabPage Flash_tabPage;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem commandsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem AEC_Flash_menuItem;
        private System.Windows.Forms.Button Verify_button;
        private System.Windows.Forms.Button Download_button;
        private System.Windows.Forms.Button Browse_button;
        private System.Windows.Forms.TextBox FileName_textBox;
        private System.Windows.Forms.ComboBox FileNumber_comboBox;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label FileLength_label;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
    }
}

