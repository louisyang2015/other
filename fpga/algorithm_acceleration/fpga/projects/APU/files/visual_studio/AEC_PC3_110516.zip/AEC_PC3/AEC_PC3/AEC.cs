﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.IO.Ports;

namespace AEC_PC3
{
    class AEC
    {
        private MyRS232 serial_port;

        public AEC(MyRS232 rs232_test_port)
        {
            serial_port = rs232_test_port;
        }

        public TestResult Flash_Test(int xn_sector_addr, int dn_sector_addr, int out_sector_addr, int num_frames)
        {
            serial_port.write_integer(1024);        // the command code
            serial_port.write_integer((xn_sector_addr - 7) * 0x8000 / 2); // sector 8 is xn address; 32 bit address is 1/2 16 bit address
            serial_port.write_integer((dn_sector_addr - 7) * 0x8000 / 2); // sector 20 is dn address
            serial_port.write_integer((out_sector_addr - 7) * 0x8000 / 2); // sector 30 is expected output address
            // serial_port.write_integer(512000 / 2);     // number of words to read
            serial_port.write_integer(256 * num_frames);

            long ticks = DateTime.Now.Ticks;
            
            bool result = serial_port.wait_for_bytes(4 * 4, 1000 * 1000); //wait for 4*4 bytes report,

            //get the running time
            ticks = DateTime.Now.Ticks - ticks;
            float seconds = ticks * (float)(100*Math.Pow(10, -9));
            string message = "Run time: " + seconds.ToString("N0") + " seconds\r\n";

            if (result)
            {
                int max_run_time, num_diff, max_diff, min_diff;
                serial_port.read_integer(out max_run_time);
                serial_port.read_integer(out num_diff);
                serial_port.read_integer(out max_diff);
                serial_port.read_integer(out min_diff);
                //serial_port.read_integer(out fifo_max);
                //serial_port.read_integer(out fifo_min);
                //serial_port.read_integer(out fifo_too_short_times);
                                
                message += "Maximum run time = " + max_run_time.ToString("N0") + " cycles\r\n";
                message += "Number of differences = " + num_diff.ToString("N0") + "\r\n";
                message += "Maximum difference = " + max_diff + "\r\n";
                message += "Minimum difference = " + min_diff + "\r\n";
                // message += "FIFO maximum size = " + fifo_max + "\r\n";
                // message += "FIFO minimum size = " + fifo_min + "\r\n";
                // message += "FIFO too short times = " + fifo_too_short_times;
                
                return new TestResult(true, message);
            }

            //else: 
            message += "No reply received in time";
            return new TestResult(false, message);
        }
    }
}
