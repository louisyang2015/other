﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.IO;
using System.IO.Ports;

namespace AEC_PC3
{
    class Flash
    {
        private MyRS232 serial_port;

        public Flash(MyRS232 rs232_test_port)
        {
            serial_port = rs232_test_port;
        }

        //command 1 - read flash memory 
        public byte[] read(int address, int size)
        {
            //limit size to 127 - the depth of the RS-232 transmit FIFO is 128 words
            if (size > 127) size = 127;

            serial_port.write_integer(1); //command byte = 1
            serial_port.write_integer(address);
            serial_port.write_integer(size);

            bool result = serial_port.wait_for_bytes(size * 4, 500);

            if (result == false) return null;

            //get all bytes sent back
            int bytes_to_read = serial_port.serial_port.BytesToRead;
            byte[] reply = new byte[bytes_to_read];
            serial_port.serial_port.Read(reply, 0, bytes_to_read);
            return reply;
        }

        public string read_str(int address, int size)
        {

            byte[] reply = read(address, size);

            //format the bytes read
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < reply.Length; i++)
            {
                sb.Append(reply[i].ToString("X") + " ");
            }
            return sb.ToString();
        }

        //command 2 - flash chip erase
        public bool chip_erase()
        {
            serial_port.write_integer(2);
            return serial_port.wait_for_reply(1, 10000);
        }

        //command 3 - flash chip buffer write
        public bool buffer_write(int sector_address, int start_address,
            short[] content)
        {
            if (content.Length != 16) return false;

            // the command code is "3", sector address, start address, 
            // then 16x "short" values
            serial_port.write_integer(3);
            serial_port.write_integer(sector_address);
            serial_port.write_integer(start_address);

            for (int i = 0; i < content.Length; i++)
            {
                byte[] content_bytes = BitConverter.GetBytes(content[i]);
                serial_port.serial_port.Write(content_bytes, 0, 2);
            }

            //-----------------Wait for reply ------------------------            
            return serial_port.wait_for_reply(1, 500);
        }

        //command 3 variation that takes in a byte[] array
        public bool buffer_write(int sector_address, int start_address,
            byte[] content)
        {
            if (content.Length != 32) return false;

            // the command code is "3", sector address, start address, 
            // then 16x "short" values
            serial_port.write_integer(3);
            serial_port.write_integer(sector_address);
            serial_port.write_integer(start_address);

            serial_port.serial_port.Write(content, 0, 32);

            //-----------------Wait for reply ------------------------
            return serial_port.wait_for_reply(1, 500);
        }

        //command 4 - flash memory sector erase
        public bool sector_erase(int sector_address)
        {
            //the command is "4", sector address
            serial_port.write_integer(4);
            serial_port.write_integer(sector_address);

            //-----------------Wait for reply ------------------------
            return serial_port.wait_for_reply(1, 500);
        }


        public TestResult write_file(string file_name, int start_sector_number)
        {
            FileStream file = new FileStream(file_name, FileMode.Open);
            BinaryReader file_br = new BinaryReader(file);

            byte[] buffer = file_br.ReadBytes((int)(file_br.BaseStream.Length));

            file.Close();

            string message = "";

            int i = 0; // i = a location in the file being written
            int sector_number = start_sector_number;
            int sector_address = (start_sector_number - 7) * 8 * 4096;
            int word_address = (start_sector_number - 7) * 0x8000;
            //*0x8000 to get the 16 bit word address, 
            //don't divide by 2 - when doing writes, the address used
            //is the 16 bit word address
            int new_sector_word_address = (start_sector_number - 7 + 1) * 0x8000;
            //this is the starting word address of the next sector. When "word_address"
            //reach this "new_sector_word_address", sector_address needs to be
            //updated and the new sector should be erased prior to writes

            bool new_sector = true; //flag that becomes true if we arrive in a new sector

            while (i < buffer.Length)
            {
                //erase the sector if needed
                if (new_sector)
                {
                    bool erase_result = sector_erase(sector_address);
                    if (erase_result == false) erase_result = sector_erase(sector_address);
                    if (erase_result == false)
                    {
                        message = "Failed while erasing sector: " + sector_address;
                        return new TestResult(false, message);
                    }
                    new_sector = false;
                }

                //extract the bytes to be written
                //at this point, we are on the "i-th" byte of "buffer"
                byte[] content = new byte[32];
                for (int j = 0; j < content.Length; j++)
                {
                    if (i < buffer.Length)
                    {
                        content[j] = buffer[i];
                        i++;
                    }
                    else content[j] = 0;
                }

                //calling the "flash_buffer_write_command"
                bool write_result = buffer_write(sector_address, word_address, content);
                if (write_result == false)
                    write_result = buffer_write(sector_address, word_address, content);
                if (write_result == false)
                {
                    message = "Failed while writing byte # " + (i - 32);
                    return new TestResult(false, message);
                }

                //preparing addresses for the next loop iteration
                word_address += 16;

                //additional prepartion in the case of a new sector
                if (word_address >= new_sector_word_address)
                {
                    //status update for the user
                    //Output_textbox.Text = "Finished writing to sector # " + sector_number;
                    //System.Threading.Thread.Sleep(50);

                    sector_address = sector_address + 8 * 4096;
                    word_address = new_sector_word_address;
                    sector_number++;
                    new_sector_word_address = (sector_number - 7 + 1) * 0x8000;
                    new_sector = true;
                }
            }

            //upon reaching this point, a successful write
            message = "Write completed \r\n";
            message += "Last byte on sector # " + sector_number + "\r\n";
            message += "Length of file = " + buffer.Length + " bytes";
            return new TestResult(true, message);
        }

        public TestResult verify_file(string file_name, int start_sector_number)
        {
            FileStream file = new FileStream(file_name, FileMode.Open);
            BinaryReader file_br = new BinaryReader(file);

            byte[] buffer = file_br.ReadBytes((int)(file_br.BaseStream.Length));

            file.Close();

            int i = 0; // i = a location in the file being verified
            //this is reading from the Flash memory, so it's 32 bit addressing
            //The actual address is half of the real address that appears on the bus
            int word_address = (start_sector_number - 7) * 0x8000 / 2;            

            while (i < buffer.Length)
            {
                byte[] from_flash = read(word_address, 64);
                if (from_flash == null)
                {
                    return new TestResult(false, "Failed to read from file at byte #" + i.ToString("N0"));
                }

                int j = 0;
                while ((i + j < buffer.Length) && (j < 64 * 4))
                {
                    if (buffer[i + j] != from_flash[j])
                    {
                        string failed_byte = (i+j).ToString("N0");
                        string message = "File comparison failed at byte #" + failed_byte;
                        return new TestResult(false, message);
                    }
                    j++;
                }
                i = i + 64 * 4;
                word_address = word_address + 64;
            }

            return new TestResult(true, "File read back from Flash and verified");
        }

    }
}
