﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.Numerics;


namespace APU_Tester
{
    class CVector
    {        
        public Complex[] c_array;
        
        #region Constructors        
        
        /// <summary>
        /// Creates a vector of the given size and initalize all elements to zero.
        /// </summary>
        public CVector(int size)
        {
            c_array = new Complex[size];
            for (int i = 0; i < c_array.Length; i++)
                c_array[i] = 0;
        }

        /// <summary>
        /// Creates a vector of the given size and initalize all elements as a
        /// sequence, starting at "start_value".
        /// </summary>
        public CVector(int size, int start_value)
        {
            c_array = new Complex[size];
            for (int i = 0; i < c_array.Length; i++)
                c_array[i] = start_value + i;
        }

        /// <summary>
        /// Create a wrapper for a Complex[] array. The newly created CVector object
        /// just wraps around the c_array. No copy of the c_array is made.
        /// </summary>
        public CVector(Complex[] c_array)
        {
            this.c_array = c_array;
        }

        /// <summary>
        /// Create a vector from a double[] d_array. The values in d_array
        /// copied into the new CVector.
        /// </summary>
        public CVector(double[] d_array)
        {
            c_array = new Complex[d_array.Length];
            for (int i = 0; i < d_array.Length; i++)
                c_array[i] = d_array[i];
        }

        /// <summary>
        /// Create a new CVector identical to cv2. The data in the cv2 
        /// vector is copied into the new vector.
        /// </summary>
        public CVector(CVector cv2)
        {
            c_array = new Complex[cv2.Length];            
            for (int i = 0; i < c_array.Length; i++)   
                   c_array[i] = new Complex(cv2[i].Real, cv2[i].Imaginary);
        }

        /// <summary>
        /// Create a new CVector from two CVector objects.
        /// </summary>
        public CVector(CVector cv1, CVector cv2)
        {
            Complex[] c_array1 = cv1.c_array;
            Complex[] c_array2 = cv2.c_array;

            int size = c_array1.Length + c_array2.Length;
            c_array = new Complex[size];
            
            int start = 0;
            for (int i = 0; i < c_array1.Length; i++)
                c_array[start + i] = new Complex(c_array1[i].Real, c_array1[i].Imaginary);

            start = c_array1.Length;
            for(int i = 0; i < c_array2.Length; i++)
                c_array[start + i] = new Complex(c_array2[i].Real, c_array2[i].Imaginary);
        }

        /// <summary>
        /// Create a new DVector from three DVector objects.
        /// </summary>
        public CVector(CVector cv1, CVector cv2, CVector cv3)
        {
            Complex[] c_array1 = cv1.c_array;
            Complex[] c_array2 = cv2.c_array;
            Complex[] c_array3 = cv3.c_array;

            int size = c_array1.Length + c_array2.Length + c_array3.Length;
            c_array = new Complex[size];

            int start = 0;
            for (int i = 0; i < c_array1.Length; i++)
                c_array[start + i] = new Complex(c_array1[i].Real, c_array1[i].Imaginary);

            start = c_array1.Length;
            for (int i = 0; i < c_array2.Length; i++)
                c_array[start + i] = new Complex(c_array2[i].Real, c_array2[i].Imaginary);

            start += c_array2.Length;
            for (int i = 0; i < c_array3.Length; i++)
                c_array[start + i] = new Complex(c_array3[i].Real, c_array3[i].Imaginary); ;
        }
        
        #endregion

        #region Utility Functions        
        /// <summary>
        /// Array Indexer
        /// </summary>
        public Complex this[int i]
        {
            get { return c_array[i]; }
            set { c_array[i] = value; }
        }
        
        /// <summary>
        /// Array Length
        /// </summary>
        public int Length
        {
            get { return c_array.Length; }
        }

        /// <summary>
        /// The magnitude values of CVector
        /// </summary>
        public double[] Magnitude
        {
            get
            {
                double[] result = new double[c_array.Length];
                for (int i = 0; i < result.Length; i++)
                    result[i] = c_array[i].Magnitude;
                return result;
            }
        }

        /// <summary>
        /// The magnitude values of CVector in dB
        /// </summary>
        public double[] Magnitude_dB
        {
            get
            {
                double[] result = new double[c_array.Length];
                for (int i = 0; i < result.Length; i++)
                {
                    if(c_array[i].Magnitude < 1e-9)
                        result[i] = 20d * Math.Log10(1e-9);
                    else
                        result[i] = 20d * Math.Log10(c_array[i].Magnitude);
                }
                return result;
            }
        }

        /// <summary>
        /// The phase values of CVector in radians
        /// </summary>
        public double[] Phase
        {
            get 
            {
                double[] result = new double[c_array.Length];
                for (int i = 0; i < result.Length; i++)
                    result[i] = c_array[i].Phase;
                return result;
            }
        }

        /// <summary>
        /// The phase values of CVector in degrees
        /// </summary>
        public double[] Phase360
        {
            get
            {
                double[] result = new double[c_array.Length];
                for (int i = 0; i < result.Length; i++)
                {
                    result[i] = c_array[i].Phase;
                    result[i] = result[i] / Math.PI * 180;
                }   
                return result;
            }
        }

        /// <summary>
        /// The real values of CVector
        /// </summary>
        public double[] Real
        {
            get
            {
                double[] result = new double[c_array.Length];
                for (int i = 0; i < result.Length; i++)
                    result[i] = c_array[i].Real;
                return result;
            }
        }

        /// <summary>
        /// The imaginary values of CVector
        /// </summary>
        public double[] Imaginary
        {
            get
            {
                double[] result = new double[c_array.Length];
                for (int i = 0; i < result.Length; i++)
                    result[i] = c_array[i].Imaginary;
                return result;
            }
        }
        
        /// <summary>
        /// This produce a column vector format than is suitable 
        /// for pasting into Excel. First column is magnitude, second
        /// column is phase.
        /// </summary>
        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < c_array.Length; i++)
            {
                sb.Append(c_array[i].Magnitude + "\t" + c_array[i].Phase);
                sb.Append("\r\n");
            }
            return sb.ToString();
        }

        /// <summary>
        /// This produce a column vector format than is suitable 
        /// for display. Each term is displayed in the format "a + bj".
        /// </summary>
        public string ToStringRect()
        {
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < c_array.Length; i++)
            {
                sb.Append(c_array[i].Real + " + " + c_array[i].Imaginary + "j");
                sb.Append("\r\n");
            }
            return sb.ToString();
        }

        #endregion 

        #region Element by Element Operations        
        /// <summary>
        /// Element by element + - * /
        /// </summary>
        public static CVector operator +(CVector cv1, CVector cv2)
        {
            Complex[] result = new Complex[cv1.Length];
            for (int i = 0; i < cv1.Length; i++)
                result[i] = cv1[i] + cv2[i];
            return new CVector(result);
        }
        public static CVector operator -(CVector cv1, CVector cv2)
        {
            Complex[] result = new Complex[cv1.Length];
            for (int i = 0; i < cv1.Length; i++)
                result[i] = cv1[i] - cv2[i];
            return new CVector(result);
        }
        public static CVector operator *(CVector cv1, CVector cv2)
        {
            Complex[] result = new Complex[cv1.Length];
            for (int i = 0; i < cv1.Length; i++)
                result[i] = cv1[i] * cv2[i];
            return new CVector(result);
        }
        public static CVector operator /(CVector cv1, CVector cv2)
        {
            Complex[] result = new Complex[cv1.Length];
            for (int i = 0; i < cv1.Length; i++)
                result[i] = cv1[i] / cv2[i];
            return new CVector(result);
        }

        /// <summary>
        /// Multiply or divide by a constant
        /// </summary>
        public static CVector operator *(CVector cv1, double d)
        {
            Complex[] result = new Complex[cv1.Length];
            for (int i = 0; i < cv1.Length; i++)
                result[i] = cv1[i] * d;
            return new CVector(result);
        }
        public static CVector operator *(double d, CVector cv1)
        {
            Complex[] result = new Complex[cv1.Length];
            for (int i = 0; i < cv1.Length; i++)
                result[i] = cv1[i] * d;
            return new CVector(result);
        }
        public static CVector operator *(CVector cv1, Complex c)
        {
            Complex[] result = new Complex[cv1.Length];
            for (int i = 0; i < cv1.Length; i++)
                result[i] = cv1[i] * c;
            return new CVector(result);
        }
        public static CVector operator *(Complex c, CVector cv1)
        {
            Complex[] result = new Complex[cv1.Length];
            for (int i = 0; i < cv1.Length; i++)
                result[i] = cv1[i] * c;
            return new CVector(result);
        }
        public static CVector operator /(CVector cv1, double d)
        {
            Complex[] result = new Complex[cv1.Length];
            for (int i = 0; i < cv1.Length; i++)
                result[i] = cv1[i] / d;
            return new CVector(result);
        }
        public static CVector operator /(CVector cv1, Complex c)
        {
            Complex[] result = new Complex[cv1.Length];
            for (int i = 0; i < cv1.Length; i++)
                result[i] = cv1[i] / c;
            return new CVector(result);
        }
        #endregion

        #region Vector Shifting and Reverse
        /// <summary>
        /// Shift the elements in the vector to the left (index 0) and pad
        /// the right end of the vector with zeros.
        /// </summary>
        public CVector shift_left(int n)
        {
            Complex[] result = new Complex[c_array.Length];

            //copy: d_array[n] to result[0], and so on...
            for (int i = n; i < c_array.Length; i++)
                result[i - n] = new Complex(c_array[i].Real, c_array[i].Imaginary);

            //copy a zero to last "n" items of "result"
            for (int i = result.Length - n; i < result.Length; i++)
                result[i] = 0;

            return new CVector(result);
        }

        /// <summary>
        /// Shift the elements in the vector to the right (last indexed element) 
        /// and pad the left end of the vector with zeros.
        /// </summary>
        public CVector shift_right(int n)
        {
            Complex[] result = new Complex[c_array.Length];

            //copy a zero to first "n" items of "result"
            for (int i = 0; i < n; i++)
                result[i] = 0;

            //copy: d_array[0] to result[n], and so on...
            for (int i = n; i < result.Length; i++)
                result[i] = c_array[i - n];

            return new CVector(result);
        }

        /// <summary>
        /// Reverse the array elements
        /// </summary>
        public CVector reverse()
        {
            Complex[] result = new Complex[c_array.Length];
            for(int i = 0; i < c_array.Length; i++)
                result[c_array.Length-1-i] = c_array[i];
            return new CVector(result);
        }
        #endregion

        #region DFT and FFT
        /// <summary>
        /// Does the slow DFT on "c_array" and returns the result as a "Complex[]". 
        /// </summary>
        public static Complex[] DFT(Complex[] c_array)
        {
            Complex[] result = new Complex[c_array.Length];

            // X[k] = Sum(n=0 --> n=N-1; 
            //          x(n) exp(-j*2pi/N*n*k)

            //The exp(-j*2pi/N*n) array:
            Complex[] twiddle = new Complex[c_array.Length];
            twiddle[0] = 1;
            for (int n = 1; n < c_array.Length; n++)
            {
                double exponent = -2 * Math.PI / c_array.Length * n;
                twiddle[n] = Complex.Exp(new Complex(0, exponent));
            }

            for (int k = 0; k < c_array.Length; k++)
            {
                Complex acc = c_array[0];
                for (int n = 1; n < c_array.Length; n++)
                {
                    // acc = acc + c_array[n] * exp(-j*2pi/N*n*k)
                    // acc = acc + c_array[n] * twiddle[n]^(k)
                    acc = acc + c_array[n] * Complex.Pow(twiddle[n], k);
                }
                result[k] = acc;
            }

            return result;
        }

        /// <summary>
        /// Does the slow DFT and returns the result as a "CVector". 
        /// </summary>
        public CVector DFT()
        {
            Complex[] result = CVector.DFT(c_array);
            return new CVector(result);
        }

        /// <summary>
        /// Return "true" if "value" is a power of 2. In this case, "power"
        /// will be log2(value).
        /// </summary>
        private static bool is_power_of_2(int value, out int power)
        {
            double power_d = Math.Log(value, 2);
            power = Convert.ToInt32(power_d);
            if (power < 1) return false;

            //check "power"
            int acc = 1;
            for (int i = 0; i < power; i++)
                acc = acc * 2;
            if (acc != value) return false;

            return true;
        }

        /// <summary>
        /// Swap elements of "c_array" according to bit-reverse order. This
        /// function assumems that the length of "c_array" is a power of 2.
        /// The "power" is the log2(c_array.Length) value. So if c_array is
        /// 1024 long, then power should be 10.
        /// </summary>
        private static void bit_reverse(Complex[] c_array, int power)
        {
            //make an array of power of 2's, for the bit-reverse case
            //pwr2_array = {2^(power-1), ...., 4, 2, 1}
            int[] pwr2_array = new int[power];
            pwr2_array[power-1] = 1;
            for (int i = power-2; i >= 0; i--)
                pwr2_array[i] = pwr2_array[i + 1] * 2;

            //element 0 and the last element does not need to go
            //through the bit reverse process
            for (int i = 1; i < c_array.Length - 1; i++)
            {
                int r = 0; //r will be the bit-reverse value of i
                int mask = 1; //this will be 0001, then 0010, then 0100
                for (int j = 0; j < pwr2_array.Length; j++)
                {
                    if ((mask & i) != 0) r += pwr2_array[j];

                    //for next loop:
                    mask = mask << 1;
                }

                if (r > i)
                {
                    Complex temp = c_array[i];
                    c_array[i] = c_array[r];
                    c_array[r] = temp;
                }
            }
        }

        /// <summary>
        /// Does the FFT on "c_arary". This changes the content of "c_array".
        /// Sets "c_array" to null if length is not a power of 2.
        /// </summary>
        public static void FFT(Complex[] c_array)
        {
            int power;
            bool check_length = is_power_of_2(c_array.Length, out power);
            if (!check_length)
            {
                c_array = null;
                return;
            }
            
            bit_reverse(c_array, power);

            //twiddle factors: the exp(-j*2pi/N*n) array:
            //The second half of the array is -1* the first half
            Complex[] twiddle = new Complex[c_array.Length / 2];
            twiddle[0] = 1;
            for (int n = 1; n < c_array.Length / 2; n++)
            {
                double exponent = -2 * Math.PI / c_array.Length * n;
                twiddle[n] = Complex.Exp(new Complex(0, exponent));
            }

            /* Assuming 8 point FFT:
             * In "stage" 1, the butterflies are in groups of "1", the twiddle
             * factor used is twiddle[0].
             * In "stage" 2, the butterflies are in gropus of "2", the twiddle
             * factors used are twiddle[0] and twiddle[2].
             * In "stage" 3, the butterflies are in groups of "4", the twiddle
             * factors used are twiddle[0, 1, 2, 3]
             */
            int stage = 1;
            int but_per_group = 1; //number of butterflies per group            

            for (stage = 1; stage <= power; stage++)
            {                
                int base_address = 0; // the "c_array" element being worked on
                //this counts: 0, 0 + but_per_group*2(1), 0 + but_per_group*2(2), ...

                //for each stage, the twiddle factors to use skips:
                //stage 1: twiddle[0]
                //stage 2: twiddle[0, 2]
                //stage 3: twiddle[0, 1, 2, 3]
                int twiddle_skip = twiddle.Length / but_per_group;
                int twiddle_index = 0; //the twiddle factor being used
                //It jumps depending on the twiddle_skip

                //number of butterfly groups in current stage = c_array.Length / 2 / but_group_size
                for (int but_group_num = 0;
                    but_group_num < c_array.Length / 2 / but_per_group; but_group_num++)
                {
                    twiddle_index = 0;
                    for (int i = 0; i < but_per_group; i++)
                    {
                        //a single butterfly
                        Complex twiddle_product = twiddle[twiddle_index] * c_array[base_address + but_per_group + i];
                        Complex temp = c_array[base_address + i] + twiddle_product;
                        c_array[base_address + but_per_group + i] = c_array[base_address + i] - twiddle_product;
                        c_array[base_address + i] = temp;

                        //for the next loop:
                        twiddle_index = twiddle_index + twiddle_skip;
                    }

                    //for the next butterfly group:
                    base_address = base_address + but_per_group * 2;
                }

                //for the next stage:
                but_per_group = but_per_group * 2;
            }

            return;
        }
        
        /// <summary>
        /// This function does FFT on "c_array" like the "FFT" function, and also
        /// records the values of the butterflies as the algorithm progresses.
        /// This function is currently limited to FFTs of up to 256 points to limit
        /// memory usage.
        /// </summary>
        public static void FFT_transcript(Complex[] c_array, out Complex[,] butterfly_in, 
            out Complex[,] butterfly_out)
        {
            int power;
            bool check_length = is_power_of_2(c_array.Length, out power);
            if (!check_length)
            {
                c_array = null;
                butterfly_in = null;
                butterfly_out = null;
                return;
            }
            if (c_array.Length > 256)
            {
                c_array = null;
                butterfly_in = null;
                butterfly_out = null;
                return;
            }
            
            butterfly_in = new Complex[power, c_array.Length];
            butterfly_out = new Complex[power, c_array.Length];

            bit_reverse(c_array, power);

            //twiddle factors: the exp(-j*2pi/N*n) array:
            //The second half of the array is -1* the first half
            Complex[] twiddle = new Complex[c_array.Length / 2];
            twiddle[0] = 1;
            for (int n = 1; n < c_array.Length / 2; n++)
            {
                double exponent = -2 * Math.PI / c_array.Length * n;
                twiddle[n] = Complex.Exp(new Complex(0, exponent));
            }

            /* Assuming 8 point FFT:
             * In "stage" 1, the butterflies are in groups of "1", the twiddle
             * factor used is twiddle[0].
             * In "stage" 2, the butterflies are in gropus of "2", the twiddle
             * factors used are twiddle[0] and twiddle[2].
             * In "stage" 3, the butterflies are in groups of "4", the twiddle
             * factors used are twiddle[0, 1, 2, 3]
             */
            int stage = 1;
            int but_per_group = 1; //number of butterflies per group                    

            for (stage = 1; stage <= power; stage++)
            {
                int base_address = 0; // the "c_array" element being worked on
                //this counts: 0, 0 + but_per_group*2(1), 0 + but_per_group*2(2), ...

                //for each stage, the twiddle factors to use skips:
                //stage 1: twiddle[0]
                //stage 2: twiddle[0, 2]
                //stage 3: twiddle[0, 1, 2, 3]
                int twiddle_skip = twiddle.Length / but_per_group;
                int twiddle_index = 0; //the twiddle factor being used
                //It jumps depending on the twiddle_skip

                int count = 0; //counter for the transcript butterfly_in and butterfly_out arrays

                //number of butterfly groups in current stage = c_array.Length / 2 / but_group_size
                for (int but_group_num = 0;
                    but_group_num < c_array.Length / 2 / but_per_group; but_group_num++)
                {
                    twiddle_index = 0;
                    for (int i = 0; i < but_per_group; i++)
                    {
                        //a single butterfly
                        Complex twiddle_product = twiddle[twiddle_index] * c_array[base_address + but_per_group + i];
                        Complex temp = c_array[base_address + i] + twiddle_product;

                        //transcript:
                        butterfly_in[stage - 1, count] = c_array[base_address + i];
                        butterfly_in[stage - 1, count + 1] = c_array[base_address + but_per_group + i];

                        c_array[base_address + but_per_group + i] = c_array[base_address + i] - twiddle_product;
                        c_array[base_address + i] = temp;

                        //transcript:
                        butterfly_out[stage - 1, count] = c_array[base_address + i];
                        butterfly_out[stage - 1, count + 1] = c_array[base_address + but_per_group + i];
                        count = count + 2;

                        //for the next loop:
                        twiddle_index = twiddle_index + twiddle_skip;
                    }

                    //for the next butterfly group:
                    base_address = base_address + but_per_group * 2;
                }

                //for the next stage:
                but_per_group = but_per_group * 2;
            }

            return;
        }

        /// <summary>
        /// Prints a particular FFT stage, given the 2D Complex[,] obtained from the
        /// "FFT_transcript" function call. The print out is meant to help with debugging
        /// the radix-2 FFT operation. The "prefix0" and "prefix1" is for variable 
        /// naming.
        /// </summary>
        public static string FFT_transcript_print(int fft_stage, Complex[,] butterfly_record, 
                string prefix0, string prefix1)
        {
            if (fft_stage > butterfly_record.GetLength(0) - 1) return null;            
            int length = butterfly_record.GetLength(1);
            var v0_real = new StringBuilder();
            var v0_imag = new StringBuilder();
            var v1_real = new StringBuilder();
            var v1_imag = new StringBuilder();
            v0_real.Append(prefix0 + ".real\t");
            v0_imag.Append(prefix0 + ".imag\t");
            v1_real.Append(prefix1 + ".real\t");
            v1_imag.Append(prefix1 + ".imag\t");
            for (int i = 0; i < length; i = i + 2)
            {
                v0_real.Append(butterfly_record[fft_stage, i].Real + "\t");
                v0_imag.Append(butterfly_record[fft_stage, i].Imaginary + "\t");
                v1_real.Append(butterfly_record[fft_stage, i + 1].Real + "\t");
                v1_imag.Append(butterfly_record[fft_stage, i + 1].Imaginary + "\t");
            }
            return v0_real + "\r\n" + v0_imag + "\r\n" + v1_real + "\r\n" + v1_imag ;
        }

        /// <summary>
        /// Does the FFT and returns the result as a "CVector". 
        /// </summary>
        public CVector FFT()
        {
            //make a copy of c_array
            Complex[] c_array2 = new Complex[c_array.Length];
            for (int i = 0; i < c_array.Length; i++)
                c_array2[i] = c_array[i];

            CVector.FFT(c_array2);

            return new CVector(c_array2);
        }

        /// <summary>
        /// This function does inverse FFT on "c_array". It will conjugate
        /// the c_array, and then call FFT, and the conjugate again. The
        /// FFT function will set c_array to null if it is not a power of two.
        /// </summary>
        public static void Inverse_FFT(Complex[] c_array)
        {
            for (int i = 0; i < c_array.Length; i++)
                c_array[i] = Complex.Conjugate(c_array[i]);
            CVector.FFT(c_array);
            if (c_array != null)
            {
                for (int i = 0; i < c_array.Length; i++)
                    c_array[i] = Complex.Conjugate(c_array[i]) / c_array.Length;
            }
        }

        #endregion
    }
}
