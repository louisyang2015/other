﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.Numerics;

namespace APU_Tester
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        const int L = 2048 * 2; //16kHz: 2048
        const int M = 16;
        const int N = (L / M);
        const int N2 = N * 2;
        const int nd = 0;

        private MyRS232 serial_port;
        private Tester tester;

        private void Form1_Load(object sender, EventArgs e)
        {
            serial_port = new MyRS232();
            tester = new Tester(serial_port);

            
            make_twiddle_hex_file(1024); // generate hex files for twiddle factors
            //Input_textBox.Text = fft32_print_transcript(); 
                    // prints a transcript for a 32 point FFT
                        
        }

        #region Event Handlers

        private void RandomTest_button_Click(object sender, EventArgs e)
        {
            if (Test_listBox.SelectedIndex < 0) return;
            string item = Test_listBox.SelectedItem.ToString();
            bool result = true;

            this.Cursor = Cursors.WaitCursor;
            if (item.StartsWith("send and get")) result = tester.send_and_get_test(30);
            else if (item.StartsWith("copy")) result = tester.copy_test(30);
            else if (item.StartsWith("memory reset")) result = tester.reset_memory_test(30);
            else if (item.StartsWith("add array")) result = tester.add_vector_test(30);
            else if (item.StartsWith("MAC")) result = tester.mac_test(30);
            else if (item.StartsWith("conjugate mirror")) result = tester.conjugate_mirror_test(30);
            else if (item.StartsWith("compute Rb")) result = tester.compute_rb_test(30);
            // else if (item.StartsWith("compute Rb")) result = tester.compute_rb_test_ms();
            else if (item.StartsWith("FFT 32")) result = tester.fft32_test(30);
            // else if (item.StartsWith("FFT 32")) result = tester.fft32_test_ms();
            else if (item.StartsWith("FFT 512")) result = tester.fft512_test(30);
            // else if (item.StartsWith("FFT 512")) result = tester.fft512_test_fixed();
            else if (item.StartsWith("ssram linear")) result = tester.ssram_linear_test(30);
            else if (item.StartsWith("ssram reset")) result = tester.ssram_reset_test(30);
            else if (item.StartsWith("ssram circular read")) result = tester.ssram_circular_read_test(30);
                    
            this.Cursor = Cursors.Default;
            
            Input_textBox.Text = tester.test_input;
            EOutput_textBox.Text = tester.expected_output;
            NOutput_textBox.Text = tester.nios2_output;
            Compare_textBox.Text = tester.comparison;

            System.Media.SystemSounds.Exclamation.Play();
            if (result == false) Input_textBox.Text += "Test failed. \r\n";
            else Input_textBox.Text += "Test successful. \r\n";
        }

        private void Dump_button_Click(object sender, EventArgs e)
        {
            if (Source_comboBox.SelectedIndex < 0) return;
            string item = Source_comboBox.SelectedItem.ToString();
            if (item.StartsWith("A0i")) tester.nios2_dump(ArrayProc.SOURCE.A0, 0);
            else if (item.StartsWith("A0r")) tester.nios2_dump(ArrayProc.SOURCE.A0, 1);
            else if (item.StartsWith("A1i")) tester.nios2_dump(ArrayProc.SOURCE.A1, 0);
            else if (item.StartsWith("A1r")) tester.nios2_dump(ArrayProc.SOURCE.A1, 1);
            else if (item.StartsWith("B0i")) tester.nios2_dump(ArrayProc.SOURCE.B0, 0);
            else if (item.StartsWith("B0r")) tester.nios2_dump(ArrayProc.SOURCE.B0, 1);
            else if (item.StartsWith("B1i")) tester.nios2_dump(ArrayProc.SOURCE.B1, 0);
            else if (item.StartsWith("B1r")) tester.nios2_dump(ArrayProc.SOURCE.B1, 1);
            NIOS2_data_textBox.Text = tester.nios2_watch_data;
        }

        #endregion

        #region Helper Functions
        /// <summary>
        /// Print any numbers found in the PC's RS232 buffer
        /// </summary>
        private void print_rs232()
        {
            bool cont = true;
            int val;
            while (cont)
            {
                cont = serial_port.read_integer(out val);
                if (cont)
                    NOutput_textBox.Text += val + "\r\n";
                else
                    NOutput_textBox.Text += "Nothing \r\n";
            }
        }

        
        #endregion

        #region FFT Testing functions
        /// <summary>
        /// Generates twiddle factors for an N length FFT and store them in a file using the
        /// Q7.40 format. There will be N/2 twiddle factors.
        /// </summary>
        private void make_twiddle_hex_file(int N)
        {
            // find twiddle[]
            Complex[] twiddle = new Complex[N / 2];
            twiddle[0] = 1;
            for (int n = 1; n < twiddle.Length; n++)
            {
                double exponent = -2 * Math.PI / N * n;
                twiddle[n] = Complex.Exp(new Complex(0, exponent));
            }

            // convert twiddle[] to long
            long[] twiddle_r = new long[N / 2];
            long[] twiddle_i = new long[N / 2];
            double fraction = Math.Pow(2, -40);
            for (int i = 0; i < twiddle.Length; i++)
            {
                twiddle_r[i] = (long)Math.Round(twiddle[i].Real / fraction);
                twiddle_i[i] = (long)Math.Round(twiddle[i].Imaginary / fraction);
            }

            // write twiddle_long to file
            byte[] b_array_r = new byte[6 * 512];
            byte[] b_array_i = new byte[6 * 512];
            for (int i = 0; i < twiddle.Length; i++)
            {
                byte[] b_temp = BitConverter.GetBytes(twiddle_r[i]);
                for (int j = 0; j < 6; j++)
                    b_array_r[i * 6 + j] = b_temp[5 - j];
                b_temp = BitConverter.GetBytes(twiddle_i[i]);
                for (int j = 0; j < 6; j++)
                    b_array_i[i * 6 + j] = b_temp[5 - j];
            }
            Hex_File.write_bytes_to_file(b_array_r, "twiddle_r.hex", 6, 6);
            Hex_File.write_bytes_to_file(b_array_i, "twiddle_i.hex", 6, 6);
        }

        /// <summary>
        /// Generate a set of data for testing the 32 point fft.
        /// </summary>
        private string fft32_print_transcript()
        {
            var sb = new StringBuilder();
            // original data
            sb.Append("Input = \t");
            Complex[] c_array = new Complex[32];
            for (int i = 0; i < 28; i++)
            {
                c_array[i] = i - 7;
                sb.Append(c_array[i] + "\t");
            }
            for (int i = 28; i < 32; i++)
            {
                c_array[i] = i - 27;
                sb.Append(c_array[i] + "\t");
            }
            sb.Append("\r\n");

            Complex[,] butterfly_in, butterfly_out;
            CVector.FFT_transcript(c_array, out butterfly_in, out butterfly_out);

            for (int i = 0; i < 5; i++)
            {
                sb.Append("FFT stage " + i + "\r\n");
                sb.Append(CVector.FFT_transcript_print(i, butterfly_in, "X0", "X1") + "\r\n");
                sb.Append(CVector.FFT_transcript_print(i, butterfly_out, "Y0", "Y1") + "\r\n");
                sb.Append("\r\n");
            }
            
            return sb.ToString();
        }

        
        #endregion
    }
}
