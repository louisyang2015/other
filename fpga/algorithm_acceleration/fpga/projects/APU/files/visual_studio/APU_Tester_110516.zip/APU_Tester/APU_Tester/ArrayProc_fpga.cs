﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace APU_Tester
{
    class ArrayProc_fpga
    {
        private MyRS232 serial_port;

        /// <summary>
        /// The constructor expects a serial port that has already been opened
        /// </summary>
        public ArrayProc_fpga(MyRS232 serial_port)
        {
            this.serial_port = serial_port;
        }

        #region Test Functions

        /// <summary>
        /// Sends a zero to the array processor and expects a zero in return
        /// </summary>
        public bool echo()
        {
            serial_port.write_integer(0);
            bool response = serial_port.wait_for_bytes(4, 200);
            if (response == false) return false;
            int response_val;
            response = serial_port.read_integer(out response_val);
            if (response == false) return false;
            if (response_val != 0) return false;
            return true;
        }

        /// <summary>
        /// Sends data to NIOS 2, which will in turn send to APU. The format is
        /// test number (1), dest, length, and the array of values.
        /// </summary>
        public void send_data(ArrayProc.DEST dest, int[] array, int length)
        {
            serial_port.write_integer(1);
            serial_port.write_integer((int)dest);
            serial_port.write_integer(length);
            write_array(array);
        }

        /// <summary>
        /// Gets data from NIOS 2, which in turn gets the data from the APU. The format
        /// is test number (2), src, real, start_index, length, and then a wait for the data
        /// </summary>
        public int[] get_data(ArrayProc.SOURCE src, int real, int start_index, int length)
        {
            if (length > 256) return null; // for now the result FIFO is only 256 element max
            serial_port.write_integer(2);
            serial_port.write_integer((int)src);
            serial_port.write_integer(real);
            serial_port.write_integer(start_index);
            serial_port.write_integer(length);
            System.Threading.Thread.Sleep(100);
            bool response;
            int[] i_array = new int[length];
            int i = 0;
            while (i < length)
            {
                response = serial_port.wait_for_bytes(4, 200);
                if (response == false) return null;
                response = serial_port.read_integer(out i_array[i]);
                i++;
            }
            return i_array;
        }

        /// <summary>
        /// Runs the "test_copy_data()" routine on the FPGA
        /// </summary>
        public void copy_general(ArrayProc.ALU_COPY_MODE alu_mode, ArrayProc.SOURCE src, 
                ArrayProc.DEST dest, int length, int src_start, int dest_start)
        {
            serial_port.write_integer(3);
            serial_port.write_integer((int)alu_mode);
            serial_port.write_integer((int)src);
            serial_port.write_integer((int)dest);
            serial_port.write_integer(length);
            serial_port.write_integer(src_start);
            serial_port.write_integer(dest_start);
        }

        /// <summary>
        /// Runs the test_reset_memory() routine on the FPGA
        /// </summary>
        public void reset_memory(ArrayProc.DEST dest, int dest_start, int length)
        {
            serial_port.write_integer(4);
            serial_port.write_integer((int)dest);
            serial_port.write_integer(dest_start);
            serial_port.write_integer(length);
        }

        /// <summary>
        /// Runs the test_add_array() routine on the FPGA
        /// </summary>
        public void add_array(ArrayProc.SOURCE src1, ArrayProc.SOURCE src2, int src_start, 
                int length, ArrayProc.DEST dest)
        {
            serial_port.write_integer(5);
            serial_port.write_integer((int)src1);
            serial_port.write_integer((int)src2);
            serial_port.write_integer(src_start);
            serial_port.write_integer(length);
            serial_port.write_integer((int)dest);
        }

        /// <summary>
        /// Runs the test_mac() routine on the FPGA
        /// </summary>
        public void mac(ArrayProc.SOURCE src, ArrayProc.T_SOURCE t_src, ArrayProc.DEST dest, 
                int src_start, int dest_index, int length)
        {
            serial_port.write_integer(6);
            serial_port.write_integer((int)src);
            serial_port.write_integer((int)t_src);
            serial_port.write_integer((int)dest);
            serial_port.write_integer(src_start);
            serial_port.write_integer(dest_index);
            serial_port.write_integer(length);
        }

        /// <summary>
        /// Run the test_conjugate_mirror() routine on the FPGA
        /// </summary>
        public void conjugate_mirror(ArrayProc.SOURCE src, ArrayProc.DEST dest, 
            int length, int src_start, int dest_start)
        {
            serial_port.write_integer(7);
            serial_port.write_integer((int)src);
            serial_port.write_integer((int)dest);
            serial_port.write_integer(length);
            serial_port.write_integer(src_start);
            serial_port.write_integer(dest_start);
        }

        /// <summary>
        /// Run the test_compute_power() routine on the FPGA
        /// </summary>
        public void compute_power(int length, int src_start, int dest_index)
        {
            serial_port.write_integer(8);
            serial_port.write_integer(length);
            serial_port.write_integer(src_start);
            serial_port.write_integer(dest_index);
        }

        /// <summary>
        /// Run the test_compute_Rb() routine on the FPGA
        /// </summary>
        public void compute_Rb(ArrayProc.SOURCE src, ArrayProc.DEST dest, 
                int length, int src_start, int dest_start, int mu_k)
        {
            serial_port.write_integer(9);
            serial_port.write_integer((int)src);
            serial_port.write_integer((int)dest);
            serial_port.write_integer(length);
            serial_port.write_integer(src_start);
            serial_port.write_integer(dest_start);
            serial_port.write_integer(mu_k);
        }

        /// <summary>
        /// Run the test_fft32() routine on the FPGA. Source=4 for A or E for B.
        /// fft_shift: 0=no shift; 1=left shift; 3=right shift.
        /// </summary>
        public void FFT32(int source, int inverse, int fft_shift)
        {
            serial_port.write_integer(10);
            serial_port.write_integer(source);
            serial_port.write_integer(inverse);
            serial_port.write_integer(fft_shift);
        }        
        /// <summary>
        /// Run the test_fft32() routine on the FPGA to trigger FFT32_A2A()
        /// </summary>
        public void FFT32_A2A(int fft_shift)
        {
            FFT32(4, 0, fft_shift);
        }
        /// <summary>
        /// Run the test_fft32() routine on the FPGA to trigger FFT32_B2B()
        /// </summary>
        public void FFT32_B2B(int fft_shift)
        {
            FFT32(0xE, 0, fft_shift);
        }
        /// <summary>
        /// Run the test_fft32() routine on the FPGA to trigger iFFT32_A2A()
        /// </summary>
        public void iFFT32_A2A(int fft_shift)
        {
            FFT32(4, 1, fft_shift);
        }
        /// <summary>
        /// Run the test_fft32() routine on the FPGA to trigger iFFT32_B2B()
        /// </summary>
        public void iFFT32_B2B(int fft_shift)
        {
            FFT32(0xE, 1, fft_shift);
        }

        /// <summary>
        /// Run the test_fft512() routine on the FPGA. Source=4 for A or E for B.
        /// fft_shift: 0=no shift; 1=left shift; 3=right shift.
        /// </summary>
        public void FFT512(int source, int inverse, int fft_shift)
        {
            serial_port.write_integer(11);
            serial_port.write_integer(source);
            serial_port.write_integer(inverse);
            serial_port.write_integer(fft_shift);
        }
        /// <summary>
        /// Run the test_fft512() routine on the FPGA to trigger FFT512_A2A()
        /// </summary>
        public void FFT512_A2A(int fft_shift)
        {
            FFT512(4, 0, fft_shift);
        }
        /// <summary>
        /// Run the test_fft512() routine on the FPGA to trigger FFT512_B2B()
        /// </summary>
        public void FFT512_B2B(int fft_shift)
        {
            FFT512(0xE, 0, fft_shift);
        }
        /// <summary>
        /// Run the test_fft512() routine on the FPGA to trigger iFFT512_A2A()
        /// </summary>
        public void iFFT512_A2A(int fft_shift)
        {
            FFT512(4, 1, fft_shift);
        }
        /// <summary>
        /// Run the test_fft512() routine on the FPGA to trigger iFFT512_B2B()
        /// </summary>
        public void iFFT512_B2B(int fft_shift)
        {
            FFT512(0xE, 1, fft_shift);
        }

        /// <summary>
        /// Run the test_ssram_set_addr() routine on the FPGA
        /// </summary>
        public void ssram_set_addr(int n)
        {
            serial_port.write_integer(12);
            serial_port.write_integer(n);
        }
        /// <summary>
        /// Run the test_ssram_set_skip() routine on the FPGA
        /// </summary>
        public void ssram_set_skip(int n)
        {
            serial_port.write_integer(13);
            serial_port.write_integer(n);
        }
        /// <summary>
        /// Run the test_ssram_set_highest_addr() routine on the FPGA
        /// </summary>
        public void ssram_set_highest_addr(int n)
        {
            serial_port.write_integer(14);
            serial_port.write_integer(n);
        }
        /// <summary>
        /// Run the test_ssram_set_block_size() routine on the FPGA
        /// </summary>
        public void ssram_set_block_size(int n)
        {
            serial_port.write_integer(15);
            serial_port.write_integer(n);
        }
        /// <summary>
        /// Run the test_ssram_reset() routine on the FPGA
        /// </summary>
        public void ssram_reset(int length)
        {
            serial_port.write_integer(16);
            serial_port.write_integer(length);
        }
        /// <summary>
        /// Run the test_ssram_write() routine on the FPGA
        /// </summary>
        public void ssram_write(ArrayProc.SOURCE source, int imag, int length, int source_start)
        {
            serial_port.write_integer(17);
            serial_port.write_integer((int)source);
            serial_port.write_integer(imag);
            serial_port.write_integer(length);
            serial_port.write_integer(source_start);
        }
        /// <summary>
        /// Run the test_ssram_read() routine on the FPGA
        /// </summary>
        public void ssram_read(ArrayProc.DEST dest, int length, int dest_start)
        {
            serial_port.write_integer(18);
            serial_port.write_integer((int)dest);
            serial_port.write_integer(length);
            serial_port.write_integer(dest_start);
        }

        #endregion

        #region Helper Functions
        /// <summary>
        /// Sends an array into the RS232.
        /// </summary>
        private void write_array(int[] i_array)
        {
            for (int i = 0; i < i_array.Length; i++)
            {
                serial_port.write_integer(i_array[i]);
                //testing pause
                if (i == 100) System.Threading.Thread.Sleep(100);
                if (i == 200) System.Threading.Thread.Sleep(100);
                if (i == 300) System.Threading.Thread.Sleep(100);
                if (i == 400) System.Threading.Thread.Sleep(100);
                if (i == 500) System.Threading.Thread.Sleep(100);
            }
        }
        #endregion
    }
}
