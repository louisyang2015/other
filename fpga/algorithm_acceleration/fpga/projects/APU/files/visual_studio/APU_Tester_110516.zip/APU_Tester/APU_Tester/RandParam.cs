﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace APU_Tester
{
    /// <summary>
    /// This class is a collection of procedures to generate random numbers for testing
    /// the array processor.
    /// </summary>
    class RandParam
    {
        private Random rand;
        const int N = 512; // this is size of the memory buffer in array processor
       
        public RandParam()
        {
            rand = new Random();
        }

        #region General Randomization

        /// <summary>
        /// Returns true with a possibility of 1/n.
        /// </summary>
        public bool coin_flip(int n)
        {
            if (n < 2) return true;
            int val = rand.Next(1, n + 1);
            if (val == 1) return true;
            return false;
        }

        /// <summary>
        /// Fill an array with random integers. The random values are between the
        /// "min" and "max" values provided
        /// </summary>
        public int[] rand_array(int length, int min, int max)
        {
            int[] i_array = new int[length];
            for (int i = 0; i < length; i++)
                i_array[i] = rand.Next(min, max);
            return i_array;
        }


        /// <summary>
        /// Returns a random integer
        /// </summary>
        public int rand_int(int min, int max)
        {
            return rand.Next(min, max);
        }

        #endregion 


        #region Randomization Specific to APU

        public ArrayProc.ALU_COPY_MODE rand_alu_mode()
        {
            int r = rand.Next(2, 7);
            /* public enum ALU_COPY_MODE {SIMPLE_COPY=2, REAL_COPY=3, RI_SWAP=4, CONJUGATE=5,
                ROUND_SAT=6, LSHIFT16=7} */
            return (ArrayProc.ALU_COPY_MODE)r;
        }
        public ArrayProc.DEST rand_dest()
        {
            int r = rand.Next(0, 15);
            return (ArrayProc.DEST)(r);
        }
        public ArrayProc.SOURCE rand_source()
        {
            int r = rand.Next(0, 3);
            return (ArrayProc.SOURCE)(r);
        }
        public ArrayProc.T_SOURCE rand_t_source()
        {
            int r = rand.Next(1, 3);
            return (ArrayProc.T_SOURCE)(r);
        }

        /// <summary>
        /// Generate a length between 16 and "N". Then generate a 
        /// starting point between 0 and N-length
        /// </summary>
        public void rand_length_start(out int length, out int src_start, out int dest_start)
        {
            length = rand.Next(16, N);
            src_start = rand.Next(0, N - length);
            dest_start = rand.Next(0, N - length);
        }

        #endregion


    }
}
