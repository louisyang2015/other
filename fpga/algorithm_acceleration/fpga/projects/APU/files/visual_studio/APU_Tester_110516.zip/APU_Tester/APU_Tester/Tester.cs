﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace APU_Tester
{
    class Tester
    {
        const int L = 2048 * 2; //16kHz: 2048, 32kHz: 4096
        const int M = 16;
        const int N = (L / M); // 32kHz: 256
        const int N2 = N * 2; // 32kHz: 512
        const int nd = 0;

        private ArrayProc_fpga ap_fpga; // real array processor
        private ArrayProc ap_cs; // system model of the array processor
        private RandParam rp; // parameter random generator

        public string test_input;
        public string expected_output;
        public string nios2_output;
        public string comparison;
        public string nios2_watch_data;

        /// <summary>
        /// The constructor takes a serial port object and expects the serial port to 
        /// already have been opened somewhere else.
        /// </summary>
        public Tester(MyRS232 serial_port)
        {
            ap_fpga = new ArrayProc_fpga(serial_port);
            ap_cs = new ArrayProc();
            ap_cs.init_param(M, N, N2, nd);
            rp = new RandParam();
        }

        #region Test Functions

        /// <summary>
        /// Test the "send_data" and "get_data" correctness. Does a single test that
        /// populate the entire memory region, then read it back, followed by "n" more tests
        /// that populate random memory regions and read it back.
        /// </summary>
        public bool send_and_get_test(int n)
        {
            clear_text();
            if (test_echo() == false) return false;
            test_input += "Initializing all memory buffers to the same set of data \r\n";
            if (initialize_memory_all_same() == false) return false;

            bool result;
            int[] i_array;
            for (int i = 0; i < n; i++)
            {                
                // use a 1/4 chance of doing a full length (N2) test
                int length = N2;
                if (rp.coin_flip(4)) length = N2;
                else length = rp.rand_int(16, N2 - 1);
                i_array = rp.rand_array(length, Int32.MinValue, Int32.MaxValue);
                ArrayProc.DEST dest = rp.rand_dest();

                test_input += "send and get test # " + i + ", dest = " + dest + ", length = " 
                        + length + "\r\n";
                ap_fpga.send_data(dest, i_array, length);
                System.Threading.Thread.Sleep(100);
                ap_cs.send_data(dest, i_array, length);
                result = memory_check(0);
                if (result == false) return false;
            }

            return true;
        }

        /// <summary>
        /// Read result from NIOS 2 and prints it.
        /// </summary>
        public bool nios2_dump(ArrayProc.SOURCE src, int real)
        {
            nios2_watch_data = "";
            // for now the result FIFO is only 256 values max, so the full buffer
            // has to be obtained in two reads
            int[] i_array1a = ap_fpga.get_data(src, real, 0, 256);
            int[] i_array1b = ap_fpga.get_data(src, real, 256, 256);
            if (i_array1a == null || i_array1b == null)
            {
                nios2_watch_data += "Failed to retrieve array \r\n";
                return false;
            }
            int[] i_array1 = new int[N2];
            for (int k = 0; k < i_array1a.Length; k++)
            {
                i_array1[k] = i_array1a[k];
                i_array1[N + k] = i_array1b[k];
            }
            int[] exp_array = ap_cs.get_data(src, real, 0, 512);
            string array_name = (src).ToString();
            if (real == 0) array_name += ".imag";
            else array_name += "real";
            nios2_watch_data += format_array_data(i_array1, exp_array, array_name, 0) + "\r\n";
            return true;
        }

        /// <summary>
        /// Copy from one memory buffer to another. Read back to confirm. This test is
        /// done "n" times.
        /// </summary>
        public bool copy_test(int n)
        {
            clear_text();
            if (test_echo() == false) return false;

            test_input = ""; expected_output = ""; nios2_output = ""; comparison = "";
            for (int i = 0; i < n; i++)
            {
                // re-initiate all memory every 3 tests
                if (i % 3 == 0)
                {
                    test_input += "Initializing memory buffers \r\n";
                    if (initialize_memory(1) == false) return false;
                }
                
                ArrayProc.ALU_COPY_MODE alu_mode = rp.rand_alu_mode();
                ArrayProc.SOURCE src = rp.rand_source();
                ArrayProc.DEST dest = rp.rand_dest();
                int length, src_start, dest_start;
                rp.rand_length_start(out length, out src_start, out dest_start);

                test_input += "Copy test # " + i + " ALU mode=" + alu_mode
                        + " src=" + src + " dest=" + dest + " length=" + length
                        + " src_start=" + src_start + " dest_start=" + dest_start
                        + "\r\n";

                ap_fpga.copy_general(alu_mode, src, dest, length, src_start, dest_start);
                ap_cs.copy_general(alu_mode, src, dest, length, src_start, dest_start);
                bool result = memory_check(0);
                if (result == false) return false;
            }
            return true;
        }

        /// <summary>
        /// Reset a segment of memory. Read back to confirm. This test is
        /// done "n" times.
        /// </summary>
        public bool reset_memory_test(int n)
        {
            clear_text();
            if (test_echo() == false) return false;

            test_input = ""; expected_output = ""; nios2_output = ""; comparison = "";
            for (int i = 0; i < n; i++)
            {
                // re-initiate all memory every 3 tests
                if (i % 3 == 0)
                {
                    test_input += "Initializing memory buffers \r\n";
                    if (initialize_memory(1) == false) return false;
                }
                
                ArrayProc.DEST dest = rp.rand_dest();
                int length, src_start, dest_start;
                rp.rand_length_start(out length, out src_start, out dest_start);

                test_input += "Reset memory test # " + i + " dest=" + dest 
                        + " length=" + length + " dest_start=" + dest_start + "\r\n";

                ap_fpga.reset_memory(dest, dest_start, length);
                ap_cs.reset_memory(dest, dest_start, length);

                bool result = memory_check(0);
                if (result == false) return false;
            }
            return true;
        }

        /// <summary>
        /// Tests the add_vector instruction. Do it "n" times.
        /// </summary>
        public bool add_vector_test(int n)
        {
            clear_text();
            if (test_echo() == false) return false;

            test_input = ""; expected_output = ""; nios2_output = ""; comparison = "";
            for (int i = 0; i < n; i++)
            {
                // re-initiate all memory every 3 tests
                if (i % 3 == 0)
                {
                    test_input += "Initializing memory buffers \r\n";
                    if (initialize_memory(1) == false) return false;
                }

                ArrayProc.SOURCE src1 = rp.rand_source();
                ArrayProc.SOURCE src2 = rp.rand_source();
                ArrayProc.DEST dest = rp.rand_dest();
                int length, src_start, dest_start;
                rp.rand_length_start(out length, out src_start, out dest_start);

                test_input += "Add array test # " + i + " src1=" + src1
                        + " src2=" + src2 + " src_start=" + src_start 
                        + " length=" + length + " dest=" + dest + "\r\n";

                ap_cs.add_array(src1, src2, src_start, length, dest);
                ap_fpga.add_array(src1, src2, src_start, length, dest);

                bool result = memory_check(0);
                if (result == false) return false;
            }
            return true;
        }

        /// <summary>
        /// Tests the mac instruction. Do it "n" times. The tolerance is set to 1, 
        /// meaning the FPGA can deviate from the software model by 1 bit.
        /// </summary>
        public bool mac_test(int n)
        {
            clear_text();
            if (test_echo() == false) return false;

            test_input = ""; expected_output = ""; nios2_output = ""; comparison = "";
            for (int i = 0; i < n; i++)
            {
                // re-initiate all memory every 5 tests
                if (i % 5 == 0)
                {
                    test_input += "Initializing memory buffers \r\n";
                    if (initialize_memory(256) == false) return false;
                }

                ArrayProc.SOURCE src = rp.rand_source();
                ArrayProc.T_SOURCE t_src = rp.rand_t_source();
                ArrayProc.DEST dest = rp.rand_dest();
                int length, src_start, dest_start;
                rp.rand_length_start(out length, out src_start, out dest_start);
                int dest_index = rp.rand_int(0, N2 - 1);

                test_input += "Mac test # " + i + " src=" + src
                        + " t_src=" + t_src + " dest=" + dest
                        + " src_start=" + src_start + " dest_index=" + dest_index
                        + " length=" + length +"\r\n";

                ap_cs.mac(src, t_src, dest, src_start, dest_index, length);
                ap_fpga.mac(src, t_src, dest, src_start, dest_index, length);

                bool result = memory_check(1); // NOTE tolerance = 1
                if (result == false) return false;
            }
            return true;
        }

        /// <summary>
        /// Tests the conjugate_mirror instruction. Do it "n" times.
        /// </summary>
        public bool conjugate_mirror_test(int n)
        {
            clear_text();
            if (test_echo() == false) return false;

            test_input = ""; expected_output = ""; nios2_output = ""; comparison = "";
            for (int i = 0; i < n; i++)
            {
                // re-initiate all memory every 3 tests
                if (i % 3 == 0)
                {
                    test_input += "Initializing memory buffers \r\n";
                    if (initialize_memory(1) == false) return false;
                }

                // for the conjugate mirror procedure, the destination can't be
                // the same as source, and both must be 0~3
                int src_int = rp.rand_int(0, 3);
                int dest_int = rp.rand_int(0, 2);
                if (dest_int >= src_int) dest_int = dest_int + 1;

                ArrayProc.SOURCE src = (ArrayProc.SOURCE)src_int;
                ArrayProc.DEST dest = (ArrayProc.DEST)dest_int;
                int length, src_start, dest_start;
                rp.rand_length_start(out length, out src_start, out dest_start);
                dest_start = rp.rand_int(length - 1, N2 - 1);

                test_input += "Conjugate mirror test # " + i + " src=" + src
                        + " dest=" + dest + " length=" + length
                        + " src_start=" + src_start + " dest_start=" + dest_start
                        + "\r\n";

                ap_cs.conjugate_mirror(src, dest, length, src_start, dest_start);
                ap_fpga.conjugate_mirror(src, dest, length, src_start, dest_start);

                bool result = memory_check(0);
                if (result == false) return false;
            }
            return true;
        }

        /// <summary>
        /// Tests the compute_rb instruction. This in turn requires the 
        /// compute_power instruction for set up. Do it "n" times.
        /// NOTE: FPGA versus software match tolerance is set at 200
        /// NOTE: If sufficiently large input is used, many FPGA output will 
        /// deviate from the expected output by exactly 2X. This is because the
        /// value in C0 is off by 1, leading to an extra bit shift.
        /// </summary>
        public bool compute_rb_test(int n)
        {
            clear_text();
            if (test_echo() == false) return false;

            test_input = ""; expected_output = ""; nios2_output = ""; comparison = "";
            for (int i = 0; i < n; i++)
            {
                // re-initiate all memory every test
                test_input += "Initializing memory buffers \r\n";
                if (initialize_memory(8*1024) == false) return false;
                // when using: if (initialize_memory(1024) == false) return false;
                // quite a few FPGA outputs are off by a factor of 2

                int length, src_start, dest_start;
                int c0_length = rp.rand_int(32, 128);
                int c0_start = rp.rand_int(0, N2 - c0_length);

                // set up the C0 memory using the compute_power instruction
                for (int j = 0; j < c0_length; j++)
                {
                    rp.rand_length_start(out length, out src_start, out dest_start);                    
                    ap_cs.compute_power(length, src_start, c0_start + j);
                    ap_fpga.compute_power(length, src_start, c0_start + j);
                }
                System.Threading.Thread.Sleep(100);

                // run a single compute_rb instruction
                ArrayProc.SOURCE src = ArrayProc.SOURCE.A0;
                if(rp.coin_flip(2)) src = ArrayProc.SOURCE.A1;
                ArrayProc.DEST dest = ArrayProc.DEST.B0;
                if(rp.coin_flip(2)) dest = ArrayProc.DEST.B1;
                dest_start = rp.rand_int(0, N2 - c0_length);
                int mu_k = rp.rand_int(int.MaxValue / 512, int.MaxValue);
                // int mu_k = 0x40000000;

                test_input += "Compute Rb test # " + i + " src=" + src
                        + " dest=" + dest + " c0_length=" + c0_length
                        + " c0_start=" + c0_start + " dest_start=" + dest_start
                        + " mu_k=" + mu_k + "\r\n";

                ap_cs.compute_Rb(src, dest, c0_length, c0_start, dest_start, mu_k);
                ap_fpga.compute_Rb(src, dest, c0_length, c0_start, dest_start, mu_k);                

                // NOTE: FPGA versus software match tolerance is set at 200
                bool result = memory_check(200);
                if (result == false) return false;
            }
            return true;
        }

        /// <summary>
        /// Tests the compute_rb instruction. This in turn requires the 
        /// compute_power instruction for set up. The test case in this function
        /// is the test case implemented in the ModelSim test bench.
        /// </summary>
        public bool compute_rb_test_ms()
        {
            clear_text();
            if (test_echo() == false) return false;

            test_input = ""; expected_output = ""; nios2_output = ""; comparison = "";
            int n = 1;
            for (int i = 0; i < n; i++)
            {
                // re-initiate all memory every test
                test_input += "Initializing memory buffers \r\n";
                // if (initialize_memory(1) == false) return false;

                // initialize according to .xls file
                // -------------------------------
                int[] i_array = new int[32];
                for (int j = 0; j <= 15; j++) i_array[j] = 644245094;
                for (int j = 16; j <= 31; j++) i_array[j] = 2126008812;
                ap_fpga.send_data(ArrayProc.DEST.A0, i_array, 32);
                ap_cs.send_data(ArrayProc.DEST.A0, i_array, 32);
                // -------------------------------

                int length, src_start, dest_start;
                //int c0_length = rp.rand_int(32, 128);
                //int c0_start = rp.rand_int(0, N2 - c0_length);
                // -------------------------------
                int c0_length = 16;
                int c0_start = 0;
                // -------------------------------

                // set up the C0 memory using the compute_power instruction
                for (int j = 0; j < c0_length; j++)
                {
                    //rp.rand_length_start(out length, out src_start, out dest_start);
                    // -------------------------------
                    length = 16 + j; src_start = 0;
                    // -------------------------------
                    ap_cs.compute_power(length, src_start, c0_start + j);
                    ap_fpga.compute_power(length, src_start, c0_start + j);
                }
                System.Threading.Thread.Sleep(100);


                // populate data for compute_rb instruction
                // -------------------------------
                for (int j = 0; j <= 15; j++) i_array[j] = (j - 7) << 16;
                ap_fpga.send_data(ArrayProc.DEST.A0r, i_array, 16);
                ap_cs.send_data(ArrayProc.DEST.A0r, i_array, 16);

                for (int j = 0; j <= 15; j++) i_array[j] = (j - 3) << 16;
                ap_fpga.send_data(ArrayProc.DEST.A0i, i_array, 16);
                ap_cs.send_data(ArrayProc.DEST.A0i, i_array, 16);

                for (int j = 0; j <= 15; j++) i_array[j] = (j - 10) << 16;
                ap_fpga.send_data(ArrayProc.DEST.A1r, i_array, 16);
                ap_cs.send_data(ArrayProc.DEST.A1r, i_array, 16);

                for (int j = 0; j <= 15; j++) i_array[j] = (j - 5) << 16;
                ap_fpga.send_data(ArrayProc.DEST.A1i, i_array, 16);
                ap_cs.send_data(ArrayProc.DEST.A1i, i_array, 16);
                // -------------------------------

                // run a single compute_rb instruction
                /*ArrayProc.SOURCE src = ArrayProc.SOURCE.A0;
                if(rp.coin_flip(2)) src = ArrayProc.SOURCE.A1;
                ArrayProc.DEST dest = ArrayProc.DEST.B0;
                if(rp.coin_flip(2)) dest = ArrayProc.DEST.B1;
                dest_start = rp.rand_int(0, N2 - c0_length);
                int mu_k = rp.rand_int(int.MaxValue / 512, int.MaxValue);*/

                // -------------------------------
                ArrayProc.SOURCE src = ArrayProc.SOURCE.A1;
                ArrayProc.DEST dest = ArrayProc.DEST.B0;
                dest_start = c0_start;
                int mu_k = 0x40000000;
                // -------------------------------

                test_input += "Compute Rb test # " + i + " src=" + src
                        + " dest=" + dest + " c0_length=" + c0_length
                        + " c0_start=" + c0_start + " dest_start=" + dest_start
                        + " mu_k=" + mu_k + "\r\n";

                ap_cs.compute_Rb(src, dest, c0_length, c0_start, dest_start, mu_k);
                ap_fpga.compute_Rb(src, dest, c0_length, c0_start, dest_start, mu_k);

                bool result = memory_check(0);
                if (result == false) return false;
            }
            return true;
        }

        /// <summary>
        /// Tests the 32 point FFT routines. Do it "n" times.
        /// The tolerance of this test is set to 1.
        /// </summary>
        public bool fft32_test(int n)
        {
            clear_text();
            if (test_echo() == false) return false;

            test_input = ""; expected_output = ""; nios2_output = ""; comparison = "";
            for (int i = 0; i < n; i++)
            {
                // re-initiate all memory every tests
                test_input += "Initializing memory buffers \r\n";
                if (initialize_memory(256) == false) return false;

                int inverse = 0;
                if (rp.coin_flip(2)) inverse = 1;
                int source = 4; // source = 4 for memA, or 0xE for memB
                if (rp.coin_flip(2)) source = 0xE;
                int fft_shift = rp.rand_int(0, 3); // returns 0 or 1 or 2
                if (fft_shift == 2) fft_shift = 3; // fft_shift = {0, 1, 3}

                string source_str = "A";
                if (source != 4) source_str = "B";
                test_input += "FFT32 test # " + i + " inverse=" + inverse
                        + " source=" + source_str + " fft_shift=" + fft_shift
                        + "\r\n";

                if (inverse == 0)
                {
                    if (source == 4) ap_cs.FFT32_A2A(fft_shift);
                    else ap_cs.FFT32_B2B(fft_shift);
                }
                else
                {
                    if (source == 4) ap_cs.iFFT32_A2A(fft_shift);
                    else ap_cs.iFFT32_B2B(fft_shift);
                }

                ap_fpga.FFT32(source, inverse, fft_shift);
                // as a side effect, the ap_cs will clear the intermediate buffer
                if (source == 4) ap_fpga.reset_memory(ArrayProc.DEST.B0_1, 0, 16);
                else ap_fpga.reset_memory(ArrayProc.DEST.A0_1, 0, 16);

                bool result = memory_check(1); // NOTE tolerance = 1
                if (result == false) return false;
            }
            return true;
        }

        /// <summary>
        /// Tests the 32 point FFT routines using same data set as ModelSim.
        /// The tolerance of this test is set to 1.
        /// </summary>
        public bool fft32_test_ms()
        {
            clear_text();
            if (test_echo() == false) return false;

            int n = 1;
            test_input = ""; expected_output = ""; nios2_output = ""; comparison = "";
            for (int i = 0; i < n; i++)
            {
                // ModelSim data is -7, -6, ... 20, 1, 2, 3, 4
                ap_cs.reset_memory(ArrayProc.DEST.ALL_MEM, 0, 512);
                ap_fpga.reset_memory(ArrayProc.DEST.ALL_MEM, 0, 512);
                int[] i_array = new int[16];
                for (int j = 0; j < 16; j++) i_array[j] = j - 7;
                ap_cs.send_data(ArrayProc.DEST.A0r, i_array, 16);
                ap_fpga.send_data(ArrayProc.DEST.A0r, i_array, 16);

                for (int j = 16; j < 28; j++) i_array[j-16] = j - 7;
                for (int j = 28; j < 32; j++) i_array[j-16] = j - 27;
                ap_cs.send_data(ArrayProc.DEST.A1r, i_array, 16);
                ap_fpga.send_data(ArrayProc.DEST.A1r, i_array, 16);

                bool result = memory_check(0);
                if (result == false) return false;
                

                int inverse = 0;
                // if (rp.coin_flip(2)) inverse = 1;
                int source = 4; // source = 4 for memA, or 0xE for memB
                // if (rp.coin_flip(2)) source = 0xE;
                int fft_shift = 0;
                //int fft_shift = rp.rand_int(0, 3); // returns 0 or 1 or 2
                //if (fft_shift == 2) fft_shift = 3;

                string source_str = "A";
                if (source != 4) source_str = "B";
                test_input += "FFT32 test # " + i + " inverse=" + inverse
                        + " source=" + source_str + " fft_shift=" + fft_shift
                        + "\r\n";

                ap_cs.FFT32_A2A(fft_shift);

                ap_fpga.FFT32(source, inverse, fft_shift);
                // as a side effect, the ap_cs will clear the intermediate buffer
                ap_fpga.reset_memory(ArrayProc.DEST.B0_1, 0, 16);

                result = memory_check(1); // NOTE tolerance is set to 1
                if (result == false) return false;
            }
            return true;
        }

        /// <summary>
        /// Tests the 512 point FFT routines. Do it "n" times.
        /// The tolerance of this test is set to 16.
        /// </summary>
        public bool fft512_test(int n)
        {
            clear_text();
            if (test_echo() == false) return false;

            test_input = ""; expected_output = ""; nios2_output = ""; comparison = "";
            for (int i = 0; i < n; i++)
            {
                // re-initiate all memory every tests
                test_input += "Initializing memory buffers \r\n";
                if (initialize_memory(1024) == false) return false;

                int inverse = 0;
                if (rp.coin_flip(2)) inverse = 1;
                int source = 4; // source = 4 for memA, or 0xE for memB
                if (rp.coin_flip(2)) source = 0xE;
                int fft_shift = rp.rand_int(0, 3); // returns 0 or 1 or 2
                if (fft_shift == 2) fft_shift = 3; // fft_shift = {0, 1, 3}

                string source_str = "A";
                if (source != 4) source_str = "B";
                test_input += "FFT32 test # " + i + " inverse=" + inverse
                        + " source=" + source_str + " fft_shift=" + fft_shift
                        + "\r\n";

                if (inverse == 0)
                {
                    if (source == 4) ap_cs.FFT512_A2A(fft_shift);
                    else ap_cs.FFT512_B2B(fft_shift);
                }
                else
                {
                    if (source == 4) ap_cs.iFFT512_A2A(fft_shift);
                    else ap_cs.iFFT512_B2B(fft_shift);
                }

                ap_fpga.FFT512(source, inverse, fft_shift);
                // as a side effect, the ap_cs will clear the intermediate buffer
                if (source == 4) ap_fpga.reset_memory(ArrayProc.DEST.B0_1, 0, 256);
                else ap_fpga.reset_memory(ArrayProc.DEST.A0_1, 0, 256);

                bool result = memory_check(16); // NOTE tolerance = 16
                if (result == false) return false;
            }
            return true;
        }

        /// <summary>
        /// Tests the 512 point FFT routines using a fixed set of data.
        /// The tolerance of this test is set to 2.
        /// </summary>
        public bool fft512_test_fixed()
        {
            clear_text();
            if (test_echo() == false) return false;

            int n = 1;
            test_input = ""; expected_output = ""; nios2_output = ""; comparison = "";
            for (int i = 0; i < n; i++)
            {
                ap_cs.reset_memory(ArrayProc.DEST.ALL_MEM, 0, 512);
                ap_fpga.reset_memory(ArrayProc.DEST.ALL_MEM, 0, 512);
                int[] i_array = new int[256];
                // let i_array = {-128, ... +127} for A0r
                for (int j = 0; j < 256; j++) i_array[j] = j - 128;
                ap_cs.send_data(ArrayProc.DEST.A0r, i_array, 256);
                ap_fpga.send_data(ArrayProc.DEST.A0r, i_array, 256);
                
                // let i_array = {-128, ... +127} for A1r
                ap_cs.send_data(ArrayProc.DEST.A1r, i_array, 256);
                ap_fpga.send_data(ArrayProc.DEST.A1r, i_array, 256);

                bool result = memory_check(0);
                if (result == false) return false;

                int inverse = 0;
                //if (rp.coin_flip(2)) inverse = 1;
                int source = 4; // source = 4 for memA, or 0xE for memB
                //if (rp.coin_flip(2)) source = 0xE;
                int fft_shift = 1;
                //int fft_shift = rp.rand_int(0, 3); // returns 0 or 1 or 2
                if (fft_shift == 2) fft_shift = 3; // fft_shift = {0, 1, 3}

                string source_str = "A";
                if (source != 4) source_str = "B";
                test_input += "FFT32 test # " + i + " inverse=" + inverse
                        + " source=" + source_str + " fft_shift=" + fft_shift
                        + "\r\n";

                if (inverse == 0)
                {
                    if (source == 4) ap_cs.FFT512_A2A(fft_shift);
                    else ap_cs.FFT512_B2B(fft_shift);
                }
                else
                {
                    if (source == 4) ap_cs.iFFT512_A2A(fft_shift);
                    else ap_cs.iFFT512_B2B(fft_shift);
                }

                ap_fpga.FFT512(source, inverse, fft_shift);
                // as a side effect, the ap_cs will clear the intermediate buffer
                if (source == 4) ap_fpga.reset_memory(ArrayProc.DEST.B0_1, 0, 256);
                else ap_fpga.reset_memory(ArrayProc.DEST.A0_1, 0, 256);

                result = memory_check(2); // NOTE tolerance = 2
                if (result == false) return false;
            }
            return true;
        }

        /// <summary>
        /// Tests the SSRAM linear read and write instructions by copying from
        /// on chip memory to SSRAM, then form SSRAM to on chip memory. Do this
        /// "n" times.
        /// </summary>
        public bool ssram_linear_test(int n)
        {
            clear_text();
            if (test_echo() == false) return false;

            test_input = ""; expected_output = ""; nios2_output = ""; comparison = "";
            for (int i = 0; i < n; i++)
            {
                // re-initiate all memory every 3 tests
                if (i % 3 == 0)
                {
                    test_input += "Initializing memory buffers \r\n";
                    if (initialize_memory(1) == false) return false;
                }

                int addr = rp.rand_int(0, ap_cs.ssram_size - N2);
                int length, src_start, dest_start;
                rp.rand_length_start(out length, out src_start, out dest_start);
                ArrayProc.SOURCE src = rp.rand_source();
                ArrayProc.DEST dest = rp.rand_dest();
                int imag = 0;
                if(rp.coin_flip(2)) imag = 1;

                test_input += "SSRAM linear test # " + i + " addr=" + addr
                        + " imag=" + imag
                        + " src=" + src + " dest=" + dest + " length=" + length
                        + " src_start=" + src_start + " dest_start=" + dest_start
                        + "\r\n";

                // copy from onchip memory to ssram
                ap_fpga.ssram_set_addr(addr);
                ap_fpga.ssram_set_skip(1);
                ap_fpga.ssram_set_highest_addr(ap_cs.ssram_size - 1);
                ap_fpga.ssram_set_block_size(ap_cs.ssram_size - 1);
                ap_fpga.ssram_write(src, imag, length, src_start);                
                //copy from ssram to onchip memory
                ap_fpga.ssram_set_addr(addr);
                ap_fpga.ssram_read(dest, length, dest_start);

                // equivalent commands applied to the software model:
                ap_cs.ssram_set_addr(addr);
                ap_cs.ssram_set_skip(1);
                ap_cs.ssram_set_highest_addr(ap_cs.ssram_size - 1);
                ap_cs.ssram_set_block_size(ap_cs.ssram_size - 1);
                ap_cs.ssram_write(src, imag, length, src_start);
                ap_cs.ssram_set_addr(addr);
                ap_cs.ssram_read(dest, length, dest_start);
                
                bool result = memory_check(0);
                if (result == false) return false;
            }
            return true;
        }

        /// <summary>
        /// Tests the SSRAM reset instruction by copying from
        /// on chip memory to SSRAM, reset part of SSRAM, then copy this back to
        /// to on chip memory. Do this "n" times. This test is similar to the linear
        /// test, except that the onchip memory buffer (N2 long) is always entirely
        /// copied to the SSRAM, and part of that is reset.
        /// </summary>
        public bool ssram_reset_test(int n)
        {
            clear_text();
            if (test_echo() == false) return false;

            test_input = ""; expected_output = ""; nios2_output = ""; comparison = "";
            for (int i = 0; i < n; i++)
            {
                // re-initiate all memory every 3 tests
                if (i % 3 == 0)
                {
                    test_input += "Initializing memory buffers \r\n";
                    if (initialize_memory(1) == false) return false;
                }

                int addr = rp.rand_int(0, ap_cs.ssram_size - N2);
                int reset_length, reset_start, dest_start;
                rp.rand_length_start(out reset_length, out reset_start, out dest_start);
                ArrayProc.SOURCE src = rp.rand_source();
                ArrayProc.DEST dest = rp.rand_dest();
                int imag = 0;
                if (rp.coin_flip(2)) imag = 1;

                test_input += "SSRAM reset test # " + i + " addr=" + addr
                        + " imag=" + imag + " src=" + src 
                        + " dest=" + dest + " reset length=" + reset_length
                        + " reset_start=" + reset_start + "\r\n";

                // copy from onchip memory to ssram
                ap_fpga.ssram_set_addr(addr);
                ap_fpga.ssram_set_skip(1);
                ap_fpga.ssram_set_highest_addr(ap_cs.ssram_size - 1);
                ap_fpga.ssram_set_block_size(ap_cs.ssram_size - 1);
                ap_fpga.ssram_write(src, imag, N2, 0);
                // reset a segment of ssram memory
                ap_fpga.ssram_set_addr(addr + reset_start);
                ap_fpga.ssram_reset(reset_length);
                // copy from ssram to onchip memory
                ap_fpga.ssram_set_addr(addr);
                ap_fpga.ssram_read(dest, N2, 0);

                // equivalent commands applied to the software model:
                ap_cs.ssram_set_addr(addr);
                ap_cs.ssram_set_skip(1);
                ap_cs.ssram_set_highest_addr(ap_cs.ssram_size - 1);
                ap_cs.ssram_set_block_size(ap_cs.ssram_size - 1);
                ap_cs.ssram_write(src, imag, N2, 0);
                ap_cs.ssram_set_addr(addr + reset_start);
                ap_cs.ssram_reset(reset_length);
                ap_cs.ssram_set_addr(addr);
                ap_cs.ssram_read(dest, N2, 0);

                bool result = memory_check(0);
                if (result == false) return false;
            }
            return true;
        }

        /// <summary>
        /// Tests the circular buffer reading capability of the SSRAM. The onchip memory
        /// data A0, A1, B0, are copied to the SSRAM. This data is read back into B1 as
        /// a circular buffer data.
        /// </summary>
        public bool ssram_circular_read_test(int n)
        {
            clear_text();
            if (test_echo() == false) return false;

            test_input = ""; expected_output = ""; nios2_output = ""; comparison = "";
            for (int i = 0; i < n; i++)
            {
                // re-initiate all memory tests
                test_input += "Initializing memory buffers \r\n";
                if (initialize_memory(1) == false) return false;

                /*int addr = 21644;
                int cir_start = 157;                
                int cir_skip = 128;*/
                int addr = rp.rand_int(0, ap_cs.ssram_size - N2 * 3 * 2);
                int cir_start = rp.rand_int(0, N2);
                int cir_skip = rp.rand_int(1, 257); // skip = {1, 2, ... 256}

                test_input += "SSRAM circular test # " + i + " addr=" + addr
                        + " cir_start=" + cir_start + " cir_skip=" + cir_skip
                        + "\r\n";

                // copy from onchip memory to ssram
                ap_fpga.ssram_set_addr(addr);
                ap_fpga.ssram_set_skip(1);
                ap_fpga.ssram_set_highest_addr(ap_cs.ssram_size - 1);
                ap_fpga.ssram_set_block_size(ap_cs.ssram_size - 1);
                ap_fpga.ssram_write(ArrayProc.SOURCE.A0, 0, N2, 0);
                ap_fpga.ssram_set_addr(addr + N2);
                ap_fpga.ssram_write(ArrayProc.SOURCE.A1, 0, N2, 0);
                ap_fpga.ssram_set_addr(addr + 2 * N2);
                ap_fpga.ssram_write(ArrayProc.SOURCE.B0, 0, N2, 0);
                ap_fpga.ssram_set_addr(addr + 3 * N2);
                ap_fpga.ssram_write(ArrayProc.SOURCE.A0, 1, N2, 0);
                ap_fpga.ssram_set_addr(addr + 4 * N2);
                ap_fpga.ssram_write(ArrayProc.SOURCE.A1, 1, N2, 0);
                ap_fpga.ssram_set_addr(addr + 5 * N2);
                ap_fpga.ssram_write(ArrayProc.SOURCE.B0, 1, N2, 0);
                // read back real part
                ap_fpga.ssram_set_addr(addr + cir_start);
                ap_fpga.ssram_set_skip(cir_skip);
                ap_fpga.ssram_set_highest_addr(addr + N2 * 3 - 1);
                ap_fpga.ssram_set_block_size(N2 * 3 - cir_skip);
                ap_fpga.ssram_read(ArrayProc.DEST.B1r, N2, 0);
                // read back imaginary part
                ap_fpga.ssram_set_addr(addr + N2 * 3 + cir_start);
                ap_fpga.ssram_set_highest_addr(addr + N2 * 6 - 1);
                ap_fpga.ssram_read(ArrayProc.DEST.B1i, N2, 0);

                // equivalent commands applied to the software model:
                ap_cs.ssram_set_addr(addr);
                ap_cs.ssram_set_skip(1);
                ap_cs.ssram_set_highest_addr(ap_cs.ssram_size - 1);
                ap_cs.ssram_set_block_size(ap_cs.ssram_size - 1);
                ap_cs.ssram_write(ArrayProc.SOURCE.A0, 0, N2, 0);
                ap_cs.ssram_set_addr(addr + N2);
                ap_cs.ssram_write(ArrayProc.SOURCE.A1, 0, N2, 0);
                ap_cs.ssram_set_addr(addr + 2 * N2);
                ap_cs.ssram_write(ArrayProc.SOURCE.B0, 0, N2, 0);
                ap_cs.ssram_set_addr(addr + 3 * N2);
                ap_cs.ssram_write(ArrayProc.SOURCE.A0, 1, N2, 0);
                ap_cs.ssram_set_addr(addr + 4 * N2);
                ap_cs.ssram_write(ArrayProc.SOURCE.A1, 1, N2, 0);
                ap_cs.ssram_set_addr(addr + 5 * N2);
                ap_cs.ssram_write(ArrayProc.SOURCE.B0, 1, N2, 0);
                // read back real part
                ap_cs.ssram_set_addr(addr + cir_start);
                ap_cs.ssram_set_skip(cir_skip);
                ap_cs.ssram_set_highest_addr(addr + N2 * 3 - 1);
                ap_cs.ssram_set_block_size(N2 * 3 - cir_skip);
                ap_cs.ssram_read(ArrayProc.DEST.B1r, N2, 0);
                // read back imaginary part
                ap_cs.ssram_set_addr(addr + N2 * 3 + cir_start);
                ap_cs.ssram_set_highest_addr(addr + N2 * 6 - 1);
                ap_cs.ssram_read(ArrayProc.DEST.B1i, N2, 0);

                bool result = memory_check(0);
                if (result == false) return false;
            }
            return true;
        }

        #endregion

        #region Helper Functions
        private void clear_text()
        {
            test_input = ""; expected_output = ""; nios2_output = ""; comparison = "";
        }

        /// <summary>
        /// Formats an array for printing.
        /// </summary>
        private string format_array_data(int[] i_array, string array_name, int start_index)
        {
            var sb = new StringBuilder();
            for (int i = 0; i < i_array.Length; i++)
                sb.Append(array_name + "[" + (start_index + i) + "] = " 
                        + i_array[i].ToString() + "\r\n");
            return sb.ToString();
        }

        /// <summary>
        /// Formats two arrays, one actual output, one expected output, for viewing.
        /// </summary>
        private string format_array_data(int[] actual_array, int[] exp_array, 
                string array_name, int start_index)
        {
            if (actual_array.Length != exp_array.Length) 
                return "The length of the actual array doesn't match "
                    + "the length of the expected array\r\n";
            var sb = new StringBuilder();
            sb.Append("\tActual \t Expected\r\n");
            for (int i = 0; i < actual_array.Length; i++)
                sb.Append(array_name + "[" + (start_index + i) + "] = \t"
                    + actual_array[i].ToString() + " \t" + exp_array[i].ToString() + "\r\n");
            return sb.ToString();
        }

        /// <summary>
        /// Initialize memory of ap_fpga and ap_cs, making the two equal.
        /// </summary>
        private bool initialize_memory(int divisor)
        {
            for (int i = 4; i < 12; i++)
            {
                int[] i_array;
                i_array = rp.rand_array(N2, Int32.MinValue / divisor, Int32.MaxValue / divisor);
                ap_fpga.send_data((ArrayProc.DEST)i, i_array, N2);
                ap_cs.send_data((ArrayProc.DEST)i, i_array, N2);
            }

            bool result = memory_check(0);
            return result;
        }

        /// <summary>
        /// Create one array and copy it to all memories, and then check.
        /// </summary>
        private bool initialize_memory_all_same()
        {
            int[] i_array = rp.rand_array(N2, Int32.MinValue, Int32.MaxValue);
            ap_fpga.send_data(ArrayProc.DEST.ALL_MEM, i_array, N2);
            ap_cs.send_data(ArrayProc.DEST.ALL_MEM, i_array, N2);

            bool result = memory_check(0);
            return result;
        }

        /// <summary>
        /// Read all buffers from the real array processor "ap_fpga" and compare with
        /// the content in the model array processor "ap_cs".
        /// </summary>
        private bool memory_check(int tolerance)
        {
            for (int i = 0; i < 4; i++)
            {
                for (int j = 1; j >= 0; j--)
                {
                    // for now the result FIFO is only 256 values max, so the full buffer
                    // has to be obtained in two reads
                    int[] i_array1a = ap_fpga.get_data((ArrayProc.SOURCE)i, j, 0, N);
                    int[] i_array1b = ap_fpga.get_data((ArrayProc.SOURCE)i, j, N, N);
                    if (i_array1a == null || i_array1b == null)
                    {
                        nios2_output += "Failed to retrieve array \r\n";
                        return false;
                    }
                    int[] i_array1 = new int[N2];
                    for (int k = 0; k < i_array1a.Length; k++)
                    {
                        i_array1[k] = i_array1a[k];
                        i_array1[N + k] = i_array1b[k];
                    }
                    int[] i_array2 = ap_cs.get_data((ArrayProc.SOURCE)i, j, 0, N2);                    
                    for (int k = 0; k < i_array1.Length; k++)
                    {
                        if (i_array1[k] - i_array2[k] > tolerance ||
                                i_array2[k] - i_array1[k] > tolerance)
                        {
                            string array_name = ((ArrayProc.SOURCE)i).ToString();
                            if (j == 0) array_name += ".imag";
                            else array_name += "real";
                            nios2_output += format_array_data(i_array1, array_name, 0) + "\r\n";
                            expected_output += format_array_data(i_array2, array_name, 0) + "\r\n";
                            comparison += "Test failed at element " + k + "\r\n";
                            return false;
                        }
                    }
                }
            }            
            return true;
        }

        /// <summary>
        /// Sends a 0 to the board and expect a reply of 0.
        /// </summary>
        private bool test_echo()
        {
            if (ap_fpga.echo() == false)
            {
                test_input = "No echo \r\n";
                return false;
            }
            return true;
        }
        #endregion
    }
}
