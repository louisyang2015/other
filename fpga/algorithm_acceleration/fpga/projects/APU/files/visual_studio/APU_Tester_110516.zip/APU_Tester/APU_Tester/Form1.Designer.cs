﻿namespace APU_Tester
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.Test_listBox = new System.Windows.Forms.ListBox();
            this.RandomTest_button = new System.Windows.Forms.Button();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.Input_tabPage = new System.Windows.Forms.TabPage();
            this.Input_textBox = new System.Windows.Forms.TextBox();
            this.EOutput_tabPage = new System.Windows.Forms.TabPage();
            this.EOutput_textBox = new System.Windows.Forms.TextBox();
            this.NOutput_tabPage = new System.Windows.Forms.TabPage();
            this.NOutput_textBox = new System.Windows.Forms.TextBox();
            this.Compare_tabPage = new System.Windows.Forms.TabPage();
            this.Compare_textBox = new System.Windows.Forms.TextBox();
            this.Nios2_Watch_tabPage = new System.Windows.Forms.TabPage();
            this.Source_comboBox = new System.Windows.Forms.ComboBox();
            this.NIOS2_data_textBox = new System.Windows.Forms.TextBox();
            this.Dump_button = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.Input_tabPage.SuspendLayout();
            this.EOutput_tabPage.SuspendLayout();
            this.NOutput_tabPage.SuspendLayout();
            this.Compare_tabPage.SuspendLayout();
            this.Nios2_Watch_tabPage.SuspendLayout();
            this.SuspendLayout();
            // 
            // splitContainer1
            // 
            this.splitContainer1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(0, 0);
            this.splitContainer1.Margin = new System.Windows.Forms.Padding(4);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.Test_listBox);
            this.splitContainer1.Panel1.Controls.Add(this.RandomTest_button);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.tabControl1);
            this.splitContainer1.Size = new System.Drawing.Size(880, 614);
            this.splitContainer1.SplitterDistance = 292;
            this.splitContainer1.SplitterWidth = 7;
            this.splitContainer1.TabIndex = 0;
            // 
            // Test_listBox
            // 
            this.Test_listBox.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.Test_listBox.FormattingEnabled = true;
            this.Test_listBox.ItemHeight = 25;
            this.Test_listBox.Items.AddRange(new object[] {
            "send and get",
            "copy",
            "memory reset",
            "add array",
            "MAC",
            "conjugate mirror",
            "compute Rb",
            "FFT 32",
            "FFT 512",
            "ssram linear",
            "ssram reset",
            "ssram circular read"});
            this.Test_listBox.Location = new System.Drawing.Point(11, 11);
            this.Test_listBox.Name = "Test_listBox";
            this.Test_listBox.Size = new System.Drawing.Size(262, 504);
            this.Test_listBox.TabIndex = 3;
            // 
            // RandomTest_button
            // 
            this.RandomTest_button.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.RandomTest_button.Location = new System.Drawing.Point(11, 544);
            this.RandomTest_button.Margin = new System.Windows.Forms.Padding(4);
            this.RandomTest_button.Name = "RandomTest_button";
            this.RandomTest_button.Size = new System.Drawing.Size(98, 62);
            this.RandomTest_button.TabIndex = 2;
            this.RandomTest_button.Text = "Random Test";
            this.RandomTest_button.UseVisualStyleBackColor = true;
            this.RandomTest_button.Click += new System.EventHandler(this.RandomTest_button_Click);
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.Input_tabPage);
            this.tabControl1.Controls.Add(this.EOutput_tabPage);
            this.tabControl1.Controls.Add(this.NOutput_tabPage);
            this.tabControl1.Controls.Add(this.Compare_tabPage);
            this.tabControl1.Controls.Add(this.Nios2_Watch_tabPage);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Margin = new System.Windows.Forms.Padding(4);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(577, 610);
            this.tabControl1.TabIndex = 0;
            // 
            // Input_tabPage
            // 
            this.Input_tabPage.Controls.Add(this.Input_textBox);
            this.Input_tabPage.Location = new System.Drawing.Point(4, 34);
            this.Input_tabPage.Margin = new System.Windows.Forms.Padding(4);
            this.Input_tabPage.Name = "Input_tabPage";
            this.Input_tabPage.Padding = new System.Windows.Forms.Padding(4);
            this.Input_tabPage.Size = new System.Drawing.Size(569, 572);
            this.Input_tabPage.TabIndex = 0;
            this.Input_tabPage.Text = "Input";
            this.Input_tabPage.UseVisualStyleBackColor = true;
            // 
            // Input_textBox
            // 
            this.Input_textBox.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.Input_textBox.Location = new System.Drawing.Point(7, 7);
            this.Input_textBox.Multiline = true;
            this.Input_textBox.Name = "Input_textBox";
            this.Input_textBox.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.Input_textBox.Size = new System.Drawing.Size(555, 558);
            this.Input_textBox.TabIndex = 0;
            // 
            // EOutput_tabPage
            // 
            this.EOutput_tabPage.Controls.Add(this.EOutput_textBox);
            this.EOutput_tabPage.Location = new System.Drawing.Point(4, 29);
            this.EOutput_tabPage.Margin = new System.Windows.Forms.Padding(4);
            this.EOutput_tabPage.Name = "EOutput_tabPage";
            this.EOutput_tabPage.Padding = new System.Windows.Forms.Padding(4);
            this.EOutput_tabPage.Size = new System.Drawing.Size(569, 577);
            this.EOutput_tabPage.TabIndex = 1;
            this.EOutput_tabPage.Text = "Expected Output";
            this.EOutput_tabPage.UseVisualStyleBackColor = true;
            // 
            // EOutput_textBox
            // 
            this.EOutput_textBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.EOutput_textBox.Location = new System.Drawing.Point(4, 4);
            this.EOutput_textBox.Multiline = true;
            this.EOutput_textBox.Name = "EOutput_textBox";
            this.EOutput_textBox.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.EOutput_textBox.Size = new System.Drawing.Size(561, 569);
            this.EOutput_textBox.TabIndex = 0;
            // 
            // NOutput_tabPage
            // 
            this.NOutput_tabPage.Controls.Add(this.NOutput_textBox);
            this.NOutput_tabPage.Location = new System.Drawing.Point(4, 29);
            this.NOutput_tabPage.Name = "NOutput_tabPage";
            this.NOutput_tabPage.Size = new System.Drawing.Size(569, 577);
            this.NOutput_tabPage.TabIndex = 2;
            this.NOutput_tabPage.Text = "NIOS 2 Output";
            this.NOutput_tabPage.UseVisualStyleBackColor = true;
            // 
            // NOutput_textBox
            // 
            this.NOutput_textBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.NOutput_textBox.Location = new System.Drawing.Point(0, 0);
            this.NOutput_textBox.Multiline = true;
            this.NOutput_textBox.Name = "NOutput_textBox";
            this.NOutput_textBox.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.NOutput_textBox.Size = new System.Drawing.Size(569, 577);
            this.NOutput_textBox.TabIndex = 0;
            // 
            // Compare_tabPage
            // 
            this.Compare_tabPage.Controls.Add(this.Compare_textBox);
            this.Compare_tabPage.Location = new System.Drawing.Point(4, 29);
            this.Compare_tabPage.Name = "Compare_tabPage";
            this.Compare_tabPage.Size = new System.Drawing.Size(569, 577);
            this.Compare_tabPage.TabIndex = 3;
            this.Compare_tabPage.Text = "Comparison";
            this.Compare_tabPage.UseVisualStyleBackColor = true;
            // 
            // Compare_textBox
            // 
            this.Compare_textBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Compare_textBox.Location = new System.Drawing.Point(0, 0);
            this.Compare_textBox.Multiline = true;
            this.Compare_textBox.Name = "Compare_textBox";
            this.Compare_textBox.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.Compare_textBox.Size = new System.Drawing.Size(569, 577);
            this.Compare_textBox.TabIndex = 0;
            // 
            // Nios2_Watch_tabPage
            // 
            this.Nios2_Watch_tabPage.Controls.Add(this.Source_comboBox);
            this.Nios2_Watch_tabPage.Controls.Add(this.NIOS2_data_textBox);
            this.Nios2_Watch_tabPage.Controls.Add(this.Dump_button);
            this.Nios2_Watch_tabPage.Location = new System.Drawing.Point(4, 29);
            this.Nios2_Watch_tabPage.Name = "Nios2_Watch_tabPage";
            this.Nios2_Watch_tabPage.Size = new System.Drawing.Size(569, 577);
            this.Nios2_Watch_tabPage.TabIndex = 4;
            this.Nios2_Watch_tabPage.Text = "NIOS Watch";
            this.Nios2_Watch_tabPage.UseVisualStyleBackColor = true;
            // 
            // Source_comboBox
            // 
            this.Source_comboBox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.Source_comboBox.FormattingEnabled = true;
            this.Source_comboBox.Items.AddRange(new object[] {
            "A0r",
            "A0i",
            "A1r",
            "A1i",
            "B0r",
            "B0i",
            "B1r",
            "B1i"});
            this.Source_comboBox.Location = new System.Drawing.Point(15, 17);
            this.Source_comboBox.Name = "Source_comboBox";
            this.Source_comboBox.Size = new System.Drawing.Size(441, 33);
            this.Source_comboBox.TabIndex = 2;
            // 
            // NIOS2_data_textBox
            // 
            this.NIOS2_data_textBox.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.NIOS2_data_textBox.Location = new System.Drawing.Point(15, 73);
            this.NIOS2_data_textBox.Multiline = true;
            this.NIOS2_data_textBox.Name = "NIOS2_data_textBox";
            this.NIOS2_data_textBox.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.NIOS2_data_textBox.Size = new System.Drawing.Size(537, 480);
            this.NIOS2_data_textBox.TabIndex = 1;
            // 
            // Dump_button
            // 
            this.Dump_button.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Dump_button.Location = new System.Drawing.Point(477, 12);
            this.Dump_button.Name = "Dump_button";
            this.Dump_button.Size = new System.Drawing.Size(75, 40);
            this.Dump_button.TabIndex = 0;
            this.Dump_button.Text = "Dump";
            this.Dump_button.UseVisualStyleBackColor = true;
            this.Dump_button.Click += new System.EventHandler(this.Dump_button_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(880, 614);
            this.Controls.Add(this.splitContainer1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Form1";
            this.Text = "APU Tester";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.tabControl1.ResumeLayout(false);
            this.Input_tabPage.ResumeLayout(false);
            this.Input_tabPage.PerformLayout();
            this.EOutput_tabPage.ResumeLayout(false);
            this.EOutput_tabPage.PerformLayout();
            this.NOutput_tabPage.ResumeLayout(false);
            this.NOutput_tabPage.PerformLayout();
            this.Compare_tabPage.ResumeLayout(false);
            this.Compare_tabPage.PerformLayout();
            this.Nios2_Watch_tabPage.ResumeLayout(false);
            this.Nios2_Watch_tabPage.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.Button RandomTest_button;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage Input_tabPage;
        private System.Windows.Forms.TabPage EOutput_tabPage;
        private System.Windows.Forms.TabPage NOutput_tabPage;
        private System.Windows.Forms.TabPage Compare_tabPage;
        private System.Windows.Forms.ListBox Test_listBox;
        private System.Windows.Forms.TextBox Input_textBox;
        private System.Windows.Forms.TextBox EOutput_textBox;
        private System.Windows.Forms.TextBox NOutput_textBox;
        private System.Windows.Forms.TextBox Compare_textBox;
        private System.Windows.Forms.TabPage Nios2_Watch_tabPage;
        private System.Windows.Forms.ComboBox Source_comboBox;
        private System.Windows.Forms.TextBox NIOS2_data_textBox;
        private System.Windows.Forms.Button Dump_button;
    }
}

