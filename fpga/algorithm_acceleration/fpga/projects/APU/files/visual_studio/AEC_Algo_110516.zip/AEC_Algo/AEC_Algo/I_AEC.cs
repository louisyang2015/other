﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AEC_Algo
{
    interface I_AEC
    {
        //N value and functions for the AEC algorithm
        int N_Val { get; }
        void aec_init();
        void aec(int[] dn, int[] xn, int[] output);

        //Further algorithm information
        Histogram[] Histo_array { get; }
        MyGraph[] Graphs { get; }
        void aec_end();
    }
}
