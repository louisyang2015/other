﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.Numerics;

namespace AEC_Algo
{
    /// <summary>
    /// This is part 4 of the FPGA port. This port fix the Wei[,]
    /// matrix size mistake that's been present since the very original
    /// AEC32 C# port. Other than the size fix, this port is just 
    /// a cleaned up version of port #3. Port #3 was not 
    /// cleaned up because it turned out to be quite hard. Debugging
    /// it relied on having the code from port #2 runnin simultaneous
    /// to port #3's new code, so that during debugging, the AEC is
    /// run twice, and the intermediate from the two runs are compared
    /// for deubg. This parallel running is deemed valuable and will
    /// be kept for reference.
    /// </summary>
    class AEC32_FPGA_port4 : I_AEC
    {
        #region Parameters
        // Set simulation parameters
        const int L = 2048 * 2; //16kHz: 2048
        const int M = 16;
        const int N = (L / M);
        const int N2 = N * 2;

        // Set parameters for DTD
        const float lam_s = 0.9995f;
        const float lam_f = 0.99f;
        const float lam_p = 0.92f;

        // Set adaptation parameters
        // const float mu1 = 0.015625f;	    // 2^(-6)
        // const float mu2 = 0.03125f;		// 2^(-5)
        const int mu1 = 33554432; // mu1 / 2^(-31)
        const int mu2 = 67108864; // mu2 / 2^(-31)
        const int nd = 0;

        // Set Threshold
        const float pwr_th = 0.025f;
        #endregion

        #region Variables
        // Time domain data buffer
        int[] xb = new int[N];
        int[] yp = new int[N];
        int[] ep = new int[N];

        // Frequency domain data buffer
        int[] ssram = new int[(M * (N + 1) + (M + 3 + nd + 1) * (N + 1) + (M + nd + 1) * (N + 1)) * 2];
        //Complex[,] Wei = new Complex[M, N + 1];
        //Complex[,] Xb = new Complex[M + 3 + nd + 1, N + 1];
        //Complex[,] Eb = new Complex[M + nd + 1, N + 1];       

        int p_start;
        float pwr, pe, ps;

        int init_blk_cnt;
        short Const_index;
        int index;

        //--------------------------------------------------------
        // For FPGA port:
        // Xb and Eb zero location
        int Xb_offset, Eb_offset;        
        int Xb_index, Eb_index; //real index = Xb_offset + for loop index
        
        // locations of the 2D arrays in "ssram"
        // Complex[,] Wei = new Complex[M, N + 1];
        // Complex[,] Xb = new Complex[M + 3 + nd + 1, N + 1];
        // Complex[,] Eb = new Complex[M + nd + 1, N + 1];
        const int Wei_base = 0;
        const int Xb_base = M * (N + 1) * 2;
        const int Eb_base = M * (N + 1) * 2 + (M + 3 + nd + 1) * (N + 1) * 2;  
      
        const int XB_NUM_ROWS = M + 3 + nd + 1;
        const int EB_NUM_ROWS = M + nd + 1;
        const int WEI_NUM_COLS = N + 1;
        const int XB_NUM_COLS = N + 1;
        const int EB_NUM_COLS = N + 1;
        const int XB_BLOCK_SIZE = (M + 3 + nd + 1) * (N + 1);

        ArrayProc ap = new ArrayProc();

        const int INT16_MAX = 32767;
        const int INT16_MIN = -32767;
        const long INT32_MAX = 2147483647;
        const long INT32_MIN = -2147483647;

        public int N_Val
        {
            get { return N; }
        }

        public Histogram[] Histo_array
        {
            get { return null; }
        }

        List<double> power_atten; //power of output[n] / x[n] for a particular frame
        MyGraph[] output_graphs;
        public MyGraph[] Graphs
        {
            get { return output_graphs; }
        }
        #endregion

        #region Etri Functions
        /// <summary>
        /// Initialize data buffers
        /// </summary>
        public void aec_init()
        {
            int k;
            
            for (k = 0; k < ssram.Length; k++)
                ssram[k] = 0;
            p_start = 0;
            pe = 0;
            ps = 0;
            init_blk_cnt = 0;
            Const_index = -1;

            index = -1; //originally done in main()
            power_atten = new List<double>(512);

            //additional variables for FPGA
            Xb_offset = 0;
            Eb_offset = 0;
            ap.init_param(M, N, N2, nd);
        }

        /// <summary>
        /// AEC function that process a single frame of data.
        /// </summary>
        public void aec(int[] dn, int[] xn, int[] output)
        {
            index++; //originally done in main()

            int i, k, m;
            Complex[] Rb = new Complex[N2];
            int mu, mu_k;            

            // Saturate xn[] and dn[]
            // For FPGA, only INT16_MIN, which is 100...000 needs to be checked
            for (i = 0; i < N; i++)
            {
                if (xn[i] > INT16_MAX) xn[i] = INT16_MAX;
                else if (xn[i] < INT16_MIN) xn[i] = INT16_MIN;
                if (dn[i] > INT16_MAX) dn[i] = INT16_MAX;
                else if (dn[i] < INT16_MIN) dn[i] = INT16_MIN;
            }

            //-------------------------------------------------------------
            // NIOS 2 --> data --> FPGA, Xc will be in memory B0 and B1
            // Xc[0~255] = xb[] <<16
            // Xc[256~512] = xn[] << 16
            ap.FIFO_IN = xb;
            ap.send_data(ArrayProc.DEST.B0, ArrayProc.DATA_TYPE.real_only, ArrayProc.SHIFT_TYPE.left16);
            ap.FIFO_IN = xn;
            ap.send_data(ArrayProc.DEST.B1, ArrayProc.DATA_TYPE.real_only, ArrayProc.SHIFT_TYPE.left16);
            //--------------------------------------------------------------

            //--------------------------------------------------------------
            // Xc FFT and bitshift
            ap.FFT512(ArrayProc.SOURCE.B0, ArrayProc.SHIFT_TYPE.right9, false);
            //--------------------------------------------------------------

            //--------------------------------------------------------------
            // Save xn[] as xb[] for use with next frame, no more use of
            // xb[] after this
            for (i = 0; i < N; i++) xb[i] = xn[i];
            //--------------------------------------------------------------

            //---------------------------------------------------------------------
            // The Xc, after computing FFT of Xc, store it in matrix Xb
            // in a circular buffer format. "Xb_offset" is the 0th
            // row of this circular buffer. 
            Xb_offset--;
            if (Xb_offset < 0) Xb_offset = Xb_offset + XB_NUM_ROWS;            
            ap.write_to_ssram(ArrayProc.SOURCE.B0, Xb_base + 2 * Xb_offset * XB_NUM_COLS, N);
            // Store Xc[0~255]
            ap.write_to_ssram(ArrayProc.SOURCE.B1, Xb_base + 2 * Xb_offset * XB_NUM_COLS + N * 2, 1);
            // Store Xc[256]
            //---------------------------------------------------------------------
            

            //---------------------------------------------------------------------
            // Compute Ys, which is later used to compute the output
            for (k = 0; k < N + 1; k++)
            {
                ap.read_ssram(ArrayProc.DEST.A0, Xb_base + Xb_offset * XB_NUM_COLS * 2 + k * 2,
                        M, XB_NUM_COLS, Xb_base + XB_BLOCK_SIZE * 2 - 1,
                        XB_BLOCK_SIZE * 2);
                ap.read_ssram(ArrayProc.DEST.A1, Wei_base + k * 2, M, WEI_NUM_COLS);
                // Xb buffer --> A0 and Wei buffer --> A1

                ap.mac(M, k);
            }
            // The Ys[] is now in memory B0

            //---------------------------------------------------------------------
            // Prepare Ys for inverse FFT:
            ap.copy_data(ArrayProc.SOURCE.B0, N, 1, ArrayProc.DEST.B1, 0, ArrayProc.DATA_TYPE.real_imag);
            // B0[N] (1 element only) copied to B1[0]
            ap.conjugate_mirror(ArrayProc.SOURCE.B0, 1, N - 1, N);
            // B1[256-k] = Complex.Conjugate(B0[k]), k = 1 to N-1


            //---------------------------------------------------------------------
            // YS --> inverse FFT and bit shift
            ap.FFT512(ArrayProc.SOURCE.B0, ArrayProc.SHIFT_TYPE.left9, true);     
            // At this point, Ys is in B0[0~255] and B1[0~255]

            //---------------------------------------------------------------------            
            // NIOS 2 will compute the "pwr" variable. It is the sum of |xn[i]|
            int pwr_int = 0;
            for (i = 0; i < N; i++)
            {
                if (xn[i] > 0) pwr_int += xn[i];
                else pwr_int -= xn[i];
            }
            pwr = (float)pwr_int / (INT16_MAX * N);

            //---------------------------------------------------------------------
            // NIOS 2 needs to read yp[i], which is Ys[256~511].Real
            ap.get_data(ArrayProc.SOURCE.B1, 0, N, ArrayProc.DATA_TYPE.real_only);
            yp = ap.FIFO_OUT;

            //---------------------------------------------------------------------
            // NIOS 2 will the error vector ep[i] and send it to the output            
            long ep_long; 
            for (i = 0; i < N; i++)
            {
                dn[i] = dn[i] << 16; //dn is now same as "dp" from this point onward

                //ep[i] = dp[i] - yp[i] :
                ep_long = dn[i] - yp[i];
                if (ep_long > INT32_MAX) ep[i] = (int)INT32_MAX;
                else if (ep_long < INT32_MIN) ep[i] = (int)INT32_MIN;
                else ep[i] = (int)ep_long;
            }

            //---------------------------------------------------------------------
            // NIOS 2 --> ep[] --> FPGA
            // Ec[0 ~ 255] = 0 --> B0
            // Ec[256 ~ 512] = ep[0 ~ 255] --> B1
            // Create Ec and do FFT
            ap.reset_memory(ArrayProc.DEST.B0, 0, N);
            ap.FIFO_IN = ep;
            ap.send_data(ArrayProc.DEST.B1, ArrayProc.DATA_TYPE.real_only, ArrayProc.SHIFT_TYPE.none);

            //---------------------------------------------------------------------
            // Do FFT on Ec, and bitshift
            ap.FFT512(ArrayProc.SOURCE.B0, ArrayProc.SHIFT_TYPE.right9, false);            

            //---------------------------------------------------------------------
            // Store Ec[] in matrix Eb. It is a circular buffer where 
            //  "Eb_offset" is the index of the 0th row.
            Eb_offset--; 
            if (Eb_offset < 0) Eb_offset += EB_NUM_ROWS;
            ap.write_to_ssram(ArrayProc.SOURCE.B0, Eb_base + Eb_offset * EB_NUM_COLS * 2, N);
            // Store Ec[0~255]
            ap.write_to_ssram(ArrayProc.SOURCE.B1, Eb_base + Eb_offset * EB_NUM_COLS * 2 + N * 2, 1);
            // Store Ec[256]

            //---------------------------------------------------------------------
            // Compute power of freq bins
            for (k = 0; k < N + 1; k++)
            {   
                ap.read_ssram(ArrayProc.DEST.A0, Xb_base + Xb_offset * XB_NUM_COLS * 2 + k * 2,
                        M + nd + 4, XB_NUM_COLS, Xb_base + XB_BLOCK_SIZE * 2 - 1,
                        XB_BLOCK_SIZE * 2); //Load Xb[,] ---> A0[]
                ap.compute_power(M + nd + 4, k); 
                // power is a single number stored at C0[k]
            }
            //Pi_int[k] is in C0 at this point
            
            //---------------------------------------------------------------------
            // Do the following in NIOS 2 - compute output, and compute power
            // use floating point for the power computations
            // Compute ps_c_array[i] = | dp[i]^2 - yp[i]^2 |
            // Compute pe_c_array[i] = ep[i] * ep[i];
            // Start of long NIOS 2 block

            // Output calculation, with saturation
            for (i = 0; i < N; i++)
            {
                // output[i] = ep[i] >> 16; plus rounding bit
                output[i] = ep[i] >> 15;
                output[i]++;
                output[i] = output[i] >> 1;
                if (output[i] > INT16_MAX) output[i] = INT16_MAX;
            }

            float[] ps_c_array = new float[N];
            float[] pe_c_array = new float[N];
            float dp_float, yp_float;
            for (i = 0; i < N; i++)
            {
                dp_float = dn[i] * ap.Fraction_F;
                yp_float = yp[i] * ap.Fraction_F;
                ps_c_array[i] = dp_float * dp_float - yp_float * yp_float;
                if (ps_c_array[i] < 0)  ps_c_array[i] *= (-1);

                dp_float = ep[i] * ap.Fraction_F;
                pe_c_array[i] = dp_float * dp_float; //really ep_float ^ 2
            }

            // Step-size control
            if (p_start == 0)
            {
                p_start = 1;
            }
            else
            {
                pwr = lam_p * pwr + (1f - lam_p) * pwr;
            }
            for (i = 0; i < N; i++)
            {
                if (ps_c_array[i] > ps)
                    ps = lam_f * ps + (1f - lam_f) * ps_c_array[i];
                else
                    ps = lam_s * ps + (1f - lam_s) * ps_c_array[i];

                if (pe_c_array[i] > pe)
                    pe = lam_f * pe + (1f - lam_f) * pe_c_array[i];
                else
                    pe = lam_s * pe + (1f - lam_s) * pe_c_array[i];
            }

            if (index < 200)
                mu = mu1;
            else
                mu = mu2;

            // Adaptation control
            if (pwr < pwr_th)
            {
                mu_k = 0;
            }
            else
            {
                // Run initial tens frame without condition
                if (init_blk_cnt < 100)
                {
                    init_blk_cnt++;
                    mu_k = mu;
                }
                else
                {
                    if (pe < 0.35f * ps)
                    {
                        mu_k = mu;
                    }
                    else if (pe < 0.4f * ps)
                    {
                        mu_k = mu / 2;
                    }
                    else if (pe < 0.5f * ps)
                    {
                        mu_k = mu / 4;
                    }
                    else if (pe < 0.65f * ps)
                    {
                        mu_k = mu / 8;
                    }
                    else
                    {
                        mu_k = 0;
                    }
                }
            }

            // Weight update -NLMS
            if (Const_index < 3)
                Const_index++;
            else
                Const_index = 0;
            // End of long NIOS 2 block
            //---------------------------------------------------------------------            


            for (m = 0; m < M; m++)
            {
                Xb_index = Xb_offset + m;
                if (Xb_index > XB_NUM_ROWS - 1) Xb_index = Xb_index - XB_NUM_ROWS;
                Eb_index = Eb_offset + nd;
                if (Eb_index > EB_NUM_ROWS - 1) Eb_index = Eb_index - EB_NUM_ROWS;

                //---------------------------------------------------------------------
                // Compute Rb[] from Xb[][], Eb[][], and Pi_int[]
                // The Pi_int[] is already in memory C0
                ap.read_ssram(ArrayProc.DEST.A0, Xb_base + (Xb_index + nd) * XB_NUM_COLS * 2,
                        N + 1, 1); //Xb_Vec --> A0
                ap.read_ssram(ArrayProc.DEST.A1, Eb_base + Eb_index * EB_NUM_COLS * 2, 
                        N + 1, 1); //Eb_Vec --> A1
                
                //-----------------------------------------------------------------------                
                ap.compute_Rb(mu_k, N + 1);  // This computes Rb[] --> B0                 

                // Weight Vector Constraint Part
                if ((m == Const_index) || (m == (Const_index + 4)) || (m == (Const_index + 8)) || (m == (Const_index + 12)))
                {
                    //---------------------------------------------------------------------
                    // Create dW[] from Wei and Rb[]
                    ap.read_ssram(ArrayProc.DEST.B1, Wei_base + m * WEI_NUM_COLS * 2, N + 1, 1);  
                    // Wei  --> B1                    
                    ap.add_array(ArrayProc.SOURCE.B0, ArrayProc.SOURCE.B1, 0, N + 1, ArrayProc.DEST.A0);
                    // dW[k] = Wei[k] + Rb[k], for k = 0 to N; dW --> A0
                    ap.copy_data(ArrayProc.SOURCE.A0, N, 1, ArrayProc.DEST.A1, 0, ArrayProc.DATA_TYPE.real_imag);
                    // Prepare for inverse FFT. Copy A0[N] to A1[0], one element copy
                    ap.conjugate_mirror(ArrayProc.SOURCE.A0, 1, N - 1, N);
                    // A1[256-k] = Complex.Conjugate(A[k]), k = 1 to N-1
                    //---------------------------------------------------------------------
                    // Inverse FFT and bitshift on dW, which is mem A right now
                    ap.FFT512(ArrayProc.SOURCE.A0, ArrayProc.SHIFT_TYPE.left9, true);
                    
                    // To prepare for the next FFT, A0[0~255] copy to B0[0~255]
                    // Then set B1[0~255] to zero.
                    ap.copy_data(ArrayProc.SOURCE.A0, 0, N, ArrayProc.DEST.B0, 0, ArrayProc.DATA_TYPE.real_only);                    
                    ap.reset_memory(ArrayProc.DEST.B1, 0, N);
                    // dW now in B

                    // Do FFT on dW and bitshift
                    ap.FFT512(ArrayProc.SOURCE.B0, ArrayProc.SHIFT_TYPE.right9, false);

                    //---------------------------------------------------------------------
                    // Store dW to Wei matrix
                    ap.write_to_ssram(ArrayProc.SOURCE.B0, Wei_base + m * WEI_NUM_COLS * 2, N);
                    ap.write_to_ssram(ArrayProc.SOURCE.B1, Wei_base + m * WEI_NUM_COLS * 2 + N * 2, 1);
                }
                else
                {
                    //---------------------------------------------------------------------
                    // Unconstraint Part
                    // Add Rb to Wei, Rb is in B0, read Wei from matrix --> A1
                    ap.read_ssram(ArrayProc.DEST.A1, Wei_base + m * WEI_NUM_COLS * 2, N + 1, 1);
                                        
                    ap.add_array(ArrayProc.SOURCE.B0, ArrayProc.SOURCE.A1, 0, N + 1, ArrayProc.DEST.B1);
                    // The updated Wei_Vec is now in B1

                    // Store Wei to the Wei matrix
                    ap.write_to_ssram(ArrayProc.SOURCE.B1, m * WEI_NUM_COLS * 2, N + 1);
                }
            }

            //compute power of the frame for d[n] and output[n]
            double total_power_dn = 1;
            // in this port of the code, dn has been shifted left by 16 previously
            for (i = 0; i < dn.Length; i++) dn[i] = dn[i] >> 16;
            for (i = 0; i < dn.Length; i++)
                total_power_dn += (double)dn[i] * (double)dn[i];
            double total_power_output = 1;
            for (i = 0; i < output.Length; i++)
                total_power_output += (double)output[i] * (double)output[i];
            double atten = -10 * Math.Log10(total_power_output / total_power_dn);
            power_atten.Add(atten);
        }

        /// <summary>
        /// This function is meant to be run after all packets have been 
        /// processed. This function converts the "power_atten" list to
        /// a graph, which the main program can then plot.
        /// </summary>
        public void aec_end()
        {
            double[] atten_val = new double[power_atten.Count];
            for (int i = 0; i < atten_val.Length; i++)
            {
                atten_val[i] = power_atten[i];
            }

            //fill the "output_graph"
            output_graphs = new MyGraph[1];
            output_graphs[0] = new MyGraph("Attenuation of output[n] compared to d[n]",
                    "frame #", "Attenuation (dB)", atten_val);
        }
        #endregion
    }
}
