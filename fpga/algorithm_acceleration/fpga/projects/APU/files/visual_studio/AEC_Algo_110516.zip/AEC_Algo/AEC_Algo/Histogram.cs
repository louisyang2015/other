﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AEC_Algo
{
    class Histogram
    {
        private string title;
        private double low_end, high_end; //Histogram limits
        private int above = 0, below = 0; //for out of bound values
        private double bin_size;
        private int[] bins;

        /// <summary>
        /// Constructor
        /// </summary>
        public Histogram(string title, double low_end, double high_end, double bin_size)
        {
            this.title = title;
            this.low_end = low_end;
            this.high_end = high_end;
            this.bin_size = bin_size;
            int bins_length = (int)Math.Ceiling((high_end - low_end) / bin_size);
            bins = new int[bins_length];
            for (int i = 0; i < bins.Length; i++)
                bins[i] = 0;
        }

        /// <summary>
        /// Adds a value to the histogram. If the value is out of bound, 
        /// then the internal variables "above" or "below" will be incremented.
        /// </summary>
        public void add_value(double val)
        {
            if(double.IsNaN(val)) return;
            if (double.IsNegativeInfinity(val))
            {
                below++;
                return;
            }
            if (double.IsPositiveInfinity(val) || double.IsInfinity(val))
            {
                above++;
                return;
            }
            if (val < low_end)
            {
                below++;
                return;
            }
            else if (val > high_end)
            {
                above++;
                return;
            }
            else
            {
                int index = (int)Math.Floor((val - low_end) / bin_size);
                bins[index]++;
            }            
        }

        /// <summary>
        /// Prints a tab delimited string output that is suitable for 
        /// pasting into Excel.
        /// </summary>
        public override string ToString()
        {
            int sum = bins.Sum();

            StringBuilder sb = new StringBuilder();
            sb.Append(title + "\r\n");
            sb.Append("Bin\tCount\tPercent\r\n");
            if (sum == 0)
            {
                sb.Append("All bins are zero\r\n");
                return sb.ToString();
            }

            double percent = (double)below / (double)sum * 100d; 
            sb.Append("<" + low_end + "\t" + below + "\t" + percent.ToString("G3") + "%\r\n");

            for (int i = 0; i < bins.Length; i++)
            {
                percent = (double)bins[i] / (double)sum * 100d;
                double bin_val = low_end + i * bin_size;
                sb.Append(bin_val.ToString("G3") + "\t" + bins[i] + "\t" + percent.ToString("G3") + "%\r\n");
            }

            percent = (double)above / (double)sum * 100d;
            sb.Append(">" + high_end + "\t" + above + "\t" + percent.ToString("G3") + "%\r\n");
            
            return sb.ToString();
        }
    }
}
