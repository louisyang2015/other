﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.IO;
using System.Media;

namespace AEC_Algo
{
    /// <summary>
    /// This program explores the AEC algorithm.
    /// </summary> 
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Code in default values here to speed up testing.
        /// </summary>
        private void Form1_Load(object sender, EventArgs e)
        {
            Xn_file_textBox.Text = "sound_files\\xn32_rand.wav";
            Dn_file_textBox.Text = "sound_files\\dn32_rand_echo_only.wav";
            Yn_file_textBox.Text = "sound_files\\out32_rand_echo_only_fpga.wav";
            AEC_comboBox.SelectedIndex = 3;
            File1_textBox.Text = "sound_files\\out32_rand_echo_only.wav";
            File2_textBox.Text = "sound_files\\out32_rand_echo_only_fpga.wav";
        }

        #region AEC Tab
        /// <summary>
        /// Get file name for "x[n]" file textbox.
        /// </summary>
        private void Xn_browse_button_Click(object sender, EventArgs e)
        {
            if (openFileDialog1.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                Xn_file_textBox.Text = openFileDialog1.FileName;
        }

        /// <summary>
        /// Play the file listed at the x[n] file textbox.
        /// </summary>
        private void Xn_play_button_Click(object sender, EventArgs e)
        {
            play_sound_file(Xn_file_textBox.Text);
        }

        /// <summary>
        /// Get file name for "d[n]" file textbox.
        /// </summary>
        private void Dn_browse_button_Click(object sender, EventArgs e)
        {
            if (openFileDialog1.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                Dn_file_textBox.Text = openFileDialog1.FileName;
        }

        /// <summary>
        /// Play the file listed at the d[n] file textbox.
        /// </summary>
        private void Dn_play_button_Click(object sender, EventArgs e)
        {
            play_sound_file(Dn_file_textBox.Text);
        }

        /// <summary>
        /// Get file name for "y[n]" file textbox.
        /// </summary>
        private void Yn_browse_button_Click(object sender, EventArgs e)
        {
            if(saveFileDialog1.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                Yn_file_textBox.Text = saveFileDialog1.FileName;
        }

        /// <summary>
        /// Play the file listed at the y[n] file textbox.
        /// </summary>
        private void Yn_play_button_Click(object sender, EventArgs e)
        {
            play_sound_file(Yn_file_textBox.Text);
        }

        /// <summary>
        /// Run the AEC algorithm.
        /// </summary>
        private void AEC_run_button_Click(object sender, EventArgs e)
        {
            //preparation and error checking
            if (AEC_comboBox.SelectedIndex < 0)
            {
                AEC_textBox.Text += "No AEC algorithm selected\r\n";
                return;
            }

            string xn_file_name = Xn_file_textBox.Text.Trim();
            string dn_file_name = Dn_file_textBox.Text.Trim();
            string output_file_name = Yn_file_textBox.Text.Trim();
            if (File.Exists(xn_file_name) == false)
            {
                AEC_textBox.Text += "x[n] file does not exist\r\n";
                return;
            }
            if (File.Exists(dn_file_name) == false)
            {
                AEC_textBox.Text += "d[n] file does not exist\r\n";
                return;
            }

            MyWavFile xn_wav = new MyWavFile(xn_file_name);
            if (xn_wav.data == null)
            {
                AEC_textBox.Text += "Failed to parse x[n] file.\r\n";
                return;
            }
            MyWavFile dn_wav = new MyWavFile(dn_file_name);
            if (dn_wav.data == null)
            {
                AEC_textBox.Text += "Failed to parse d[n] file.\r\n";
                return;
            }

            // Choose an algorithm implementation
            I_AEC aec_if = null;
            if (AEC_comboBox.SelectedItem.ToString().StartsWith("16 kHz original double precision"))
                aec_if = new AEC16_Etri_double();
            else if (AEC_comboBox.SelectedItem.ToString().StartsWith("16 kHz double precision with histograms"))
                aec_if = new AEC16_double_hist();
            else if (AEC_comboBox.SelectedItem.ToString().StartsWith("32 kHz double precision"))
                aec_if = new AEC32_double();
            else if (AEC_comboBox.SelectedItem.ToString().StartsWith("32 kHz FPGA int precision"))
                aec_if = new AEC32_FPGA_port6();

            if (aec_if == null)
            {
                AEC_textBox.Text += "Failed to instantiate AEC object";
                return;
            }

            //running the AEC
            this.Cursor = Cursors.WaitCursor;
            aec_if.aec_init();
            int N = aec_if.N_Val;
            int[] xn = new int[N];
            int[] dn = new int[N];
            int[] output = new int[N];
            int[] full_output = new int[xn_wav.data.Length];
            for (int i = 0; i <= xn_wav.data.Length - N + 1; i = i + N)
            {
                //load up xn and dn
                for (int j = 0; j < N; j++)
                {
                    xn[j] = xn_wav.data[i + j];
                    dn[j] = dn_wav.data[i + j];
                }
                aec_if.aec(dn, xn, output);

                //load output --> full_output
                for (int j = 0; j < N; j++)
                    full_output[i + j] = output[j];
            }
            aec_if.aec_end();

            //saving output to file
            MyWavFile output_wav = new MyWavFile(full_output, xn_wav.frequency, xn_wav.bit_width);
            output_wav.write_to_file(output_file_name);
            AEC_textBox.Text = "Output created: " + output_file_name + "\r\n";
            this.Cursor = Cursors.Default;     
       
            //print Histogram output if it exists
            if (aec_if.Histo_array != null)
            {
                StringBuilder sb = new StringBuilder();
                for (int i = 0; i < aec_if.Histo_array.Length; i++)
                {
                    sb.Append(aec_if.Histo_array[i].ToString());
                }
                AEC_textBox.Text += "\r\n" + sb.ToString();
            }

            //attach graphs if they exist
            output_graphs = aec_if.Graphs;
            Graphs_comboBox.SelectedIndex = -1;
            Graphs_comboBox.Items.Clear();
            if (output_graphs != null)
            {
                for (int i = 0; i < output_graphs.Length; i++)
                    Graphs_comboBox.Items.Add(output_graphs[i].get_title());
            }

            System.Media.SystemSounds.Exclamation.Play();
        }
        #endregion

        #region Data Tab
        /// <summary>
        /// This creates a random data set and save it in a 
        /// file. The randomization is based on the 
        /// selection in Xn_create_comboBox.
        /// </summary>
        private void Xn_create_button_Click(object sender, EventArgs e)
        {
            if (Xn_create_comboBox.SelectedIndex < 0) return;

            string file_name = null;
            if (saveFileDialog1.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                file_name = saveFileDialog1.FileName;
            if (file_name == null) return;

            int[] data = null;
            Random rand = new Random();
            if (Xn_create_comboBox.SelectedItem.ToString().StartsWith("Random -(2^13) ~ 2^13, 32k * 15 samples"))
            {
                data = new int[32000 * 15];
                for (int i = 0; i < data.Length; i++)
                    data[i] = rand.Next(-8 * 1024, 8 * 1024);
            }
            else if (Xn_create_comboBox.SelectedItem.ToString().StartsWith("Random -(2^15-1) ~ 2^15-1, 32k * 15 samples"))
            {
                data = new int[32000 * 15];
                for (int i = 0; i < data.Length; i++)
                    data[i] = rand.Next(-32 * 1024 + 1, 32 * 1024 - 1);
            }
            else if (Xn_create_comboBox.SelectedItem.ToString().StartsWith("Random -(2^14) ~ 2^14, 32k * 15 samples"))
            {
                data = new int[32000 * 15];
                for (int i = 0; i < data.Length; i++)
                    data[i] = rand.Next(-16 * 1024, 16 * 1024);
            }
            MyWavFile xn_rand = new MyWavFile(data, 32000, 16);
            xn_rand.write_to_file(file_name);
        }

        /// <summary>
        /// Chooses a x[n] file as the basis for the d[n] file. The 
        /// d[n] will be an echo of the x[n] file.
        /// </summary>
        private void Xn_basis_file_button_Click(object sender, EventArgs e)
        {
            if (openFileDialog1.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                Xn_basis_file_textBox.Text = openFileDialog1.FileName;
        }

        /// <summary>
        /// Chooses an interference file for the d[n] creation. This
        /// interference file is the near end speaker. The d[n] file is 
        /// an echo generated from the x[n] file, plus speech from this
        /// interference file.
        /// </summary>
        private void Dn_interfere_browse_button_Click(object sender, EventArgs e)
        {
            if (openFileDialog1.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                Dn_interfere_file_textBox.Text = openFileDialog1.FileName;
        }
        
        /// <summary>
        /// Chooses a file name to hold the d[n] data that will be generated.
        /// </summary>
        private void Dn_gen_file_button_Click(object sender, EventArgs e)
        {
            if (saveFileDialog1.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                Dn_gen_file_textBox.Text = saveFileDialog1.FileName;
        }

        /// <summary>
        /// Generate the d[n] file, from the x[n]
        /// </summary>
        private void Dn_create_button_Click(object sender, EventArgs e)
        {
            //error checking
            if (File.Exists(Xn_basis_file_textBox.Text) == false) return;
            if (Dn_create_comboBox.SelectedIndex < 0) return;
            if (Dn_gen_file_textBox.Text.Trim().Length < 1) return;

            //echo generation
            MyWavFile xn_wav = new MyWavFile(Xn_basis_file_textBox.Text);
            if (xn_wav.data == null) return;

            int[] echo_data = null;
            if (Dn_create_comboBox.SelectedItem.ToString().StartsWith("Simple echo"))
                echo_data = make_echo(xn_wav.data, 256 * 6, 0.3);
            else if (Dn_create_comboBox.SelectedItem.ToString().StartsWith("Tripple echo"))
                echo_data = make_tripple_echo(xn_wav.data, 256 * 5, 0.3, 256 * 7, 0.15, 256 * 9, 0.07);
            else if (Dn_create_comboBox.SelectedItem.ToString().StartsWith("Fully random: -(2^15-1) ~ 2^15-1"))
            {
                echo_data = new int[xn_wav.data.Length];
                Random rand = new Random();
                for(int i = 0; i < echo_data.Length; i++)
                    echo_data[i] = rand.Next(-32*1024+1, 32*1024-1);
            }

            //add interference data if needed
            if (Dn_interfere_file_textBox.Text.Trim().Length > 0)
            {
                MyWavFile interfere_wav = new MyWavFile(Dn_interfere_file_textBox.Text);
                if (interfere_wav.data != null)
                {
                    echo_data = add_voice_data(echo_data, interfere_wav.data, 32*1024-1);
                }
            }

            //write to file
            MyWavFile dn_wav = new MyWavFile(echo_data, xn_wav.frequency, 16);
            dn_wav.write_to_file(Dn_gen_file_textBox.Text);
        }
        #endregion

        #region Graphs Tab
        MyGraph[] output_graphs;

        /// <summary>
        /// Renders a graph according to user choice.
        /// </summary>
        private void Graphs_comboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (output_graphs == null) return;
            if (Graphs_comboBox.SelectedIndex < 0) return;
            if (Graphs_comboBox.SelectedIndex > output_graphs.Length - 1) return;

            int selection = Graphs_comboBox.SelectedIndex;
            output_graphs[selection].render(Graphs_c1Chart);
        }

        /// <summary>
        /// Place a graph onto the clipboard according to user choice.
        /// </summary>
        private void Copy_graph_data_button_Click(object sender, EventArgs e)
        {
            if (output_graphs == null) return;
            if (Graphs_comboBox.SelectedIndex < 0) return;
            if (Graphs_comboBox.SelectedIndex > output_graphs.Length - 1) return;

            int selection = Graphs_comboBox.SelectedIndex;
            string data = output_graphs[selection].get_data();
            Clipboard.SetText(data);
        }

        #endregion

        #region Util Tab
        /// <summary>
        /// Converts PCM files to the WAV format.
        /// </summary>        
        private void PCM_to_wav_button_Click(object sender, EventArgs e)
        {
            if (Source_rate_comboBox.SelectedIndex == -1) return;
            if (Dest_rate_comboBox.SelectedIndex == -1) return;
            int src_sample_rate = -1;
            int dest_sample_rate = -1;
            if (Source_rate_comboBox.SelectedItem.ToString().StartsWith("16 k"))
                src_sample_rate = 16000;
            else if (Source_rate_comboBox.SelectedItem.ToString().StartsWith("32 k"))
                src_sample_rate = 32000;
            if (Dest_rate_comboBox.SelectedItem.ToString().StartsWith("16 k"))
                dest_sample_rate = 16000;
            else if (Dest_rate_comboBox.SelectedItem.ToString().StartsWith("32 k"))
                dest_sample_rate = 32000;

            if (src_sample_rate == -1) return;
            if (dest_sample_rate == -1) return;

            string file_name;
            if (openFileDialog1.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                file_name = openFileDialog1.FileName;
            }
            else
                return;

            int[] data = read_int16_from_file(file_name);
            if (src_sample_rate == dest_sample_rate)
            {
                //no rate conversion
                MyWavFile wav = new MyWavFile(data, dest_sample_rate, 16);
                wav.write_to_file(remove_file_ext(file_name) + ".wav");
            }
            else
            {
                //rate conversion needed
            }
        }

        /// <summary>
        /// Converts a WAV file to the binary format.
        /// </summary>
        private void Wav_to_bin_button_Click(object sender, EventArgs e)
        {
            string file_name;
            if (openFileDialog1.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                file_name = openFileDialog1.FileName;
                MyWavFile wav_file = new MyWavFile(file_name);
                if (wav_file.bit_width == 16)
                {
                    string new_file_name = remove_file_ext(file_name) + ".bin";
                    BinaryWriter b = new BinaryWriter(File.OpenWrite(new_file_name));
                    for (int i = 0; i < wav_file.data.Length; i++)
                    {
                        b.Write((short)wav_file.data[i]);
                    }
                    b.Close();
                }
            }
        }

        /// <summary>
        /// Choose File1
        /// </summary>
        private void File1_browse_button_Click(object sender, EventArgs e)
        {
            if (openFileDialog1.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                File1_textBox.Text = openFileDialog1.FileName;
            }
        }

        /// <summary>
        /// Choose File2
        /// </summary>
        private void File2_browse_button_Click(object sender, EventArgs e)
        {
            if (openFileDialog1.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                File2_textBox.Text = openFileDialog1.FileName;
            }
        }

        /// <summary>
        /// Run a comparison test between File1 and File2
        /// </summary>
        private void File_compare_button_Click(object sender, EventArgs e)
        {
            Util_textBox.Text = compare_with_file(File1_textBox.Text, File2_textBox.Text);
        }
        #endregion

        #region Helper Functions
        /// <summary>
        /// Add two sets of voice data together and scale it to be 
        /// less than the "max_voice" variable. The output[n] = (voice1[n]
        /// + voice2[n]) * scale_factor. The length of the output is the
        /// longer of the two voice data arrays.
        /// </summary>
        private int[] add_voice_data(int[] voice1, int[] voice2, int max_voice)
        {
            int short_length, long_length;
            if (voice1.Length > voice2.Length)
            {
                long_length = voice1.Length;
                short_length = voice2.Length;
            }
            else
            {
                long_length = voice2.Length;
                short_length = voice1.Length;
            }
            int[] output = new int[long_length];
            int max = 0;
            int min = 0;
            //add voice1[n] and voice2[n], then padd
            for (int n = 0; n < short_length; n++)
            {
                output[n] = voice1[n] + voice2[n];
                if (output[n] > max) max = output[n];
                if (output[n] < min) min = output[n];
            }
            if (voice1.Length > voice2.Length)
            {
                //pad with voice1
                for (int n = short_length; n < long_length; n++)
                {
                    output[n] = voice1[n];
                    if (output[n] > max) max = output[n];
                    if (output[n] < min) min = output[n];
                }
            }
            else
            {
                //pad with voice2
                for (int n = short_length; n < long_length; n++)
                {
                    output[n] = voice2[n];
                    if (output[n] > max) max = output[n];
                    if (output[n] < min) min = output[n];
                }
            }
            
            //use the larger of max or |min| for scaling
            if (-1 * min > max) max = -1 * min;
            double scale = (max_voice - 1) / max;
            for (int n = 0; n < long_length; n++)
                output[n] = (int)Math.Round(scale * output[n]);

            return output;
        }

        /// <summary>
        /// Compare an integer array with data inside a "wav" file. Print the number of
        /// differences, the maximum difference, the minimum difference, average absolute
        /// difference, and up to the first 10 differences found.
        /// </summary>
        private string compare_with_file(int[] i_array, string wav_file_name)
        {
            if (wav_file_name.EndsWith(".wav", StringComparison.OrdinalIgnoreCase) == false)
                return "File name provided is not a \".wav\" file";

            MyWavFile wav = new MyWavFile(wav_file_name);
            if (wav.data == null)
                return "Failed to open the wav file: " + wav_file_name;

            StringBuilder sb = new StringBuilder();

            int length = i_array.Length;
            if (length != wav.data.Length)
            {
                sb.Append("Two arrays are of different length: " + length + " elements and ");
                sb.Append(wav.data.Length + " elements.\r\n");
                if (length > wav.data.Length) length = wav.data.Length;
            }

            //satistics to collect
            long total_diff = 0; //sum of [absolute_value (differences) ]
            long max_diff = 0; //maximum difference
            long min_diff = 0;
            int num_diff = 0; //number of differences observed
            int[] first10_diff_index = new int[10]; //where are the first 10 differences seen

            //element by element comparison:
            for (int i = 0; i < length; i++)
            {
                int diff = i_array[i] - wav.data[i];
                if (diff != 0)
                {
                    if (diff > max_diff) max_diff = diff;
                    if (diff < min_diff) min_diff = diff;
                    total_diff += Math.Abs(diff);
                    if (num_diff < 10)
                    {
                        first10_diff_index[num_diff] = i;
                    }
                    num_diff++;                    
                }
            }

            //format output
            sb.Append("Number of elements compared: " + length + "\r\n");
            sb.Append("Number of differences observed: " + num_diff + "\r\n");
            sb.Append("Maximum difference: " + max_diff + "\r\n");
            sb.Append("Minimum difference: " + min_diff + "\r\n");
            double avg_diff = (double)total_diff / (double)length;
            sb.Append("Average absolute difference: " + avg_diff.ToString("G5") + "\r\n");
            if (num_diff > 0)
            {
                //print differences, up to 10
                sb.Append("index\tValue\tValue\tDifference\r\n");
                int num_diff_to_print = num_diff;
                if(num_diff_to_print > 10) num_diff_to_print = 10;
                for (int i = 0; i < num_diff_to_print; i++)
                {
                    sb.Append(first10_diff_index[i] + "\t");
                    sb.Append(i_array[first10_diff_index[i]] + "\t");
                    sb.Append(wav.data[first10_diff_index[i]] + "\t");
                    sb.Append((i_array[first10_diff_index[i]] - wav.data[first10_diff_index[i]]) + "\r\n");
                }
            }
            return sb.ToString();
        }

        /// <summary>
        /// Compares two "wav" files. It actually opens one wave fiel as an integer array, 
        /// and then it will call the compare_with_file(int[] i_array, string wav_file_name).
        /// </summary>
        private string compare_with_file(string wav_file_name1, string wav_file_name2)
        {
            MyWavFile file1 = new MyWavFile(wav_file_name1);
            if (file1.data == null)
                return "Failed to open the wave file:" + wav_file_name1;

            return compare_with_file(file1.data, wav_file_name2);
        }

        /// <summary>
        /// Produce an echo from the "original" integer array. This original
        /// array is not modified. The output[n] = coeff * original[n-delay]
        /// </summary>
        private int[] make_echo(int[] original, int delay, double coeff)
        {
            int[] output = new int[original.Length];
            for (int n = 0; n < delay; n++)
                output[n] = 0;
            for (int n = delay; n < output.Length; n++)
                output[n] = (int)Math.Round(coeff * original[n - delay]);
            return output;
        }

        /// <summary>
        /// Produce an echo from the "original" integer array, based on three separate
        /// delay and attenuation values. The original array is not changed. 
        /// The output[n] = coeff1 * original[n-delay1] + coeff2 * original[n-delay2]
        /// + coeff3 * original[n-delay3]. It's assumed that delay1 < delay2 < delay3.
        /// </summary>
        private int[] make_tripple_echo(int[] original, int delay1, double coeff1,
                int delay2, double coeff2, int delay3, double coeff3)
        {
            int[] output = new int[original.Length];
            for (int n = 0; n < delay1; n++)
                output[n] = 0;
            for (int n = delay1; n < delay2; n++)
                output[n] = (int)Math.Round(coeff1 * original[n - delay1]);
            for (int n = delay2; n < delay3; n++)
                output[n] = (int)Math.Round(coeff1 * original[n - delay1])
                    + (int)Math.Round(coeff2 * original[n - delay2]);
            for (int n = delay3; n < output.Length; n++)
                output[n] = (int)Math.Round(coeff1 * original[n - delay1])
                    + (int)Math.Round(coeff2 * original[n - delay2])
                    + (int)Math.Round(coeff3 * original[n - delay3]);
            return output;
        }

        /// <summary>
        /// Checks to see that the "file_name" exists and ends in ".wav". Then
        /// play the file.
        /// </summary>
        private void play_sound_file(string file_name)
        {
            if (File.Exists(file_name) == false) return;
            if (file_name.EndsWith(".wav") == false) return;
            SoundPlayer sp = new SoundPlayer(file_name);
            sp.Play();
        }

        /// <summary>
        /// Reads a binary file and return it as an array of short (16-bit)
        /// integers.
        /// </summary>
        private int[] read_int16_from_file(string file_name)
        {
            BinaryReader b = new BinaryReader(File.OpenRead(file_name));
            long length = b.BaseStream.Length / 2;
            int[] return_val = new int[length];
            for (int i = 0; i < return_val.Length; i++)
                return_val[i] = b.ReadInt16();
            return return_val;
        }

        /// <summary>
        /// Takes in a file name and remove the file extension from the end
        /// of the file name.
        /// </summary>
        private string remove_file_ext(string file_name)
        {
            int last_period = file_name.LastIndexOf('.');
            if (last_period == -1) return file_name;
            else return file_name.Substring(0, last_period);            
        }

        
        #endregion

        







    }
}
