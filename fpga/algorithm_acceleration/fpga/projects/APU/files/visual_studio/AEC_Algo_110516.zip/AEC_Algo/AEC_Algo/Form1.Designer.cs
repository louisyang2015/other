﻿namespace AEC_Algo
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.AEC_tabPage = new System.Windows.Forms.TabPage();
            this.AEC_textBox = new System.Windows.Forms.TextBox();
            this.AEC_run_button = new System.Windows.Forms.Button();
            this.AEC_comboBox = new System.Windows.Forms.ComboBox();
            this.Yn_play_button = new System.Windows.Forms.Button();
            this.Dn_play_button = new System.Windows.Forms.Button();
            this.Xn_play_button = new System.Windows.Forms.Button();
            this.Yn_browse_button = new System.Windows.Forms.Button();
            this.Dn_browse_button = new System.Windows.Forms.Button();
            this.Xn_browse_button = new System.Windows.Forms.Button();
            this.Yn_file_textBox = new System.Windows.Forms.TextBox();
            this.Dn_file_textBox = new System.Windows.Forms.TextBox();
            this.Xn_file_textBox = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.Data_tabPage = new System.Windows.Forms.TabPage();
            this.Dn_gen_file_textBox = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.Dn_gen_file_button = new System.Windows.Forms.Button();
            this.Xn_basis_file_button = new System.Windows.Forms.Button();
            this.Xn_basis_file_textBox = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.Xn_create_comboBox = new System.Windows.Forms.ComboBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.Dn_create_button = new System.Windows.Forms.Button();
            this.Dn_interfere_browse_button = new System.Windows.Forms.Button();
            this.Dn_interfere_file_textBox = new System.Windows.Forms.TextBox();
            this.Dn_create_comboBox = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.Xn_create_button = new System.Windows.Forms.Button();
            this.Graphs_tabPage = new System.Windows.Forms.TabPage();
            this.Graphs_c1Chart = new C1.Win.C1Chart.C1Chart();
            this.Graphs_comboBox = new System.Windows.Forms.ComboBox();
            this.Copy_graph_data_button = new System.Windows.Forms.Button();
            this.Util_tabPage = new System.Windows.Forms.TabPage();
            this.Util_textBox = new System.Windows.Forms.TextBox();
            this.File2_browse_button = new System.Windows.Forms.Button();
            this.File1_browse_button = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.File2_textBox = new System.Windows.Forms.TextBox();
            this.File1_textBox = new System.Windows.Forms.TextBox();
            this.Dest_rate_comboBox = new System.Windows.Forms.ComboBox();
            this.Source_rate_comboBox = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.File_compare_button = new System.Windows.Forms.Button();
            this.PCM_to_wav_button = new System.Windows.Forms.Button();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.Wav_to_bin_button = new System.Windows.Forms.Button();
            this.tabControl1.SuspendLayout();
            this.AEC_tabPage.SuspendLayout();
            this.Data_tabPage.SuspendLayout();
            this.Graphs_tabPage.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Graphs_c1Chart)).BeginInit();
            this.Util_tabPage.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.AEC_tabPage);
            this.tabControl1.Controls.Add(this.Data_tabPage);
            this.tabControl1.Controls.Add(this.Graphs_tabPage);
            this.tabControl1.Controls.Add(this.Util_tabPage);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(714, 522);
            this.tabControl1.TabIndex = 0;
            // 
            // AEC_tabPage
            // 
            this.AEC_tabPage.Controls.Add(this.AEC_textBox);
            this.AEC_tabPage.Controls.Add(this.AEC_run_button);
            this.AEC_tabPage.Controls.Add(this.AEC_comboBox);
            this.AEC_tabPage.Controls.Add(this.Yn_play_button);
            this.AEC_tabPage.Controls.Add(this.Dn_play_button);
            this.AEC_tabPage.Controls.Add(this.Xn_play_button);
            this.AEC_tabPage.Controls.Add(this.Yn_browse_button);
            this.AEC_tabPage.Controls.Add(this.Dn_browse_button);
            this.AEC_tabPage.Controls.Add(this.Xn_browse_button);
            this.AEC_tabPage.Controls.Add(this.Yn_file_textBox);
            this.AEC_tabPage.Controls.Add(this.Dn_file_textBox);
            this.AEC_tabPage.Controls.Add(this.Xn_file_textBox);
            this.AEC_tabPage.Controls.Add(this.label3);
            this.AEC_tabPage.Controls.Add(this.label2);
            this.AEC_tabPage.Controls.Add(this.label1);
            this.AEC_tabPage.Location = new System.Drawing.Point(4, 38);
            this.AEC_tabPage.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.AEC_tabPage.Name = "AEC_tabPage";
            this.AEC_tabPage.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.AEC_tabPage.Size = new System.Drawing.Size(706, 480);
            this.AEC_tabPage.TabIndex = 0;
            this.AEC_tabPage.Text = "AEC";
            this.AEC_tabPage.UseVisualStyleBackColor = true;
            // 
            // AEC_textBox
            // 
            this.AEC_textBox.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.AEC_textBox.Location = new System.Drawing.Point(16, 291);
            this.AEC_textBox.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.AEC_textBox.Multiline = true;
            this.AEC_textBox.Name = "AEC_textBox";
            this.AEC_textBox.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.AEC_textBox.Size = new System.Drawing.Size(658, 146);
            this.AEC_textBox.TabIndex = 14;
            this.AEC_textBox.WordWrap = false;
            // 
            // AEC_run_button
            // 
            this.AEC_run_button.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.AEC_run_button.Location = new System.Drawing.Point(562, 212);
            this.AEC_run_button.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.AEC_run_button.Name = "AEC_run_button";
            this.AEC_run_button.Size = new System.Drawing.Size(112, 54);
            this.AEC_run_button.TabIndex = 13;
            this.AEC_run_button.Text = "Run";
            this.AEC_run_button.UseVisualStyleBackColor = true;
            this.AEC_run_button.Click += new System.EventHandler(this.AEC_run_button_Click);
            // 
            // AEC_comboBox
            // 
            this.AEC_comboBox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.AEC_comboBox.FormattingEnabled = true;
            this.AEC_comboBox.Items.AddRange(new object[] {
            "16 kHz original double precision",
            "16 kHz double precision with histograms",
            "32 kHz double precision",
            "32 kHz FPGA int precision"});
            this.AEC_comboBox.Location = new System.Drawing.Point(16, 222);
            this.AEC_comboBox.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.AEC_comboBox.Name = "AEC_comboBox";
            this.AEC_comboBox.Size = new System.Drawing.Size(529, 37);
            this.AEC_comboBox.TabIndex = 12;
            // 
            // Yn_play_button
            // 
            this.Yn_play_button.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Yn_play_button.Location = new System.Drawing.Point(562, 138);
            this.Yn_play_button.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Yn_play_button.Name = "Yn_play_button";
            this.Yn_play_button.Size = new System.Drawing.Size(112, 54);
            this.Yn_play_button.TabIndex = 11;
            this.Yn_play_button.Text = "Play";
            this.Yn_play_button.UseVisualStyleBackColor = true;
            this.Yn_play_button.Click += new System.EventHandler(this.Yn_play_button_Click);
            // 
            // Dn_play_button
            // 
            this.Dn_play_button.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Dn_play_button.Location = new System.Drawing.Point(562, 69);
            this.Dn_play_button.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Dn_play_button.Name = "Dn_play_button";
            this.Dn_play_button.Size = new System.Drawing.Size(112, 54);
            this.Dn_play_button.TabIndex = 7;
            this.Dn_play_button.Text = "Play";
            this.Dn_play_button.UseVisualStyleBackColor = true;
            this.Dn_play_button.Click += new System.EventHandler(this.Dn_play_button_Click);
            // 
            // Xn_play_button
            // 
            this.Xn_play_button.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Xn_play_button.Location = new System.Drawing.Point(562, 5);
            this.Xn_play_button.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Xn_play_button.Name = "Xn_play_button";
            this.Xn_play_button.Size = new System.Drawing.Size(112, 54);
            this.Xn_play_button.TabIndex = 3;
            this.Xn_play_button.Text = "Play";
            this.Xn_play_button.UseVisualStyleBackColor = true;
            this.Xn_play_button.Click += new System.EventHandler(this.Xn_play_button_Click);
            // 
            // Yn_browse_button
            // 
            this.Yn_browse_button.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Yn_browse_button.Location = new System.Drawing.Point(434, 138);
            this.Yn_browse_button.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Yn_browse_button.Name = "Yn_browse_button";
            this.Yn_browse_button.Size = new System.Drawing.Size(112, 54);
            this.Yn_browse_button.TabIndex = 10;
            this.Yn_browse_button.Text = "Browse";
            this.Yn_browse_button.UseVisualStyleBackColor = true;
            this.Yn_browse_button.Click += new System.EventHandler(this.Yn_browse_button_Click);
            // 
            // Dn_browse_button
            // 
            this.Dn_browse_button.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Dn_browse_button.Location = new System.Drawing.Point(434, 69);
            this.Dn_browse_button.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Dn_browse_button.Name = "Dn_browse_button";
            this.Dn_browse_button.Size = new System.Drawing.Size(112, 54);
            this.Dn_browse_button.TabIndex = 6;
            this.Dn_browse_button.Text = "Browse";
            this.Dn_browse_button.UseVisualStyleBackColor = true;
            this.Dn_browse_button.Click += new System.EventHandler(this.Dn_browse_button_Click);
            // 
            // Xn_browse_button
            // 
            this.Xn_browse_button.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Xn_browse_button.Location = new System.Drawing.Point(434, 5);
            this.Xn_browse_button.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Xn_browse_button.Name = "Xn_browse_button";
            this.Xn_browse_button.Size = new System.Drawing.Size(112, 54);
            this.Xn_browse_button.TabIndex = 2;
            this.Xn_browse_button.Text = "Browse";
            this.Xn_browse_button.UseVisualStyleBackColor = true;
            this.Xn_browse_button.Click += new System.EventHandler(this.Xn_browse_button_Click);
            // 
            // Yn_file_textBox
            // 
            this.Yn_file_textBox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.Yn_file_textBox.Location = new System.Drawing.Point(84, 146);
            this.Yn_file_textBox.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Yn_file_textBox.Name = "Yn_file_textBox";
            this.Yn_file_textBox.Size = new System.Drawing.Size(326, 35);
            this.Yn_file_textBox.TabIndex = 9;
            // 
            // Dn_file_textBox
            // 
            this.Dn_file_textBox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.Dn_file_textBox.Location = new System.Drawing.Point(84, 80);
            this.Dn_file_textBox.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Dn_file_textBox.Name = "Dn_file_textBox";
            this.Dn_file_textBox.Size = new System.Drawing.Size(326, 35);
            this.Dn_file_textBox.TabIndex = 5;
            // 
            // Xn_file_textBox
            // 
            this.Xn_file_textBox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.Xn_file_textBox.Location = new System.Drawing.Point(84, 15);
            this.Xn_file_textBox.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Xn_file_textBox.Name = "Xn_file_textBox";
            this.Xn_file_textBox.Size = new System.Drawing.Size(326, 35);
            this.Xn_file_textBox.TabIndex = 1;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(10, 151);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(51, 29);
            this.label3.TabIndex = 8;
            this.label3.Text = "y[n]";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(10, 85);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(54, 29);
            this.label2.TabIndex = 4;
            this.label2.Text = "d[n]";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(10, 20);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(51, 29);
            this.label1.TabIndex = 0;
            this.label1.Text = "x[n]";
            // 
            // Data_tabPage
            // 
            this.Data_tabPage.Controls.Add(this.Dn_gen_file_textBox);
            this.Data_tabPage.Controls.Add(this.label11);
            this.Data_tabPage.Controls.Add(this.Dn_gen_file_button);
            this.Data_tabPage.Controls.Add(this.Xn_basis_file_button);
            this.Data_tabPage.Controls.Add(this.Xn_basis_file_textBox);
            this.Data_tabPage.Controls.Add(this.label10);
            this.Data_tabPage.Controls.Add(this.Xn_create_comboBox);
            this.Data_tabPage.Controls.Add(this.label9);
            this.Data_tabPage.Controls.Add(this.label6);
            this.Data_tabPage.Controls.Add(this.Dn_create_button);
            this.Data_tabPage.Controls.Add(this.Dn_interfere_browse_button);
            this.Data_tabPage.Controls.Add(this.Dn_interfere_file_textBox);
            this.Data_tabPage.Controls.Add(this.Dn_create_comboBox);
            this.Data_tabPage.Controls.Add(this.label5);
            this.Data_tabPage.Controls.Add(this.Xn_create_button);
            this.Data_tabPage.Location = new System.Drawing.Point(4, 38);
            this.Data_tabPage.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Data_tabPage.Name = "Data_tabPage";
            this.Data_tabPage.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Data_tabPage.Size = new System.Drawing.Size(706, 480);
            this.Data_tabPage.TabIndex = 1;
            this.Data_tabPage.Text = "Data";
            this.Data_tabPage.UseVisualStyleBackColor = true;
            // 
            // Dn_gen_file_textBox
            // 
            this.Dn_gen_file_textBox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.Dn_gen_file_textBox.Location = new System.Drawing.Point(214, 323);
            this.Dn_gen_file_textBox.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Dn_gen_file_textBox.Name = "Dn_gen_file_textBox";
            this.Dn_gen_file_textBox.Size = new System.Drawing.Size(322, 35);
            this.Dn_gen_file_textBox.TabIndex = 12;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(14, 328);
            this.label11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(164, 29);
            this.label11.TabIndex = 11;
            this.label11.Text = "d[n] file name:";
            // 
            // Dn_gen_file_button
            // 
            this.Dn_gen_file_button.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Dn_gen_file_button.Location = new System.Drawing.Point(564, 317);
            this.Dn_gen_file_button.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Dn_gen_file_button.Name = "Dn_gen_file_button";
            this.Dn_gen_file_button.Size = new System.Drawing.Size(112, 54);
            this.Dn_gen_file_button.TabIndex = 13;
            this.Dn_gen_file_button.Text = "Browse";
            this.Dn_gen_file_button.UseVisualStyleBackColor = true;
            this.Dn_gen_file_button.Click += new System.EventHandler(this.Dn_gen_file_button_Click);
            // 
            // Xn_basis_file_button
            // 
            this.Xn_basis_file_button.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Xn_basis_file_button.Location = new System.Drawing.Point(564, 105);
            this.Xn_basis_file_button.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Xn_basis_file_button.Name = "Xn_basis_file_button";
            this.Xn_basis_file_button.Size = new System.Drawing.Size(112, 54);
            this.Xn_basis_file_button.TabIndex = 5;
            this.Xn_basis_file_button.Text = "Browse";
            this.Xn_basis_file_button.UseVisualStyleBackColor = true;
            this.Xn_basis_file_button.Click += new System.EventHandler(this.Xn_basis_file_button_Click);
            // 
            // Xn_basis_file_textBox
            // 
            this.Xn_basis_file_textBox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.Xn_basis_file_textBox.Location = new System.Drawing.Point(346, 111);
            this.Xn_basis_file_textBox.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Xn_basis_file_textBox.Name = "Xn_basis_file_textBox";
            this.Xn_basis_file_textBox.Size = new System.Drawing.Size(190, 35);
            this.Xn_basis_file_textBox.TabIndex = 4;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(14, 115);
            this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(331, 29);
            this.label10.TabIndex = 3;
            this.label10.Text = "x[n] basis file for d[n] creation:";
            // 
            // Xn_create_comboBox
            // 
            this.Xn_create_comboBox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.Xn_create_comboBox.FormattingEnabled = true;
            this.Xn_create_comboBox.Items.AddRange(new object[] {
            "Random -(2^15-1) ~ 2^15-1, 32k * 15 samples",
            "Random -(2^14) ~ 2^14, 32k * 15 samples",
            "Random -(2^13) ~ 2^13, 32k * 15 samples"});
            this.Xn_create_comboBox.Location = new System.Drawing.Point(260, 35);
            this.Xn_create_comboBox.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Xn_create_comboBox.Name = "Xn_create_comboBox";
            this.Xn_create_comboBox.Size = new System.Drawing.Size(232, 37);
            this.Xn_create_comboBox.TabIndex = 1;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(16, 40);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(236, 29);
            this.label9.TabIndex = 0;
            this.label9.Text = "x[n] creation method:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(14, 262);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(194, 29);
            this.label6.TabIndex = 8;
            this.label6.Text = "d[n] interference:";
            // 
            // Dn_create_button
            // 
            this.Dn_create_button.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Dn_create_button.Location = new System.Drawing.Point(520, 380);
            this.Dn_create_button.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Dn_create_button.Name = "Dn_create_button";
            this.Dn_create_button.Size = new System.Drawing.Size(156, 54);
            this.Dn_create_button.TabIndex = 14;
            this.Dn_create_button.Text = "Make d[n]";
            this.Dn_create_button.UseVisualStyleBackColor = true;
            this.Dn_create_button.Click += new System.EventHandler(this.Dn_create_button_Click);
            // 
            // Dn_interfere_browse_button
            // 
            this.Dn_interfere_browse_button.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Dn_interfere_browse_button.Location = new System.Drawing.Point(564, 251);
            this.Dn_interfere_browse_button.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Dn_interfere_browse_button.Name = "Dn_interfere_browse_button";
            this.Dn_interfere_browse_button.Size = new System.Drawing.Size(112, 54);
            this.Dn_interfere_browse_button.TabIndex = 10;
            this.Dn_interfere_browse_button.Text = "Browse";
            this.Dn_interfere_browse_button.UseVisualStyleBackColor = true;
            this.Dn_interfere_browse_button.Click += new System.EventHandler(this.Dn_interfere_browse_button_Click);
            // 
            // Dn_interfere_file_textBox
            // 
            this.Dn_interfere_file_textBox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.Dn_interfere_file_textBox.Location = new System.Drawing.Point(214, 257);
            this.Dn_interfere_file_textBox.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Dn_interfere_file_textBox.Name = "Dn_interfere_file_textBox";
            this.Dn_interfere_file_textBox.Size = new System.Drawing.Size(322, 35);
            this.Dn_interfere_file_textBox.TabIndex = 9;
            // 
            // Dn_create_comboBox
            // 
            this.Dn_create_comboBox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.Dn_create_comboBox.FormattingEnabled = true;
            this.Dn_create_comboBox.Items.AddRange(new object[] {
            "Simple echo",
            "Tripple echo",
            "Fully random: -(2^15-1) ~ 2^15-1"});
            this.Dn_create_comboBox.Location = new System.Drawing.Point(260, 185);
            this.Dn_create_comboBox.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Dn_create_comboBox.Name = "Dn_create_comboBox";
            this.Dn_create_comboBox.Size = new System.Drawing.Size(415, 37);
            this.Dn_create_comboBox.TabIndex = 7;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(14, 189);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(239, 29);
            this.label5.TabIndex = 6;
            this.label5.Text = "d[n] creation method:";
            // 
            // Xn_create_button
            // 
            this.Xn_create_button.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Xn_create_button.Location = new System.Drawing.Point(520, 29);
            this.Xn_create_button.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Xn_create_button.Name = "Xn_create_button";
            this.Xn_create_button.Size = new System.Drawing.Size(156, 54);
            this.Xn_create_button.TabIndex = 2;
            this.Xn_create_button.Text = "Make x[n]";
            this.Xn_create_button.UseVisualStyleBackColor = true;
            this.Xn_create_button.Click += new System.EventHandler(this.Xn_create_button_Click);
            // 
            // Graphs_tabPage
            // 
            this.Graphs_tabPage.Controls.Add(this.Graphs_c1Chart);
            this.Graphs_tabPage.Controls.Add(this.Graphs_comboBox);
            this.Graphs_tabPage.Controls.Add(this.Copy_graph_data_button);
            this.Graphs_tabPage.Location = new System.Drawing.Point(4, 38);
            this.Graphs_tabPage.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Graphs_tabPage.Name = "Graphs_tabPage";
            this.Graphs_tabPage.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Graphs_tabPage.Size = new System.Drawing.Size(706, 480);
            this.Graphs_tabPage.TabIndex = 2;
            this.Graphs_tabPage.Text = "Graphs";
            this.Graphs_tabPage.UseVisualStyleBackColor = true;
            // 
            // Graphs_c1Chart
            // 
            this.Graphs_c1Chart.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.Graphs_c1Chart.BackColor = System.Drawing.Color.Transparent;
            this.Graphs_c1Chart.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.Graphs_c1Chart.Location = new System.Drawing.Point(30, 88);
            this.Graphs_c1Chart.Name = "Graphs_c1Chart";
            this.Graphs_c1Chart.PropBag = resources.GetString("Graphs_c1Chart.PropBag");
            this.Graphs_c1Chart.Size = new System.Drawing.Size(644, 281);
            this.Graphs_c1Chart.TabIndex = 3;
            // 
            // Graphs_comboBox
            // 
            this.Graphs_comboBox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.Graphs_comboBox.FormattingEnabled = true;
            this.Graphs_comboBox.Location = new System.Drawing.Point(30, 31);
            this.Graphs_comboBox.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Graphs_comboBox.Name = "Graphs_comboBox";
            this.Graphs_comboBox.Size = new System.Drawing.Size(643, 37);
            this.Graphs_comboBox.TabIndex = 0;
            this.Graphs_comboBox.SelectedIndexChanged += new System.EventHandler(this.Graphs_comboBox_SelectedIndexChanged);
            // 
            // Copy_graph_data_button
            // 
            this.Copy_graph_data_button.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.Copy_graph_data_button.Location = new System.Drawing.Point(562, 389);
            this.Copy_graph_data_button.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Copy_graph_data_button.Name = "Copy_graph_data_button";
            this.Copy_graph_data_button.Size = new System.Drawing.Size(112, 54);
            this.Copy_graph_data_button.TabIndex = 2;
            this.Copy_graph_data_button.Text = "Copy";
            this.Copy_graph_data_button.UseVisualStyleBackColor = true;
            this.Copy_graph_data_button.Click += new System.EventHandler(this.Copy_graph_data_button_Click);
            // 
            // Util_tabPage
            // 
            this.Util_tabPage.Controls.Add(this.Wav_to_bin_button);
            this.Util_tabPage.Controls.Add(this.Util_textBox);
            this.Util_tabPage.Controls.Add(this.File2_browse_button);
            this.Util_tabPage.Controls.Add(this.File1_browse_button);
            this.Util_tabPage.Controls.Add(this.label8);
            this.Util_tabPage.Controls.Add(this.label7);
            this.Util_tabPage.Controls.Add(this.File2_textBox);
            this.Util_tabPage.Controls.Add(this.File1_textBox);
            this.Util_tabPage.Controls.Add(this.Dest_rate_comboBox);
            this.Util_tabPage.Controls.Add(this.Source_rate_comboBox);
            this.Util_tabPage.Controls.Add(this.label4);
            this.Util_tabPage.Controls.Add(this.File_compare_button);
            this.Util_tabPage.Controls.Add(this.PCM_to_wav_button);
            this.Util_tabPage.Location = new System.Drawing.Point(4, 38);
            this.Util_tabPage.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Util_tabPage.Name = "Util_tabPage";
            this.Util_tabPage.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Util_tabPage.Size = new System.Drawing.Size(706, 480);
            this.Util_tabPage.TabIndex = 3;
            this.Util_tabPage.Text = "Util";
            this.Util_tabPage.UseVisualStyleBackColor = true;
            // 
            // Util_textBox
            // 
            this.Util_textBox.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.Util_textBox.Location = new System.Drawing.Point(20, 298);
            this.Util_textBox.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Util_textBox.Multiline = true;
            this.Util_textBox.Name = "Util_textBox";
            this.Util_textBox.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.Util_textBox.Size = new System.Drawing.Size(650, 139);
            this.Util_textBox.TabIndex = 11;
            this.Util_textBox.WordWrap = false;
            // 
            // File2_browse_button
            // 
            this.File2_browse_button.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.File2_browse_button.Location = new System.Drawing.Point(558, 152);
            this.File2_browse_button.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.File2_browse_button.Name = "File2_browse_button";
            this.File2_browse_button.Size = new System.Drawing.Size(112, 54);
            this.File2_browse_button.TabIndex = 9;
            this.File2_browse_button.Text = "Browse";
            this.File2_browse_button.UseVisualStyleBackColor = true;
            this.File2_browse_button.Click += new System.EventHandler(this.File2_browse_button_Click);
            // 
            // File1_browse_button
            // 
            this.File1_browse_button.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.File1_browse_button.Location = new System.Drawing.Point(558, 89);
            this.File1_browse_button.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.File1_browse_button.Name = "File1_browse_button";
            this.File1_browse_button.Size = new System.Drawing.Size(112, 54);
            this.File1_browse_button.TabIndex = 6;
            this.File1_browse_button.Text = "Browse";
            this.File1_browse_button.UseVisualStyleBackColor = true;
            this.File1_browse_button.Click += new System.EventHandler(this.File1_browse_button_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(14, 166);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(92, 29);
            this.label8.TabIndex = 7;
            this.label8.Text = "File #2:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(14, 103);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(92, 29);
            this.label7.TabIndex = 4;
            this.label7.Text = "File #1:";
            // 
            // File2_textBox
            // 
            this.File2_textBox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.File2_textBox.Location = new System.Drawing.Point(112, 162);
            this.File2_textBox.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.File2_textBox.Name = "File2_textBox";
            this.File2_textBox.Size = new System.Drawing.Size(426, 35);
            this.File2_textBox.TabIndex = 8;
            // 
            // File1_textBox
            // 
            this.File1_textBox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.File1_textBox.Location = new System.Drawing.Point(112, 98);
            this.File1_textBox.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.File1_textBox.Name = "File1_textBox";
            this.File1_textBox.Size = new System.Drawing.Size(426, 35);
            this.File1_textBox.TabIndex = 5;
            // 
            // Dest_rate_comboBox
            // 
            this.Dest_rate_comboBox.FormattingEnabled = true;
            this.Dest_rate_comboBox.Items.AddRange(new object[] {
            "16 kHz",
            "32 kHz"});
            this.Dest_rate_comboBox.Location = new System.Drawing.Point(246, 25);
            this.Dest_rate_comboBox.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Dest_rate_comboBox.Name = "Dest_rate_comboBox";
            this.Dest_rate_comboBox.Size = new System.Drawing.Size(180, 37);
            this.Dest_rate_comboBox.TabIndex = 2;
            // 
            // Source_rate_comboBox
            // 
            this.Source_rate_comboBox.FormattingEnabled = true;
            this.Source_rate_comboBox.Items.AddRange(new object[] {
            "16 kHz",
            "32 kHz"});
            this.Source_rate_comboBox.Location = new System.Drawing.Point(12, 25);
            this.Source_rate_comboBox.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Source_rate_comboBox.Name = "Source_rate_comboBox";
            this.Source_rate_comboBox.Size = new System.Drawing.Size(180, 37);
            this.Source_rate_comboBox.TabIndex = 0;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(202, 29);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(33, 29);
            this.label4.TabIndex = 1;
            this.label4.Text = "to";
            // 
            // File_compare_button
            // 
            this.File_compare_button.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.File_compare_button.Location = new System.Drawing.Point(480, 217);
            this.File_compare_button.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.File_compare_button.Name = "File_compare_button";
            this.File_compare_button.Size = new System.Drawing.Size(190, 54);
            this.File_compare_button.TabIndex = 10;
            this.File_compare_button.Text = "File Compare";
            this.File_compare_button.UseVisualStyleBackColor = true;
            this.File_compare_button.Click += new System.EventHandler(this.File_compare_button_Click);
            // 
            // PCM_to_wav_button
            // 
            this.PCM_to_wav_button.Location = new System.Drawing.Point(480, 15);
            this.PCM_to_wav_button.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.PCM_to_wav_button.Name = "PCM_to_wav_button";
            this.PCM_to_wav_button.Size = new System.Drawing.Size(190, 54);
            this.PCM_to_wav_button.TabIndex = 3;
            this.PCM_to_wav_button.Text = "PCM to Wav";
            this.PCM_to_wav_button.UseVisualStyleBackColor = true;
            this.PCM_to_wav_button.Click += new System.EventHandler(this.PCM_to_wav_button_Click);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.Filter = "Wav files|*.wav|PCM files|*.pcm|All files|*.*";
            // 
            // saveFileDialog1
            // 
            this.saveFileDialog1.Filter = "Wav File|*.wav";
            // 
            // Wav_to_bin_button
            // 
            this.Wav_to_bin_button.Location = new System.Drawing.Point(20, 217);
            this.Wav_to_bin_button.Name = "Wav_to_bin_button";
            this.Wav_to_bin_button.Size = new System.Drawing.Size(191, 54);
            this.Wav_to_bin_button.TabIndex = 12;
            this.Wav_to_bin_button.Text = "Wav to Binary";
            this.Wav_to_bin_button.UseVisualStyleBackColor = true;
            this.Wav_to_bin_button.Click += new System.EventHandler(this.Wav_to_bin_button_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(714, 522);
            this.Controls.Add(this.tabControl1);
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "Form1";
            this.Text = "AEC Algorithm";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.tabControl1.ResumeLayout(false);
            this.AEC_tabPage.ResumeLayout(false);
            this.AEC_tabPage.PerformLayout();
            this.Data_tabPage.ResumeLayout(false);
            this.Data_tabPage.PerformLayout();
            this.Graphs_tabPage.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.Graphs_c1Chart)).EndInit();
            this.Util_tabPage.ResumeLayout(false);
            this.Util_tabPage.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage AEC_tabPage;
        private System.Windows.Forms.Button Xn_browse_button;
        private System.Windows.Forms.TextBox Yn_file_textBox;
        private System.Windows.Forms.TextBox Dn_file_textBox;
        private System.Windows.Forms.TextBox Xn_file_textBox;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TabPage Data_tabPage;
        private System.Windows.Forms.Button AEC_run_button;
        private System.Windows.Forms.ComboBox AEC_comboBox;
        private System.Windows.Forms.Button Yn_play_button;
        private System.Windows.Forms.Button Dn_play_button;
        private System.Windows.Forms.Button Xn_play_button;
        private System.Windows.Forms.Button Yn_browse_button;
        private System.Windows.Forms.Button Dn_browse_button;
        private System.Windows.Forms.TextBox AEC_textBox;
        private System.Windows.Forms.TabPage Graphs_tabPage;
        private System.Windows.Forms.TabPage Util_tabPage;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button Dn_create_button;
        private System.Windows.Forms.Button Dn_interfere_browse_button;
        private System.Windows.Forms.TextBox Dn_interfere_file_textBox;
        private System.Windows.Forms.ComboBox Dn_create_comboBox;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button Xn_create_button;
        private System.Windows.Forms.ComboBox Graphs_comboBox;
        private System.Windows.Forms.Button Copy_graph_data_button;
        private System.Windows.Forms.Button PCM_to_wav_button;
        private System.Windows.Forms.TextBox Util_textBox;
        private System.Windows.Forms.Button File2_browse_button;
        private System.Windows.Forms.Button File1_browse_button;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox File2_textBox;
        private System.Windows.Forms.TextBox File1_textBox;
        private System.Windows.Forms.ComboBox Dest_rate_comboBox;
        private System.Windows.Forms.ComboBox Source_rate_comboBox;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button File_compare_button;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.SaveFileDialog saveFileDialog1;
        private System.Windows.Forms.ComboBox Xn_create_comboBox;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button Xn_basis_file_button;
        private System.Windows.Forms.TextBox Xn_basis_file_textBox;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox Dn_gen_file_textBox;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Button Dn_gen_file_button;
        private C1.Win.C1Chart.C1Chart Graphs_c1Chart;
        private System.Windows.Forms.Button Wav_to_bin_button;
    }
}

