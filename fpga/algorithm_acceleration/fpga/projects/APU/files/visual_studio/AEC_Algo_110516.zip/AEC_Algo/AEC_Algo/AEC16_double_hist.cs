﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.Numerics;

namespace AEC_Algo
{
    /// <summary>
    /// This is modified from the Etri 16 kHz floating point. It adds
    /// histograms for key variables, so to identify their dynamic range.
    /// </summary>
    class AEC16_double_hist : I_AEC
    {
        #region Parameters
        // Set simulation parameters
        const int L = 2048;
        const int M = 16;
        const int N = (L / M);
        const int N2 = N * 2;

        // Set parameters for DTD
        const double lam_s = 0.9995;
        const double lam_f = 0.99;
        const double lam_p = 0.92;

        // Set adaptation parameters
        const double mu1 = 0.015625;	// 2^(-6)
        const double mu2 = 0.03125;		// 2^(-5)
        const int nd = 0;

        // Set Threshold
        const double pwr_th = 0.025;
        #endregion

        #region Variables
        // Time domain data buffer
        double[] dp = new double[N];
        double[] xp = new double[N];
        double[] xb = new double[N];
        double[] yp = new double[N];
        double[] ep = new double[N];

        // Frequency domain data buffer
        Complex[,] Wei = new Complex[N2, M];
        Complex[,] Xb = new Complex[N + 1, M + 3 + nd + 1];
        Complex[,] Eb = new Complex[N + 1, M + nd + 1];
        Complex[] Xc = new Complex[N2];
        Complex[] Ys = new Complex[N2];
        Complex[] Ec = new Complex[N2];
        Complex[] dW = new Complex[N2];
        double[] Pi = new double[N + 1];
        int[] Pi_int = new int[N + 1];

        int p_start;
        double pwr, pe, ps;
        //double mu_m; - never used

        int init_blk_cnt;
        //short test_par, test_vec[N], test_vecl[N2];

        short Const_index;
        int index; // originally a global

        public int N_Val
        {
            get { return N; }
        }

        Histogram[] histo_array;
        public Histogram[] Histo_array
        {
            get { return histo_array; }
        }

        public MyGraph[] Graphs
        {
            get { return null; }
        }
        #endregion

        #region Etri Functions
        /// <summary>
        /// Initialize data buffers
        /// </summary>
        public void aec_init()
        {
            int k, m;
            for (k = 0; k < N; k++)
            {
                dp[k] = 0;
                xp[k] = 0;
                yp[k] = 0;
                xb[k] = 0;
            }
            for (k = 0; k < N + 1; k++)
            {
                for (m = 0; m < M; m++)
                {
                    Wei[k, m] = 0;
                }
                for (m = 0; m < M + 3 + nd + 1; m++)
                {
                    Xb[k, m] = 0;
                }
                for (m = 0; m < M + nd + 1; m++)
                {
                    Eb[k, m] = 0;
                }
                Pi[k] = 0.1;
            }
            for (k = 0; k < N2; k++)
            {
                Xc[k] = 0;
                Ys[k] = 0;
                Ec[k] = 0;
                dW[k] = 0;
            }
            p_start = 0;
            pe = 0;
            ps = 0;
            init_blk_cnt = 0;
            Const_index = -1;

            index = -1; //originally done in main()

            //Histograms
            histo_array = new Histogram[4];
            histo_array[0] = new Histogram("Wei histogram", -32, 2, 1);
            histo_array[1] = new Histogram("Eb histogram", -32, 2, 1);
            histo_array[2] = new Histogram("Xb histogram", -32, 2, 1);
            histo_array[3] = new Histogram("Pi histogram", -32, 32, 1);
        }

        /// <summary>
        /// AEC function that process a single frame of data.
        /// </summary>
        public void aec(int[] dn, int[] xn, int[] output)
        {
            index++; //originally done in main()

            int i, k, m;
            double pe_c, ps_c, pwr_c;
            Complex[] Rb = new Complex[N2];
            double mu, mu_k;
            //double cfaca; -- not used

            // Take new input frames
            for (i = 0; i < N; i++)
            {
                dp[i] = (double)dn[i] / 32768d;
                xp[i] = (double)xn[i] / 32768d;
                Xc[i] = xb[i];
                Xc[i + N] = xp[i];
            }

            // Transform the reference input frame using FFT
            CVector.FFT(Xc);
            divide_by(Xc, Xc.Length);

            for (m = M + nd + 3; m > 0; m--)
            {
                for (k = 0; k < N + 1; k++)
                {
                    Xb[k, m] = Xb[k, m - 1];
                }
            }
            for (k = 0; k < N + 1; k++)
            {
                Xb[k, 0] = Xc[k];
                update_histo_array(2, Xb[k, 0]);
            }
            for (i = 0; i < N; i++)
                xb[i] = xp[i];

            // Compute the filter output
            for (k = 0; k < N + 1; k++)
            {
                Ys[k] = 0;
            }

            for (m = 0; m < M; m++)
            {
                for (k = 0; k < N + 1; k++)
                {
                    Ys[k] += Xb[k, m] * Wei[k, m];
                }
            }
            for (k = 1; k < N; k++)
            {
                Ys[N2 - k] = Complex.Conjugate(Ys[k]);
            }

            CVector.Inverse_FFT(Ys);
            multiply_by(Ys, Ys.Length);

            for (i = 0; i < N; i++)
            {
                yp[i] = Ys[i + N].Real;
            }

            // Compute the error vector
            for (i = 0; i < N; i++)
            {
                Ec[i] = 0;
                ep[i] = dp[i] - yp[i];
                Ec[i + N] = ep[i];
            }

            CVector.FFT(Ec);
            divide_by(Ec, Ec.Length);

            for (m = M + nd; m > 0; m--)
            {
                for (k = 0; k < N + 1; k++)
                {
                    Eb[k, m] = Eb[k, m - 1];
                }
            }
            for (k = 0; k < N + 1; k++)
            {
                Eb[k, 0] = Ec[k];
                update_histo_array(1, Eb[k, 0]);
            }

            // Step-size control
            if (p_start == 0)
            {
                pwr = 0;
                for (i = 0; i < N; i++)
                {
                    if (xp[i] > 0)
                        pwr += xp[i];
                    else
                        pwr -= xp[i];
                }
                pwr /= N;
                p_start = 1;
            }
            else
            {
                pwr_c = 0;
                for (i = 0; i < N; i++)
                {
                    if (xp[i] > 0)
                        pwr_c += xp[i];
                    else
                        pwr_c -= xp[i];
                }
                pwr_c /= N;
                pwr = lam_p * pwr + (1d - lam_p) * pwr_c;
            }
            for (i = 0; i < N; i++)
            {
                ps_c = dp[i] * dp[i] - yp[i] * yp[i];
                if (ps_c < 0)
                    ps_c *= (-1);
                if (ps_c > ps)
                    ps = lam_f * ps + (1d - lam_f) * ps_c;
                else
                    ps = lam_s * ps + (1d - lam_s) * ps_c;
                pe_c = ep[i] * ep[i];
                if (pe_c > pe)
                    pe = lam_f * pe + (1d - lam_f) * pe_c;
                else
                    pe = lam_s * pe + (1d - lam_s) * pe_c;
            }

            if (index < 200)
                mu = mu1;
            else
                mu = mu2;

            // Adaptation control
            if (pwr < pwr_th)
            {
                mu_k = 0;
            }
            else
            {
                // Run initial tens frame without condition
                if (init_blk_cnt < 100)
                {
                    init_blk_cnt++;
                    mu_k = mu;
                }
                else
                {
                    if (pe < 0.35f * ps)
                    {
                        mu_k = mu;
                    }
                    else if (pe < 0.4f * ps)
                    {
                        mu_k = mu / 2;
                    }
                    else if (pe < 0.5f * ps)
                    {
                        mu_k = mu / 4;
                    }
                    else if (pe < 0.65f * ps)
                    {
                        mu_k = mu / 8;
                    }
                    else
                    {
                        mu_k = 0;
                    }
                }
            }

            // Compute pwrs of freq. bins
            for (k = 0; k < N + 1; k++)
                Pi[k] = 0;
            for (k = 0; k < N + 1; k++)
            {
                for (m = 0; m < M + nd + 4; m++)
                {
                    Pi[k] += ((Xb[k, m].Real * Xb[k, m].Real + Xb[k, m].Imaginary * Xb[k, m].Imaginary) * N2 * N2);
                }
                Pi[k] /= M;
                update_histo_array(3, Pi[k]);
                Pi_int[k] = (int)(Pi[k] + 1);
            }
            
            for (k = 0; k < N + 1; k++)
            {
                int tmp;
                int nshift;
                tmp = Pi_int[k];
                nshift = 0;
                tmp >>= 1;
                if (tmp > 1)
                {
                    nshift++;
                    tmp >>= 1;
                    if (tmp > 1)
                    {
                        nshift++;
                        tmp >>= 1;
                        if (tmp > 1)
                        {
                            nshift++;
                            tmp >>= 1;
                            if (tmp > 1)
                            {
                                nshift++;
                                tmp >>= 1;
                                if (tmp > 1)
                                {
                                    nshift++;
                                    tmp >>= 1;
                                    if (tmp > 1)
                                    {
                                        nshift++;
                                        tmp >>= 2;
                                        if (tmp > 1)
                                        {
                                            nshift = nshift + 2;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                Pi[k] = nshift;
            }

            // Weight update -NLMS
            if (Const_index < 3)
                Const_index++;
            else
                Const_index = 0;
            for (m = 0; m < M; m++)
            {
                for (k = 0; k < N + 1; k++)
                {
                    Rb[k] = mu_k * Complex.Conjugate(Xb[k, m + nd]) * Eb[k, nd] * (double)(1 << (int)(16 - Pi[k]));
                }

                // Weight Vector Constraint Part
                if ((m == Const_index) || (m == (Const_index + 4)) || (m == (Const_index + 8)) || (m == (Const_index + 12)))
                {
                    dW[0] = Wei[0, m] + Rb[0];

                    for (k = 1; k < N; k++)
                    {
                        dW[k] = Wei[k, m] + Rb[k];
                        dW[N2 - k] = Complex.Conjugate(dW[k]);
                    }

                    dW[N] = Wei[N, m] + Rb[N];

                    CVector.Inverse_FFT(dW);
                    multiply_by(dW, dW.Length);

                    for (k = 0; k < N; k++)
                    {
                        dW[k] = dW[k].Real;
                        dW[k + N] = 0;
                    }

                    CVector.FFT(dW);
                    divide_by(dW, dW.Length);

                    for (k = 0; k < N + 1; k++)
                    {
                        Wei[k, m] = dW[k];
                        update_histo_array(0, Wei[k, m]);
                    }
                }
                else
                {
                    // Unconstraint Part
                    for (k = 0; k < N + 1; k++)
                    {
                        Wei[k, m] += Rb[k];
                        update_histo_array(0, Wei[k, m]);
                    }
                }
            }

            for (i = 0; i < N; i++)
            {
                output[i] = (int)(ep[i] * 32768d + 0.5);
            }
        }

        /// <summary>
        /// Pace holder only. Not used in this version of the AEC
        /// </summary>
        public void aec_end()
        {
        }
        #endregion

        #region Helper Functions
        /// <summary>
        /// This function divides every element of the c_array by the divisor.
        /// </summary>
        private void divide_by(Complex[] c_array, double divisor)
        {
            for (int i = 0; i < c_array.Length; i++)
                c_array[i] = c_array[i] / divisor;
        }

        /// <summary>
        /// This function multiply every element of the c_array by the multiplicand.
        /// </summary>
        private void multiply_by(Complex[] c_array, double multiplicand)
        {
            for (int i = 0; i < c_array.Length; i++)
                c_array[i] = c_array[i] * multiplicand;
        }

        /// <summary>
        /// Upate the histogram at histo_array[index] with a complex value
        /// </summary>
        private void update_histo_array(int index, Complex val)
        {
            double val_log;
            if (val.Real != 0)
            {
                val_log = Math.Log(val.Real, 2);
                histo_array[index].add_value(val_log);
            }
            if (val.Imaginary != 0)
            {
                val_log = Math.Log(val.Imaginary, 2);
                histo_array[index].add_value(val_log);
            }
        }

        /// <summary>
        /// Upate the histogram at histo_array[index] with a double value
        /// </summary>
        private void update_histo_array(int index, double val)
        {
            double val_log;
            if (val != 0)
            {
                val_log = Math.Log(val, 2);
                histo_array[index].add_value(val_log);
            }
        }
        #endregion
    }
}
