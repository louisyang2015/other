﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.Numerics;

namespace AEC_Algo
{
    /// <summary>
    /// This is part 1 of the FPGA port. This port focus on
    /// re-organizing the code to better suit FPGA execution. Also,
    /// the Xb and Eb memories are no longer being shifted around.
    /// The output of this port should match the double precision
    /// outputs exactly.
    /// </summary>
    class AEC32_FPGA_port1 : I_AEC
    {
        #region Parameters
        // Set simulation parameters
        const int L = 2048 * 2; //16kHz: 2048
        const int M = 16;
        const int N = (L / M);
        const int N2 = N * 2;

        // Set parameters for DTD
        const double lam_s = 0.9995;
        const double lam_f = 0.99;
        const double lam_p = 0.92;

        // Set adaptation parameters
        const double mu1 = 0.015625;	// 2^(-6)
        const double mu2 = 0.03125;		// 2^(-5)
        const int nd = 0;

        // Set Threshold
        const double pwr_th = 0.025;
        #endregion

        #region Variables
        // Time domain data buffer
        double[] dp = new double[N];
        double[] xp = new double[N];
        double[] xb = new double[N];
        double[] yp = new double[N];
        double[] ep = new double[N];

        // Frequency domain data buffer
        Complex[,] Wei = new Complex[M, N2];
        Complex[,] Xb = new Complex[M + 3 + nd + 1, N + 1];
        Complex[,] Eb = new Complex[M + nd + 1, N + 1];
        Complex[] Xc = new Complex[N2];
        Complex[] Ys = new Complex[N2];
        Complex[] Ec = new Complex[N2];
        Complex[] dW = new Complex[N2];
        double[] Pi = new double[N + 1];
        int[] Pi_int = new int[N + 1];

        int p_start;
        double pwr, pe, ps;

        int init_blk_cnt;

        short Const_index;
        int index; 

        //Xb and Eb zero location
        int Xb_offset, Eb_offset;
        int Xb_num_rows, Eb_num_rows;
        int Xb_index, Eb_index; //real index = Xb_offset + for loop index

        public int N_Val
        {
            get { return N; }
        }

        public Histogram[] Histo_array
        {
            get { return null; }
        }

        public MyGraph[] Graphs
        {
            get { return null; }
        }
        #endregion

        #region Etri Functions
        /// <summary>
        /// Initialize data buffers
        /// </summary>
        public void aec_init()
        {
            int k, m;
            for (k = 0; k < N; k++)
            {
                dp[k] = 0;
                xp[k] = 0;
                yp[k] = 0;
                xb[k] = 0;
            }
            for (k = 0; k < N + 1; k++)
            {
                for (m = 0; m < M; m++)
                {
                    Wei[m, k] = 0;
                }
                for (m = 0; m < M + 3 + nd + 1; m++)
                {
                    Xb[m, k] = 0;
                }
                for (m = 0; m < M + nd + 1; m++)
                {
                    Eb[m, k] = 0;
                }
                Pi[k] = 0.1;
            }
            for (k = 0; k < N2; k++)
            {
                Xc[k] = 0;
                Ys[k] = 0;
                Ec[k] = 0;
                dW[k] = 0;
            }
            p_start = 0;
            pe = 0;
            ps = 0;
            init_blk_cnt = 0;
            Const_index = -1;

            index = -1; //originally done in main()

            //additional variables for FPGA
            Xb_offset = 0; 
            Eb_offset = 0;
            Xb_num_rows = M + 3 + nd + 1;
            Eb_num_rows = M + nd + 1;
        }

        /// <summary>
        /// AEC function that process a single frame of data.
        /// </summary>
        public void aec(int[] dn, int[] xn, int[] output)
        {
            index++; //originally done in main()

            int i, k, m;
            Complex[] Rb = new Complex[N2];
            double mu, mu_k;

                        
            //---------------------------------------------------------------------
            // NIOS2 will stuff xn[] into array processor, into Xc[]
            // NIOS 2 will stuff xb[] into Xc[]
            // then copy xp[i] into xb[i] because there
            // is no more use for the xb[i]

            // temp only:
            for (i = 0; i < N; i++)
                xp[i] = (double)xn[i] / 32768d;

            //NIOS 2 --> FPGA
            for (i = 0; i < N; i++)
            {                               
                Xc[i] = xb[i];                
                Xc[i + N] = xp[i];
            }

            //NIOS 2
            for (i = 0; i < N; i++)
                xb[i] = xp[i];

            //---------------------------------------------------------------------
            // Transform the reference input frame using FFT
            // FPGA
            CVector.FFT(Xc);
            divide_by(Xc, Xc.Length);

            //---------------------------------------------------------------------
            //modify the "0" location of the Xb array, so to avoid
            //having to shift array elements
            //NIOS 2
            Xb_offset--;
            if (Xb_offset < 0) Xb_offset = Xb_offset + Xb_num_rows;
            //FPGA
            for (k = 0; k < N + 1; k++)
            {
                Xb[Xb_offset, k] = Xc[k];
            }

            //---------------------------------------------------------------------
            // Compute the filter output
            // FPGA
            for (k = 0; k < N + 1; k++)
            {
                Ys[k] = 0;
            }

            for (k = 0; k < N + 1; k++)
            {                
                for (m = 0; m < M; m++)
                {
                    Xb_index = Xb_offset + m;
                    if (Xb_index > Xb_num_rows - 1) Xb_index = Xb_index - Xb_num_rows;
                    Ys[k] += Xb[Xb_index, k] * Wei[m, k];
                }
            }
            for (k = 1; k < N; k++)
            {
                Ys[N2 - k] = Complex.Conjugate(Ys[k]);
            }

            

            //---------------------------------------------------------------------
            // FPGA
            CVector.Inverse_FFT(Ys);
            multiply_by(Ys, Ys.Length);

            // FPGA
            for (i = 0; i < N; i++)
            {
                yp[i] = Ys[i + N].Real;
            }

            //---------------------------------------------------------------------            
            // NIOS 2 will compute the "pwr" variable as well. It is the sum of |xp[i]|
            // NIOS 2
            pwr = 0;
            for (i = 0; i < N; i++)
            {
                xp[i] = (double)xn[i] / 32768d;
                if (xp[i] > 0) pwr += xp[i] / N;
                else pwr -= xp[i] / N;
            }

            //---------------------------------------------------------------------
            // NIOS 2 needs to read yp[i]
            // Compute the error vector ep[i] and send it to the output
            // Create Ec and do FFT
            // NIOS 2
            for (i = 0; i < N; i++)
            {
                dp[i] = (double)dn[i] / 32768d; 
                ep[i] = dp[i] - yp[i];
                output[i] = (int)(ep[i] * 32768d + 0.5);                
            }

            // NIOS 2 --> FPGA
            for (i = 0; i < N; i++)
            {
                Ec[i] = 0;
                Ec[i + N] = ep[i];
            }

            //---------------------------------------------------------------------
            // FPGA
            CVector.FFT(Ec);
            divide_by(Ec, Ec.Length);

            //---------------------------------------------------------------------
            // Store Ec
            // NIOS 2
            Eb_offset--; //so no need to shift Ec array
            if (Eb_offset < 0) Eb_offset += Eb_num_rows;
            // FPGA
            for (k = 0; k < N + 1; k++)
            {
                Eb[Eb_offset, k] = Ec[k];
            }

            //---------------------------------------------------------------------
            // Compute Pi_int[k] - power of freq bins
            for (k = 0; k < N + 1; k++)
                Pi[k] = 0;
            for (k = 0; k < N + 1; k++)
            {
                for (m = 0; m < M + nd + 4; m++)
                {
                    Xb_index = Xb_offset + m;
                    if (Xb_index > Xb_num_rows - 1) Xb_index = Xb_index - Xb_num_rows;
                    Pi[k] += ((Xb[Xb_index, k].Real * Xb[Xb_index, k].Real + Xb[Xb_index, k].Imaginary * Xb[Xb_index, k].Imaginary) * N2 * N2);
                }
                Pi[k] /= M;
                Pi[k] = Pi[k] + 1;

                Pi_int[k] = 0;
                if (Pi[k] >= 4)
                    Pi_int[k] = 1;
                if (Pi[k] >= 8)
                    Pi_int[k] = 2;
                if (Pi[k] >= 16)
                    Pi_int[k] = 3;
                if (Pi[k] >= 32)
                    Pi_int[k] = 4;
                if (Pi[k] >= 64)
                    Pi_int[k] = 5;
                if (Pi[k] >= 128)
                    Pi_int[k] = 6;
                if (Pi[k] >= 512)
                    Pi_int[k] = 8;
                Pi_int[k] = 16 - Pi_int[k];
            }

            //---------------------------------------------------------------------
            // Do the following in NIOS 2 - use floating point
            // Compute ps_c_array[i] = | dp[i]^2 - yp[i]^2 |
            // Compute pe_c_array[i] = ep[i] * ep[i];
            // Start of long NIOS 2 block
            double[] ps_c_array = new double[N];
            double[] pe_c_array = new double[N];
            for (i = 0; i < N; i++)
            {
                ps_c_array[i] = dp[i] * dp[i] - yp[i] * yp[i];
                if (ps_c_array[i] < 0)
                    ps_c_array[i] *= (-1);
                ep[i] = dp[i] - yp[i];
                pe_c_array[i] = ep[i] * ep[i];
            }

            // Step-size control
            if (p_start == 0)
            {
                p_start = 1;
            }
            else
            {
                pwr = lam_p * pwr + (1d - lam_p) * pwr;
            }
            for (i = 0; i < N; i++)
            {                                
                if (ps_c_array[i] > ps)
                    ps = lam_f * ps + (1d - lam_f) * ps_c_array[i];
                else
                    ps = lam_s * ps + (1d - lam_s) * ps_c_array[i];

                if (pe_c_array[i] > pe)
                    pe = lam_f * pe + (1d - lam_f) * pe_c_array[i];
                else
                    pe = lam_s * pe + (1d - lam_s) * pe_c_array[i];
            }

            if (index < 200)
                mu = mu1;
            else
                mu = mu2;

            // Adaptation control
            if (pwr < pwr_th)
            {
                mu_k = 0;
            }
            else
            {
                // Run initial tens frame without condition
                if (init_blk_cnt < 100)
                {
                    init_blk_cnt++;
                    mu_k = mu;
                }
                else
                {
                    if (pe < 0.35f * ps)
                    {
                        mu_k = mu;
                    }
                    else if (pe < 0.4f * ps)
                    {
                        mu_k = mu / 2;
                    }
                    else if (pe < 0.5f * ps)
                    {
                        mu_k = mu / 4;
                    }
                    else if (pe < 0.65f * ps)
                    {
                        mu_k = mu / 8;
                    }
                    else
                    {
                        mu_k = 0;
                    }
                }
            }

            // Weight update -NLMS
            if (Const_index < 3)
                Const_index++;
            else
                Const_index = 0;
            // End of long NIOS 2 block
            //---------------------------------------------------------------------

            for (m = 0; m < M; m++)
            {
                // NIOS 2
                Xb_index = Xb_offset + m;
                if (Xb_index > Xb_num_rows - 1) Xb_index = Xb_index - Xb_num_rows;
                Eb_index = Eb_offset + nd;
                if (Eb_index > Eb_num_rows - 1) Eb_index = Eb_index - Eb_num_rows;

                //---------------------------------------------------------------------
                // Compute Rb[] from Xb[][], Eb[][], and Pi_int[]
                // FPGA
                for (k = 0; k < N + 1; k++)
                {
                    Rb[k] = mu_k * Complex.Conjugate(Xb[Xb_index + nd, k]) * Eb[Eb_index, k] * (double)(1 << Pi_int[k]);
                }

                // Weight Vector Constraint Part
                if ((m == Const_index) || (m == (Const_index + 4)) || (m == (Const_index + 8)) || (m == (Const_index + 12)))
                {
                    //---------------------------------------------------------------------
                    // Create dW[] from Wei and Rb[]
                    // FPGA:
                    dW[0] = Wei[m, 0] + Rb[0];

                    for (k = 1; k < N; k++)
                    {
                        dW[k] = Wei[m, k] + Rb[k];
                        dW[N2 - k] = Complex.Conjugate(dW[k]);
                    }

                    dW[N] = Wei[m, N] + Rb[N];

                    //---------------------------------------------------------------------
                    // Inverse FFT on dW, then FFT
                    // FPGA
                    CVector.Inverse_FFT(dW);
                    multiply_by(dW, dW.Length);

                    for (k = 0; k < N; k++)
                    {
                        dW[k] = dW[k].Real;
                        dW[k + N] = 0;
                    }

                    CVector.FFT(dW);
                    divide_by(dW, dW.Length);

                    //---------------------------------------------------------------------
                    // Store dW to Wei
                    // FPGA
                    for (k = 0; k < N + 1; k++)
                    {
                        Wei[m, k] = dW[k];
                    }
                }
                else
                {
                    //---------------------------------------------------------------------
                    // Unconstraint Part
                    // Add Rb to Wei
                    // FPGA
                    for (k = 0; k < N + 1; k++)
                    {
                        Wei[m, k] += Rb[k];
                    }
                }
            }
        }

        /// <summary>
        /// Pace holder only. Not used in this version of the AEC
        /// </summary>
        public void aec_end()
        {
        }
        #endregion

        #region Helper Functions
        /// <summary>
        /// This function divides every element of the c_array by the divisor.
        /// </summary>
        private void divide_by(Complex[] c_array, double divisor)
        {
            for (int i = 0; i < c_array.Length; i++)
                c_array[i] = c_array[i] / divisor;
        }

        /// <summary>
        /// This function multiply every element of the c_array by the multiplicand.
        /// </summary>
        private void multiply_by(Complex[] c_array, double multiplicand)
        {
            for (int i = 0; i < c_array.Length; i++)
                c_array[i] = c_array[i] * multiplicand;
        }
        #endregion
    }
}
