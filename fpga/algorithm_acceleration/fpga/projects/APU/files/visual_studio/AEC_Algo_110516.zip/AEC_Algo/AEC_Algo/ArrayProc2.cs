﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.Numerics;

namespace AEC_Algo
{
    /// <summary>
    /// This class simulates the work that will be done by the FPGA
    /// </summary>
    class ArrayProc2
    {
        #region Parameters     
        // AEC Simulation parameters
        // need to call init(...) to set these
        int M;
        int N2;

        /// <summary>
        /// Sets simulation parameters: L, M, N, N2, and nd. Then allocate
        /// internal memory according to these parameters.
        /// </summary>
        public void init_param(int M, int N, int N2, int nd)
        {
            this.M = M;
            this.N2 = N2;
            //ssram = new int[(M * N2 + (M + 3 + nd + 1) * (N + 1) + (M + nd + 1) * (N + 1)) * 2];
            ssram = new int[32*1024];
            A0 = new Complex[N2]; A1 = new Complex[N2];
            B0 = new Complex[N2]; B1 = new Complex[N2];
            //C0 = new int[N + 1];
            C0 = new int[N2];
        }

        // SSRAM Size
        public int ssram_size
        {
            get { return ssram.Length; }
        }
   
        // Fraction for converting from integer to the Q format        
        double fraction = Math.Pow(2, -31);        
        public double Fraction
        {
            get { return fraction; }
        }
        public float Fraction_F
        {
            get { return (float)fraction; }
        }

        // NIOS 2 instruction fields:
        public enum DEST { A0=0, A1, B0, B1, A0r, A1r, B0r, B1r, A0i, A1i, B0i, B1i, A0_1, 
                B0_1, ALL_MEM, NONE_MEM}
        public enum SOURCE { A0=0, A1, B0, B1}
        public enum ALU_COPY_MODE {SIMPLE_COPY=2, REAL_COPY=3, RI_SWAP=4, CONJUGATE=5,
                ROUND_SAT=6, LSHIFT16=7}
        public enum T_SOURCE { ONE=1, A0, A0_Conjugate }

        // currently not used:
        // private enum DATA_TYPE { real_only, real_imag }
        // private enum SHIFT_TYPE { none, left8, left9, left16, right8, right9 }
        #endregion

        #region SSRAM
        int[] ssram;
        int ssram_addr, ssram_skip, ssram_highest_addr, ssram_block_size;
        /// <summary>
        /// Sets the SSRAM address generator (AG) "address" register.
        /// </summary>
        public void ssram_set_addr(int n)
        {
            ssram_addr = n;
        }
        /// <summary>
        /// Sets the SSRAM address generator (AG) "skip" register.
        /// </summary>
        public void ssram_set_skip(int n)
        {
            ssram_skip = n;
        }
        /// <summary>
        /// Sets the SSRAM address generator (AG) "highest_addr" register.
        /// </summary>
        public void ssram_set_highest_addr(int n)
        {
            ssram_highest_addr = n;
        }
        /// <summary>
        /// Sets the SSRAM address generator (AG) "block_size" register.
        /// </summary>
        public void ssram_set_block_size(int n)
        {
            ssram_block_size = n;
        }
        /// <summary>
        /// Reset a range of SSRAM address to zero. The counting is based
        /// on the current settings in the ssram address generator (AG).
        /// </summary>
        public void ssram_reset(int length)
        {
            for (int i = 0; i < length; i++)
            {
                ssram[ssram_addr] = 0;
                ssram_addr = ssram_addr + ssram_skip;
                if (ssram_addr > ssram_highest_addr)
                    ssram_addr = ssram_addr - ssram_block_size;
            }
        }
        /// <summary>
        /// Copies value from internal memory to the SSRAM. 
        /// The counting is based on the current settings in 
        /// the ssram address generator (AG).
        /// </summary>
        public void ssram_write(SOURCE source, int imag, int length, int source_start)
        {
            for (int i = 0; i < length; i++)
            {
                Complex v = get_complex_val(source, source_start + i);

                if (imag == 0) ssram[ssram_addr] = double_to_int(v.Real);
                else ssram[ssram_addr] = double_to_int(v.Imaginary);

                ssram_addr = ssram_addr + ssram_skip;
                if (ssram_addr > ssram_highest_addr)
                    ssram_addr = ssram_addr - ssram_block_size;
            }
        }
        /// <summary>
        /// Copies value from SSRAM to the internal memory. 
        /// The counting is based on the current settings in 
        /// the ssram address generator (AG).
        /// </summary>
        public void ssram_read(DEST dest, int length, int dest_start)
        {
            for (int i = 0; i < length; i++)
            {
                int v = ssram[ssram_addr];

                place_data(dest, dest_start + i, v * fraction, v * fraction);

                // note in this implmentation, the "block_size" is not really the block size.
                // it's more like a wrap_around_value - it should get a new name in 
                // the next version of the array processor.
                // so the wrap around is NOT computed by:
                // ssram_addr_new = ssram_addr + ssram_skip - ssram_block_size
                int ssram_addr_new = ssram_addr + ssram_skip;
                if (ssram_addr_new > ssram_highest_addr)
                    ssram_addr_new = ssram_addr - ssram_block_size;

                ssram_addr = ssram_addr_new;
            }
        }

        #endregion


        #region Internal Memories
        Complex[] A0, A1, B0, B1;
        int[] C0; //Pi_int
       
        /// <summary>
        /// NIOS 2 will send data into the array processor
        /// </summary>
        public void send_data(DEST dest, int[] i_array, int length)
        {
            for (int i = 0; i < length; i++)
            {
                double new_val = i_array[i] * fraction;
                place_data(dest, i, new_val, new_val);
            }
        }

        /// <summary>
        /// Return data to NIOS 2
        /// </summary>
        public int[] get_data(SOURCE source, int real, int start_index, int length)
        {            
            // copy only real component to fifo_out[]
            int[] i_array = new int[length];
            for (int i = 0; i < length; i++)
            {
                if (real != 0)
                {
                    if (source == SOURCE.A0) i_array[i] = double_to_int(A0[start_index + i].Real);
                    else if (source == SOURCE.A1) i_array[i] = double_to_int(A1[start_index + i].Real);
                    else if (source == SOURCE.B0) i_array[i] = double_to_int(B0[start_index + i].Real);
                    else if (source == SOURCE.B1) i_array[i] = double_to_int(B1[start_index + i].Real);
                }
                else
                {
                    if (source == SOURCE.A0) i_array[i] = double_to_int(A0[start_index + i].Imaginary);
                    else if (source == SOURCE.A1) i_array[i] = double_to_int(A1[start_index + i].Imaginary);
                    else if (source == SOURCE.B0) i_array[i] = double_to_int(B0[start_index + i].Imaginary);
                    else if (source == SOURCE.B1) i_array[i] = double_to_int(B1[start_index + i].Imaginary);
                }
            }
            return i_array;
        }

        /// <summary>
        /// This operation copy data from "source" to "dest". The source
        /// of the copy is source[source_start] to source[source_start + length - 1].
        /// The destination of the copy is dest[dest_start] to 
        /// dest[dest_start + length - 1].
        /// </summary>
        public void copy_general(ALU_COPY_MODE alu_mode, SOURCE src, DEST dest, int length, 
                int src_start, int dest_start)
        {
            for (int i = 0; i < length; i++)
            {
                // fetch data from source
                Complex val = 0;
                if (src == SOURCE.A0) val = A0[src_start + i];
                else if (src == SOURCE.A1) val = A1[src_start + i];
                else if (src == SOURCE.B0) val = B0[src_start + i];
                else if (src == SOURCE.B1) val = B1[src_start + i];

                // modify data if needed
                if (alu_mode != ALU_COPY_MODE.SIMPLE_COPY)
                {
                    if (alu_mode == ALU_COPY_MODE.CONJUGATE) val = Complex.Conjugate(val);
                    else if (alu_mode == ALU_COPY_MODE.LSHIFT16) val = val * 65536;
                    else if (alu_mode == ALU_COPY_MODE.REAL_COPY) val = val.Real;
                    else if (alu_mode == ALU_COPY_MODE.RI_SWAP)
                        val = new Complex(val.Imaginary, val.Real);
                    else if (alu_mode == ALU_COPY_MODE.ROUND_SAT)
                    {
                        double real = val.Real;
                        double imag = val.Imaginary;
                        val = new Complex(double_to_int(real) * fraction,
                                double_to_int(imag) * fraction);
                    }
                }

                // put data into destination
                place_data(dest, dest_start + i, val.Real, val.Imaginary);
            }
        }

        /// <summary>
        /// Copy data from source to destination
        /// </summary>
        public void copy_data(SOURCE src, DEST dest, int length, int src_start, int dest_start)
        {
            copy_general(ALU_COPY_MODE.SIMPLE_COPY, src, dest, length, src_start, dest_start);
        }
        /// <summary>
        /// Copy data from source to destination, copy only the real part. Imaginary part is
        /// set to zero.
        /// </summary>
        public void copy_real(SOURCE src, DEST dest, int length, int src_start, int dest_start)
        {
            copy_general(ALU_COPY_MODE.REAL_COPY, src, dest, length, src_start, dest_start);
        }
        public void copy_swap(SOURCE src, DEST dest, int length, int src_start, int dest_start)
        {
            copy_general(ALU_COPY_MODE.RI_SWAP, src, dest, length, src_start, dest_start);
        }
        public void copy_conjugate(SOURCE src, DEST dest, int length, int src_start, 
            int dest_start)
        {
            copy_general(ALU_COPY_MODE.CONJUGATE, src, dest, length, src_start, dest_start);
        }
        public void copy_round(SOURCE src, DEST dest, int length, int src_start, int dest_start)
        {
            copy_general(ALU_COPY_MODE.ROUND_SAT, src, dest, length, src_start, dest_start);
        }
        public void copy_shift16(SOURCE src, DEST dest, int length, int src_start, int dest_start)
        {
            copy_general(ALU_COPY_MODE.LSHIFT16, src, dest, length, src_start, dest_start);
        }

        /// <summary>
        /// This function loads zeros into the specified memory.
        /// </summary>
        public void reset_memory(DEST dest, int dest_start, int length)
        {
            for (int i = dest_start; i < dest_start + length; i++)
            {
                place_data(dest, i, 0, 0);
            }
        }

        #endregion

        #region FFT Operations
        /// <summary>
        /// 32 point FFT on values in memA, with result in memA
        /// fft_shift: 0=no shift; 1=left shift; 3=right shift;
        /// </summary>
        public void FFT32_A2A(int fft_shift)
        {
            Complex[] c_array = new Complex[32];
            for (int i = 0; i < 16; i++) c_array[i] = A0[i];
            for (int i = 16; i < 32; i++) c_array[i] = A1[i - 16];

            CVector.FFT(c_array);
            if (fft_shift == 1) multiply_by(c_array, 32);
            else if (fft_shift == 3) divide_by(c_array, 32);

            // in this simulation B0 and B1 are set to zeros - but in reality
            // they won't be zeros
            for (int i = 0; i < 16; i++)
            {
                A0[i] = c_array[i]; A1[i] = c_array[i + 16];
                B0[i] = 0; B1[i] = 0;                
            }
        }

        /// <summary>
        /// 32 point FFT on values in memB, with result in memB
        /// fft_shift: 0=no shift; 1=left shift; 3=right shift;
        /// </summary>
        public void FFT32_B2B(int fft_shift)
        {
            Complex[] c_array = new Complex[32];
            for (int i = 0; i < 16; i++) c_array[i] = B0[i];
            for (int i = 16; i < 32; i++) c_array[i] = B1[i - 16];

            CVector.FFT(c_array);
            if (fft_shift == 1) multiply_by(c_array, 32);
            else if (fft_shift == 3) divide_by(c_array, 32);

            // in this simulation A0 and A1 are set to zeros - but in reality
            // they won't be zeros
            for (int i = 0; i < 16; i++)
            {
                B0[i] = c_array[i]; B1[i] = c_array[i + 16];
                A0[i] = 0; A1[i] = 0;
            }
        }

        /// <summary>
        /// 32 point INVERSE FFT on values in memA, with result in memA.        
        /// fft_shift: 0=no shift, 1=left shift, 3=right shift.
        /// There is NO automatic 1/32 scaling of the result.
        /// </summary>
        public void iFFT32_A2A(int fft_shift)
        {
            Complex[] c_array = new Complex[32];
            for (int i = 0; i < 16; i++) c_array[i] = A0[i];
            for (int i = 16; i < 32; i++) c_array[i] = A1[i - 16];

            CVector.Inverse_FFT(c_array);
            multiply_by(c_array, 32); // to undo the automatic 1/32 scaling
            if (fft_shift == 1) multiply_by(c_array, 32);
            else if (fft_shift == 3) divide_by(c_array, 32);

            // in this simulation B0 and B1 are set to zeros - but in reality
            // they won't be zeros
            for (int i = 0; i < 16; i++)
            {
                A0[i] = c_array[i]; A1[i] = c_array[i + 16];
                B0[i] = 0; B1[i] = 0;
            }
        }
        /// <summary>
        /// 32 point INVERSE FFT on values in memB, with result in memB.        
        /// fft_shift: 0=no shift, 1=left shift, 3=right shift.
        /// There is NO automatic 1/32 scaling of the result.
        /// </summary>
        public void iFFT32_B2B(int fft_shift)
        {
            Complex[] c_array = new Complex[32];
            for (int i = 0; i < 16; i++) c_array[i] = B0[i];
            for (int i = 16; i < 32; i++) c_array[i] = B1[i - 16];

            CVector.Inverse_FFT(c_array);
            multiply_by(c_array, 32); // to undo the automatic 1/32 scaling
            if (fft_shift == 1) multiply_by(c_array, 32);
            else if (fft_shift == 3) divide_by(c_array, 32);

            // in this simulation A0 and A1 are set to zeros - but in reality
            // they won't be zeros
            for (int i = 0; i < 16; i++)
            {
                B0[i] = c_array[i]; B1[i] = c_array[i + 16];
                A0[i] = 0; A1[i] = 0;
            }
        }

        /// <summary>
        /// 512 point FFT on values in memA, with result in memA
        /// fft_shift: 0=no shift; 1=left shift; 3=right shift;
        /// </summary>
        public void FFT512_A2A(int fft_shift)
        {
            Complex[] c_array = new Complex[512];
            for (int i = 0; i < 256; i++) c_array[i] = A0[i];
            for (int i = 256; i < 512; i++) c_array[i] = A1[i - 256];

            CVector.FFT(c_array);
            if (fft_shift == 1) multiply_by(c_array, 512);
            else if (fft_shift == 3) divide_by(c_array, 512);

            // in this simulation B0 and B1 are set to zeros - but in reality
            // they won't be zeros
            for (int i = 0; i < 256; i++)
            {
                A0[i] = c_array[i]; A1[i] = c_array[i + 256];
                B0[i] = 0; B1[i] = 0;
            }
        }

        /// <summary>
        /// 512 point FFT on values in memB, with result in memB
        /// fft_shift: 0=no shift; 1=left shift; 3=right shift;
        /// </summary>
        public void FFT512_B2B(int fft_shift)
        {
            Complex[] c_array = new Complex[512];
            for (int i = 0; i < 256; i++) c_array[i] = B0[i];
            for (int i = 256; i < 512; i++) c_array[i] = B1[i - 256];

            CVector.FFT(c_array);
            if (fft_shift == 1) multiply_by(c_array, 512);
            else if (fft_shift == 3) divide_by(c_array, 512);

            // in this simulation A0 and A1 are set to zeros - but in reality
            // they won't be zeros
            for (int i = 0; i < 256; i++)
            {
                B0[i] = c_array[i]; B1[i] = c_array[i + 256];
                A0[i] = 0; A1[i] = 0;
            }
        }

        /// <summary>
        /// 512 point INVERSE FFT on values in memA, with result in memA.        
        /// fft_shift: 0=no shift, 1=left shift, 3=right shift.
        /// There is NO automatic 1/512 scaling of the result.
        /// </summary>
        public void iFFT512_A2A(int fft_shift)
        {
            Complex[] c_array = new Complex[512];
            for (int i = 0; i < 256; i++) c_array[i] = A0[i];
            for (int i = 256; i < 512; i++) c_array[i] = A1[i - 256];

            CVector.Inverse_FFT(c_array);
            multiply_by(c_array, 512); // to undo the automatic 1/512 scaling
            if (fft_shift == 1) multiply_by(c_array, 512);
            else if (fft_shift == 3) divide_by(c_array, 512);

            // in this simulation B0 and B1 are set to zeros - but in reality
            // they won't be zeros
            for (int i = 0; i < 256; i++)
            {
                A0[i] = c_array[i]; A1[i] = c_array[i + 256];
                B0[i] = 0; B1[i] = 0;
            }
        }
        /// <summary>
        /// 512 point INVERSE FFT on values in memB, with result in memB.        
        /// fft_shift: 0=no shift, 1=left shift, 3=right shift.
        /// There is NO automatic 1/512 scaling of the result.
        /// </summary>
        public void iFFT512_B2B(int fft_shift)
        {
            Complex[] c_array = new Complex[512];
            for (int i = 0; i < 256; i++) c_array[i] = B0[i];
            for (int i = 256; i < 512; i++) c_array[i] = B1[i - 256];

            CVector.Inverse_FFT(c_array);
            multiply_by(c_array, 512); // to undo the automatic 1/512 scaling
            if (fft_shift == 1) multiply_by(c_array, 512);
            else if (fft_shift == 3) divide_by(c_array, 512);

            // in this simulation A0 and A1 are set to zeros - but in reality
            // they won't be zeros
            for (int i = 0; i < 256; i++)
            {
                B0[i] = c_array[i]; B1[i] = c_array[i + 256];
                A0[i] = 0; A1[i] = 0;
            }
        }
        #endregion

        #region Math Operations
        /// <summary>
        /// Carries out for example B0[dest_index] = A0[0]*A1[0] + A0[1]*A1[1] + ... 
        /// + A0[source_length-1]*A1[source_length-1]
        /// </summary>
        public void mac(SOURCE src, T_SOURCE t_src, DEST dest, int src_start, 
                int dest_index, int length)
        {
            Complex acc = 0;
            for (int i = src_start; i < src_start + length; i++)
            {
                Complex v1 = get_complex_t_val(t_src, i);
                Complex v2 = get_complex_val(src, i);
                acc += v1 * v2;
            }
            place_data(dest, dest_index, acc.Real, acc.Imaginary);
        }

        /// <summary>
        /// Executes an operation where the conjugate of one array is copied 
        /// to another. If used on A0 as source and A1 as destination, 
        /// then A1[dest_end - k] = Complex.Conjugate(A0[k]).
        /// The "k" runs from "source_start", for "length" number of elements.
        /// </summary>
        public void conjugate_mirror(SOURCE src, DEST dest, int length, int src_start, 
            int dest_start)
        {
            if ((int)dest > 3) throw new Exception("Destination must be 0 to 3");
            if ((int) dest == (int) src) 
                throw new Exception("Destination can't be the same as the source");
            
            for (int i = 0; i < length; i++)
            {
                Complex v = get_complex_val(src, src_start + i);
                v = Complex.Conjugate(v);
                place_data(dest, dest_start - i, v.Real, v.Imaginary);
            }
        }

        /// <summary>
        /// Compute the power by adding the sum of square of the real and imaginary 
        /// parts, for the values stored in buffer A0. This is implemented as A0 times 
        /// its conjugate. Next find the log2 of this power (but it's not quite log2 - 
        /// see ALU section for a table showing the exact mapping). Then take 16 minus 
        /// the log2 result and store it at C0[dest_index].
        /// </summary>
        public void compute_power(int length, int src_start, int dest_index)
        {
            double pwr = 0;
            for (int i = src_start; i < src_start + length; i++)
            {
                pwr += A0[i].Real * A0[i].Real;
                pwr += A0[i].Imaginary * A0[i].Imaginary;
            }
            
            // The following is hard coded in the Quartus 2 Verilog version of "APU_ALU.v"
            // It is NOT implemented in the ModelSim version of "APU_ALU.v"
            // So there's a mismatch of the two versions
            // currently using N2 = 2^9, M = 2^4, total left shift of 14 bits
            pwr *= N2 * N2; 
            pwr /= M;

            // this is not implemented in any Verilog version
            // pwr = pwr + 1; 

            int Pi_int_k = 0;
            if (pwr >= 4)
                Pi_int_k = 1;
            if (pwr >= 8)
                Pi_int_k = 2;
            if (pwr >= 16)
                Pi_int_k = 3;
            if (pwr >= 32)
                Pi_int_k = 4;
            if (pwr >= 64)
                Pi_int_k = 5;
            if (pwr >= 128)
                Pi_int_k = 6;
            if (pwr >= 512)
                Pi_int_k = 8;
            Pi_int_k = 16 - Pi_int_k;
            C0[dest_index] = Pi_int_k;
        }

        /// <summary>
        /// Computes: B0[k] = mu_k * Complex.Conjugate(A0[k]) * A1[k] * (double)(1 &lt;&lt; Pi_int[k]);
        /// The k goes from 0 to "length". 
        /// This B0[] is called the Rb[] in the AEC code.
        /// src should be A0 or A1. The conjugate array source should always be A0, 
        /// because only A0 is conjugated and feeding the T input.
        /// dest is always memory B0 or B1.
        /// </summary>
        public void compute_Rb(SOURCE src, DEST dest, int length, int src_start, 
                int dest_start, int mu_k)
        {
            if (dest != DEST.B0 && dest != DEST.B1) 
                throw new Exception("Destination not B0 or B1");
            if (src != SOURCE.A0 && src != SOURCE.A1)
                throw new Exception("Source not A0 or A1");

            // Rb[k] = mu_k * ap.Fraction * Complex.Conjugate(Xb_Vec[k]) * Eb_Vec[k] 
            //         * (double)(1 << Pi_int[k]);
            for (int i = 0; i < length; i++)
            {
                Complex a1_val = get_complex_val(src, src_start + i);
                Complex Rb = mu_k * fraction * Complex.Conjugate(A0[src_start + i])
                    * a1_val * (double)(1 << C0[src_start + i]);
                place_data(dest, dest_start + i, Rb.Real, Rb.Imaginary);
            }
        }

        /// <summary>
        /// Adds two arrays "src1" and "src2", and puts them in the
        /// "dest" array. The indexes used will be "start_index" through
        /// "start_index + length - 1".
        /// </summary>
        public void add_array(SOURCE src1, SOURCE src2, int src_start, int length, DEST dest)
        {
            for (int i = src_start; i < src_start + length; i++)
            {
                Complex temp1 = get_complex_val(src1, i);
                Complex temp2 = get_complex_val(src2, i);
                temp1 = temp1 + temp2;
                place_data(dest, i, temp1.Real, temp1.Imaginary);
            }
        }     

        #endregion

        
        #region Helper Functions
        /// <summary>
        /// Place a (real, imag) pair into the memory based on "dest" and "index".
        /// </summary>
        private void place_data(DEST dest, int index, double real, double imag)
        {
            int i = index;
            double old_real, old_imag;
            if (dest == DEST.A0) A0[i] = new Complex(real, imag);
            else if (dest == DEST.A1) A1[i] = new Complex(real, imag);
            else if (dest == DEST.B0) B0[i] = new Complex(real, imag);
            else if (dest == DEST.B1) B1[i] = new Complex(real, imag);
            else if (dest == DEST.A0r)
            {
                old_imag = A0[i].Imaginary;
                A0[i] = new Complex(real, old_imag);
            }
            else if (dest == DEST.A1r)
            {
                old_imag = A1[i].Imaginary;
                A1[i] = new Complex(real, old_imag);
            }
            else if (dest == DEST.B0r)
            {
                old_imag = B0[i].Imaginary;
                B0[i] = new Complex(real, old_imag);
            }
            else if (dest == DEST.B1r)
            {
                old_imag = B1[i].Imaginary;
                B1[i] = new Complex(real, old_imag);
            }
            else if (dest == DEST.A0i)
            {
                old_real = A0[i].Real;
                A0[i] = new Complex(old_real, imag);
            }
            else if (dest == DEST.A1i)
            {
                old_real = A1[i].Real;
                A1[i] = new Complex(old_real, imag);
            }
            else if (dest == DEST.B0i)
            {
                old_real = B0[i].Real;
                B0[i] = new Complex(old_real, imag);
            }
            else if (dest == DEST.B1i)
            {
                old_real = B1[i].Real;
                B1[i] = new Complex(old_real, imag);
            }
            else if (dest == DEST.A0_1)
            {
                A0[i] = new Complex(real, imag);
                A1[i] = A0[i];
            }
            else if (dest == DEST.B0_1)
            {
                B0[i] = new Complex(real, imag);
                B1[i] = B0[i];
            }
            else if (dest == DEST.ALL_MEM)
            {
                A0[i] = new Complex(real, imag);
                A1[i] = A0[i]; B0[i] = A0[i]; B1[i] = A0[i];
            }
            // else if(dest == DEST.NONE_MEM) - do nothing
        }

        /// <summary>
        /// Gets a complex number based on the SOURCE and index provided
        /// </summary>
        private Complex get_complex_val(SOURCE src, int index)
        {
            Complex val = new Complex(0, 0);
            if (src == SOURCE.A0) val = A0[index];
            else if (src == SOURCE.A1) val = A1[index];
            else if (src == SOURCE.B0) val = B0[index];
            else if (src == SOURCE.B1) val = B1[index];
            return val;
        }

        /// <summary>
        /// Gets a complex number based on the T_SOURCE and index provided
        /// </summary>
        private Complex get_complex_t_val(T_SOURCE t_src, int index)
        {
            Complex val = new Complex(1, 0);
            if (t_src == T_SOURCE.A0) val = A0[index];
            else if (t_src == T_SOURCE.A0_Conjugate) val = Complex.Conjugate(A0[index]);
            return val;
        }

        /// <summary>
        /// This function divides every element of the c_array by the divisor.
        /// </summary>
        private void divide_by(Complex[] c_array, double divisor)
        {
            for (int i = 0; i < c_array.Length; i++)
                c_array[i] = c_array[i] / divisor;
        }

        /// <summary>
        /// This function multiply every element of the c_array by the multiplicand.
        /// </summary>
        private void multiply_by(Complex[] c_array, double multiplicand)
        {
            for (int i = 0; i < c_array.Length; i++)
                c_array[i] = c_array[i] * multiplicand;
        }

        /// <summary>
        /// Saturate the double value to bewteen +1 and -1, and convert it
        /// to an integer.
        /// </summary>
        private int double_to_int(double val)
        {
            if (val > 1d - fraction) val = 1d - fraction;
            else if (val < -1d + fraction) val = -1d + fraction;
            return (int)(val / fraction);
        }
        #endregion


        #region Diagnostic Use Only
        /// Comment out these functions if not doing diagnostic
        /// <summary>
        /// Reads elements from memory A0 and A1 and return a Complex[].
        /// "A0_length" number of elements are read from 
        /// </summary>
        public Complex[] read_MemA(int A0_length, int A1_length)
        {
            Complex[] c_array = new Complex[A0_length + A1_length];
            for (int i = 0; i < A0_length; i++)
                c_array[i] = A0[i];
            for (int i = 0; i < A1_length; i++)
                c_array[A0_length + i] = A1[i];
            return c_array;
        }

        /// <summary>
        /// Similar to read_MemA, except that it applies to memory B0 and B1 instead.
        /// </summary>
        public Complex[] read_MemB(int B0_length, int B1_length)
        {
            Complex[] c_array = new Complex[B0_length + B1_length];
            for (int i = 0; i < B0_length; i++)
                c_array[i] = B0[i];
            for (int i = 0; i < B1_length; i++)
                c_array[B0_length + i] = B1[i];
            return c_array;
        }

        /// <summary>
        /// Populate A0 and A1 with "c_array". The first "A0_length" elements
        /// of "c_array" goes into A0. The next "A1_length" elements of
        /// "c_array" goes into A1.
        /// </summary>
        public void write_MemA(Complex[] c_array, int A0_length, int A1_length)
        {
            for (int i = 0; i < A0_length; i++)
                A0[i] = c_array[i];
            for (int i = 0; i < A1_length; i++)
                A1[i] = c_array[A0_length + i];
        }

        public bool compare(Complex[] c_array1, Complex[] c_array2)
        {
            if (c_array1.Length != c_array2.Length) return false;
            for (int i = 0; i < c_array1.Length; i++)
            {
                if (Math.Abs(c_array1[i].Real - c_array2[i].Real) > 10 * fraction) return false;
                if (Math.Abs(c_array1[i].Imaginary - c_array2[i].Imaginary) > 10 * fraction) 
                    return false;
            }
            return true;
        }
        #endregion

    }
}
