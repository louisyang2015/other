﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.IO;

namespace AEC_Algo
{
    /// <summary>
    /// This class provides asic support for Wav files. Encoding is PCM. 
    /// Frequency is arbitrary. Bit width should be 8, 16, 24, or 32.
    /// The number of channels is one (mono-only).
    /// </summary>
    class MyWavFile
    {
        public int[] data;
        public int frequency;
        public int bit_width;
        public string err_message;

        #region Constructors

        /// <summary>
        /// This constructor will fill the fields from the 
        /// file provided. IF there's a problem parsing the file, the
        /// "data" array will be null and the problem will be in the
        /// "err_message" string.
        /// </summary>
        
        /// <code>
        /// MyWavFile test = new MyWavFile("my_recording.wav");
        /// int[] data = test.data;
        /// // Manipulate data
        /// test.write_to_file("my_recording2.wav");
        /// </code>
        public MyWavFile(string file_name)
        {
            FileStream fs = new FileStream(file_name, FileMode.Open);
            int file_length = (int)fs.Length;
            BinaryReader br = new BinaryReader(fs);
            byte[] file_data = br.ReadBytes((int)fs.Length);
            br.Close();

            data = null;
            err_message = null;

            //check first 4 bytes for "RIFF"
            if (match_string(file_data, "RIFF", 0) == false)
                err_message = "First 4 bytes do not spell \"RIFF\"";
            //check second 4 bytes for file length
            if (match_int(file_data, (int)(file_length - 8), 4) == false)
                err_message = "Second 4 bytes is not length of file minus 8";
            //check third 4 bytes for "WAVE"
            if (match_string(file_data, "WAVE", 8) == false)
                err_message = "Bytes 8 through 11 do not spell \"WAVE\"";

            //look for the format and data chuncks
            int fmt_start = -1;
            int data_start = -1;
            int current_index = 12;
            while (current_index < file_data.Length - 1)
            {
                //look at the current chunk to see if it's data or format chunk
                if (match_string(file_data, "fmt ", current_index))
                    fmt_start = current_index;
                if (match_string(file_data, "data", current_index))
                    data_start = current_index;

                //advance to the next chunk
                if (current_index + 7 > file_data.Length - 1) break;
                int chunk_length = BitConverter.ToInt32(file_data, current_index + 4);
                current_index = current_index + 8 + chunk_length;
            }

            //quit if format or data chunks cannot be found
            if (fmt_start == -1)
                err_message = "Format sub-chunk cannot be found.";
            if (data_start == -1)
                err_message = "Data sub-chunk cannot be found.";

            //extract from the format chunk: frequency, bit_width
            int audio_format = BitConverter.ToInt16(file_data, fmt_start + 8);
            int num_channels = BitConverter.ToInt16(file_data, fmt_start + 10);
            frequency = BitConverter.ToInt32(file_data, fmt_start + 12);
            bit_width = BitConverter.ToInt16(file_data, fmt_start + 22);

            //error checks on format chunk:
            if (audio_format != 1)
                err_message = "Wave file is not PCM";
            if (bit_width != 8 && bit_width != 16 && bit_width != 24
                && bit_width != 32)
                err_message = "Bit width is not 8, 16, 24, nor 32.";
            if (num_channels != 1 && num_channels != 2)
                err_message = "Number of channels is not 1 nor 2";

            //extract from the data chunk: data
            if (data_start + 7 > file_data.Length - 1)
                err_message = "Wave file data chunk has no length value.";
            int data_num_bytes = BitConverter.ToInt32(file_data, data_start + 4);
            int data_length = data_num_bytes / (bit_width / 8);
            //further divide data_length by 2 if dual channel
            if(num_channels == 2) data_length = data_length / 2;

            if (err_message != null) return;

            data = new int[data_length];
            int bit7_val = 128;
            int bit23_val = (int)Math.Pow(2, 23);
            for (int i = 0; i < data_length; i++)
            {
                int data_size = bit_width / 8;
                current_index = data_start + 8 + i * data_size * num_channels;
                byte[] val = new byte[] {0, 0, 0, 0};
                val[0] = file_data[current_index];
                if (data_size >= 2) val[1] = file_data[current_index + 1];
                if (data_size >= 3) val[2] = file_data[current_index + 2];
                if (data_size == 4) val[3] = file_data[current_index + 3];
                if (data_size == 1)
                {
                    data[i] = val[0];
                    //This needs to be checked out on 8-bit wave files
                    //Are 8 bit wave files stored as unsigned?
                    if (data[i] > bit7_val)
                    {
                        //1100 = 12 unsigned and -4 signed
                        //-8 + (12 - 8) = -4
                        data[i] = bit7_val + (data[i] - bit7_val);
                    }
                }
                else if (data_size == 2)
                {
                    data[i] = BitConverter.ToInt16(val, 0);
                }
                else if (data_size == 3)
                {
                    data[i] = BitConverter.ToInt32(val, 0);
                    //adjust this to make it signed.
                    if (data[i] > (bit23_val - 1))
                    {
                        //1100 = 12 unsigned and -4 signed
                        //-8 + (12 - 8) = -4
                        data[i] = -1 * bit23_val + (data[i] - bit23_val);
                    }
                }
                else if (data_size == 4)
                {
                    data[i] = BitConverter.ToInt32(val, 0);
                }
                
            }
        }

        /// <summary>
        /// This constructor just initializes the data
        /// and frequency fields.
        /// </summary>      
        public MyWavFile(int[] data, int frequency, int bit_width)
        {
            this.data = data;
            this.frequency = frequency;
            this.bit_width = bit_width;
            err_message = "";
        }

        #endregion 

        #region User Functions

        /// <summary>
        /// Create a Wav file with the data and frequency
        /// provided. The data will not be saturated to accomodate 
        /// the bit width.
        /// </summary>
        public bool write_to_file(string file_name)
        {
            if (bit_width != 8 && bit_width != 16
                && bit_width != 24 && bit_width != 32) return false;

            int bytes_per_data = bit_width / 8;
            byte[] file_data = new byte[data.Length * bytes_per_data + 44];
            
            //RIFF chunk
            place_string(file_data, "RIFF", 0);     //chunk ID
            place_int(file_data, file_data.Length - 8, 4);      //chunk size
            place_string(file_data, "WAVE", 8);     //format

            //Format chunk
            place_string(file_data, "fmt ", 12);    //sub-chunk ID
            place_int(file_data, 16, 16);           //sub-chunk size
            place_short(file_data, 1, 20);          //audio format = PCM
            place_short(file_data, 1, 22);      //number of channels = 1 = mono
            place_int(file_data, frequency, 24);    //frequency (sample rate)
            place_int(file_data, frequency * bytes_per_data, 28); //byte rate
            place_int(file_data, 1 * bytes_per_data, 32); //bytes per sample
            place_short(file_data, bit_width, 34);
            
            //the data chunk header:            
            place_string(file_data, "data", 36);
            place_int(file_data, data.Length * bytes_per_data, 40);

            //the data section:
            for (int i = 0; i < data.Length; i++)
            {
                byte[] val = BitConverter.GetBytes(data[i]);
                //lower bytes at lower address:
                file_data[44 + i * bytes_per_data + 0] = val[0];
                if (bytes_per_data > 1) file_data[44 + i * bytes_per_data + 1] = val[1];
                if (bytes_per_data > 2) file_data[44 + i * bytes_per_data + 2] = val[2];
                if (bytes_per_data > 2) file_data[44 + i * bytes_per_data + 3] = val[3];
            }

            FileStream fs = new FileStream(file_name, FileMode.Create);
            BinaryWriter bw = new BinaryWriter(fs);
            bw.Write(file_data);
            bw.Close();

            return true;
        }

        #endregion 

        #region Helper functions

        /// <summary>
        /// This function converts the string "str" into a character array
        /// and place it inside the byte[] "b_array" starting at the 
        /// "offset" index.
        /// </summary>
        private void place_string(byte[] b_array, string str, int offset)
        {
            char[] c_array = str.ToCharArray();
            for (int i = 0; i < c_array.Length; i++)
                b_array[offset + i] = (byte)c_array[i];
        }

        /// <summary>
        /// This function converts the integer "value" into a byte array
        /// and place it inside the byte[] "b_array" starting at the 
        /// "offset" index. The bytes are placed so that the lower bytes
        /// are at the lower address (little endian order).
        /// </summary>
        private void place_int(byte[] b_array, int value, int offset)
        {
            byte[] val = BitConverter.GetBytes(value);
            b_array[offset + 0] = val[0];
            b_array[offset + 1] = val[1];
            b_array[offset + 2] = val[2];
            b_array[offset + 3] = val[3];
        }

        /// <summary>
        /// This function is same as place_int(), except that only lower
        /// two bytes of the integer are placed into the byte[] "b_array".
        /// </summary>
        private void place_short(byte[] b_array, int value, int offset)
        {
            byte[] val = BitConverter.GetBytes(value);
            b_array[offset + 0] = val[0];
            b_array[offset + 1] = val[1];
        }

        /// <summary>
        /// Starting at b_array[offset], see if the characters match those
        /// in a given string "str". Return true if string is found.
        /// </summary>
        private bool match_string(byte[] b_array, string str, int offset)
        {
            int last_index = offset + str.Length - 1;
            if (last_index > b_array.Length - 1) return false;
            for (int i = 0; i < str.Length; i++)
            {
                if (str[i] != (char)b_array[offset + i]) return false;
            }
            return true;
        }

        /// <summary>
        /// Starting at b_array[offset], see if the value can be found.
        /// Return true if it's found.
        /// </summary>
        private bool match_int(byte[] b_array, int value, int offset)
        {
            int last_index = offset + 4 - 1;
            if (last_index > b_array.Length - 1) return false;
            byte[] val = BitConverter.GetBytes(value);
            for (int i = 0; i < 4; i++)
            {
                if (val[i] != b_array[offset + i]) return false;
            }
            return true;
        }

        /// <summary>
        /// This is similar to match_int, except that "value" is treated
        /// as a 16 bit short integer. So the match is done on the lower
        /// two bytes of value only.
        /// </summary>
        private bool match_short(byte[] b_array, int value, int offset)
        {
            int last_index = offset + 2 - 1;
            if (last_index > b_array.Length - 1) return false;
            byte[] val = BitConverter.GetBytes(value);
            for (int i = 0; i < 2; i++)
            {
                if (val[i] != b_array[offset + i]) return false;
            }
            return true;
        }
        /*
        /// <summary>
        /// Reads "length" number of bytes from b_array, starting at the
        /// "offset", and return those bytes as a string.
        /// </summary>
        private string extract_string(byte[] b_array, int offset, int length)
        {
            if (offset + length - 1 > b_array.Length - 1)
                length = b_array.Length - offset;

            char[] c_array = new char[length];
            for (int i = 0; i < length; i++)
                c_array[i] = (char)b_array[offset + i];

            return new string(c_array);
        }

        /// <summary>
        /// Reads 4 bytes from b_array, starting at the
        /// "offset", and return those bytes as an integer.
        /// </summary>
        private int extract_int(byte[] b_array, int offset)
        {
            if (offset + 3 > b_array.Length - 1) 
                throw new Exception("offset is too close to the end of the array");
            byte[] val = new byte[4];
            val[0] = b_array[offset];
            val[1] = b_array[offset + 1];
            val[2] = b_array[offset + 2];
            val[3] = b_array[offset + 3];

            return BitConverter.ToInt32(val, 0);
        }
        */
        #endregion 
    }
}
