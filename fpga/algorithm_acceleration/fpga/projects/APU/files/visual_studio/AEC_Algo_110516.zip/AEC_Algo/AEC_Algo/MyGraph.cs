﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using C1.Win.C1Chart;

namespace AEC_Algo
{
    class MyGraph
    {
        private string title, x_axis_text, y_axis_text; 
        private double[] x_vector;
        private string[] series_names;
        private double[][] y_vectors;

        #region Constructors
        //this is the real constructor method
        private void init(string title, string x_axis_text, string y_axis_text,
                double[] x_vector, double[][] y_vectors, string[] series_names)
        {
            this.title = title;
            this.x_axis_text = x_axis_text;
            this.y_axis_text = y_axis_text;
            this.x_vector = x_vector;
            this.y_vectors = y_vectors;
            this.series_names = series_names;
        }

        //This function produce an "x" vector that counts 0, 1, 2, 3, ...
        private double[] create_x_vector(int size)
        {
            double[] x_val = new double[size];
            for (int i = 0; i < size; i++)
                x_val[i] = i;
            return x_val;            
        }

        //One "y" vector constructor - various titles are blank
        public MyGraph(double[] y_vector)
        {
            y_vectors = new double[1][];
            y_vectors[0] = y_vector;
            init(null, "", "", create_x_vector(y_vector.Length),
                    y_vectors, null);
        }

        //One "y" vector only constructor; "x" is assumed
        public MyGraph(string title, string x_axis_text, string y_axis_text,
                double[] y_vector)
        {
            y_vectors = new double[1][];
            y_vectors[0] = y_vector;
            init(title, x_axis_text, y_axis_text, 
                    create_x_vector(y_vector.Length), y_vectors, null);
        }

        //One "x" and one "y" vector constructor
        public MyGraph(string title, string x_axis_text, string y_axis_text,
                double[] x_vector, double[] y_vector)
        {
            y_vectors = new double[1][];
            y_vectors[0] = y_vector;
            init(title, x_axis_text, y_axis_text, x_vector, y_vectors, null);
        }

        //Many "y" vector constructor; "x" is assumed
        public MyGraph(string title, string x_axis_text, string y_axis_text,
                double[][] y_vectors, string[] series_names)
        {
            init(title, x_axis_text, y_axis_text, 
                    create_x_vector(y_vectors[0].Length), y_vectors, series_names);
        }

        //One "x" and many "y" vector constructor
        public MyGraph(string title, string x_axis_text, string y_axis_text,
                double[] x_vector, double[][] y_vectors, string[] series_names)
        {
            init(title, x_axis_text, y_axis_text, x_vector, y_vectors, series_names);
        }
        #endregion

        #region "get_...()" methods
        public string get_title()
        {
            if (title != null) return title;
            return "";
        }
        public string get_data()
        {
            StringBuilder sb = new StringBuilder();

            //The first line says "X Y" or "X series_name1 series_name2 ..."
            sb.Append("X");
            if (y_vectors.Length == 1)
            {
                sb.Append("\tY\r\n");
            }
            else
            {
                for (int i = 0; i < y_vectors.Length; i++)
                {
                    sb.Append("\t" + series_names[i]);
                }
                sb.Append("\r\n");
            }
            
            //Second line and on contains the actual data
            for (int i = 0; i < x_vector.Length; i++)
            {
                sb.Append(x_vector[i]);
                for (int j = 0; j < y_vectors.Length; j++)
                {
                    //At this point in the loop, 
                    //we are on the j-th y_vector, and on the 
                    //i-th row of that y_vector
                    sb.Append("\t" + y_vectors[j][i].ToString());
                }
                sb.Append("\r\n");
            }
            return sb.ToString();
        }
        #endregion

        public void render(C1Chart a_graph)
        {
            //some basic checks
            if (y_vectors == null) return;
            if (y_vectors.Length < 1) return;

            ChartDataSeriesCollection series_collection = a_graph.ChartGroups[0].ChartData.SeriesList;

            series_collection.RemoveAll();

            //Render the data
            if (y_vectors.Length == 1)
            {
                //One "y" vector only
                series_collection.AddNewSeries();
                series_collection[0].X.CopyDataIn(x_vector);
                series_collection[0].Y.CopyDataIn(y_vectors[0]);
                series_collection[0].Label = "";
                a_graph.Legend.Visible = false;
            }
            else
            {
                //Many "y" vectors
                for (int i = 0; i < y_vectors.Length; i++)
                {
                    series_collection.AddNewSeries();
                    series_collection[i].X.CopyDataIn(x_vector);
                    series_collection[i].Y.CopyDataIn(y_vectors[i]);
                    series_collection[i].Label = series_names[i];
                }
                a_graph.Legend.Visible = true;
            }

            //Title 
            if (title != null)
            {
                a_graph.Header.Text = title;
                a_graph.Header.Visible = true;
            }
            else
            {
                a_graph.Header.Text = "";
                a_graph.Header.Visible = false;
            }

            //"x" and "y" axis
            a_graph.ChartArea.AxisX.Text = x_axis_text;
            a_graph.ChartArea.AxisY.Text = y_axis_text;
        }
    }
}
