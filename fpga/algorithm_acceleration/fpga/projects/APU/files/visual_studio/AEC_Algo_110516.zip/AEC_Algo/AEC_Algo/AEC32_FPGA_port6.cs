﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.Numerics;

namespace AEC_Algo
{
    /// <summary>
    /// This is port 5 of the FPGA AEC port. This one uses the new ArrayProc2
    /// model, which is the software model of the array processor that actually 
    /// got implemented on the FPGA. The older ArrayProc model was not implemented.
    /// The two models are quite alike though. Both models exist side by side in
    /// this FPGA port.
    /// Differences in new array processor software model:
    /// * Due to the nature of the array processor 
    /// operation, the minimum length of the array is 16. So the part of the code
    /// that stores a single value to the SSRAM needs to be storing 16 values to
    /// the SSRAM.
    /// * The SSRAM storage of complex numbers will be an array of real component,
    /// followed by an array of imaginary component. So in the SSRAM, it looks like:
    /// A0r[0], A0r[1], ... A0r[511], A0i[0], A0i[1], ... A0i[511]
    /// </summary>
    class AEC32_FPGA_port6 : I_AEC
    {
        #region Parameters
        // Set simulation parameters
        const int L = 2048 * 2; //16 kHz: 2048, 32 kHz: L=4096
        const int M = 16;
        const int N = (L / M); // 32 kHz: N=256
        const int N2 = N * 2; // 32 kHz: N2=512

        // Set parameters for DTD
        const float lam_s = 0.9995f;
        const float lam_f = 0.99f;
        const float lam_p = 0.92f;

        // Set adaptation parameters
        // const float mu1 = 0.015625f;	    // 2^(-6)
        // const float mu2 = 0.03125f;		// 2^(-5)
        const int mu1 = 33554432; // mu1 / 2^(-31)
        const int mu2 = 67108864; // mu2 / 2^(-31)
        const int nd = 0;

        // Set Threshold
        const float pwr_th = 0.025f;
        #endregion

        #region Variables
        // Time domain data buffer
        int[] xb = new int[N];
        int[] yp = new int[N];
        int[] ep = new int[N];

        // Frequency domain data buffer
        // int[] ssram = new int[(M * (N + 1) + (M + 3 + nd + 1) * (N + 1) + (M + nd + 1) * (N + 1)) * 2];
        //Complex[,] Wei = new Complex[M, N + 1];
        //Complex[,] Xb = new Complex[M + 3 + nd + 1, N + 1];
        //Complex[,] Eb = new Complex[M + nd + 1, N + 1];       

        int p_start;
        float pwr, pe, ps;

        int init_blk_cnt;
        short Const_index;
        int index;

        //--------------------------------------------------------
        // For FPGA port:
        // Xb and Eb zero location
        int Xb_offset, Eb_offset;
        int Xb_index, Eb_index; //real index = Xb_offset + for loop index

        // locations of the 2D arrays in "ssram"
        // Complex[,] Wei = new Complex[M, N + 1];
        // Complex[,] Xb = new Complex[M + 3 + nd + 1, N + 1];
        // Complex[,] Eb = new Complex[M + nd + 1, N + 1];
        const int Wei_base = 0;
        const int Wei_base_i = Wei_base + M * (N + 16);
        const int Wei_base_end = Wei_base + M * (N + 16) * 2 - 1;
        const int Xb_base = Wei_base + M * (N + 16) * 2;
        const int Xb_base_i = Xb_base + (M + 3 + nd + 1) * (N + 16);
        const int Xb_base_end = Xb_base + (M + 3 + nd + 1) * (N + 16) * 2 - 1;
        const int Eb_base = Xb_base + (M + 3 + nd + 1) * (N + 16) * 2;
        const int Eb_base_i = Eb_base + (M + nd + 1) * (N + 16);
        const int Eb_base_end = Eb_base + (M + nd + 1) * (N + 16) * 2 - 1;

        const int XB_NUM_ROWS = M + 3 + nd + 1;
        const int EB_NUM_ROWS = M + nd + 1;
        const int WEI_NUM_COLS = N + 16;
        const int XB_NUM_COLS = N + 16;
        const int EB_NUM_COLS = N + 16;

        const int WEI_BLOCK_SIZE = M * (N + 16);
        const int XB_BLOCK_SIZE = (M + 3 + nd + 1) * (N + 16);
        const int EB_BLOCK_SIZE = (M + nd + 1) * (N + 16);

        ArrayProc2 ap2 = new ArrayProc2();

        const int INT16_MAX = 32767;
        const int INT16_MIN = -32767;
        const long INT32_MAX = 2147483647;
        const long INT32_MIN = -2147483647;

        public int N_Val
        {
            get { return N; }
        }

        public Histogram[] Histo_array
        {
            get { return null; }
        }

        List<double> power_atten; //power of output[n] / x[n] for a particular frame
        MyGraph[] output_graphs;
        public MyGraph[] Graphs
        {
            get { return output_graphs; }
        }
        #endregion

        #region Etri Functions
        /// <summary>
        /// Initialize data buffers
        /// </summary>
        public void aec_init()
        {
            p_start = 0;
            pe = 0;
            ps = 0;
            init_blk_cnt = 0;
            Const_index = -1;

            index = -1; //originally done in main()
            power_atten = new List<double>(512);

            //additional variables for FPGA
            Xb_offset = 0;
            Eb_offset = 0;
            
            ap2.init_param(M, N, N2, nd);

            // clear the SSRAM, from Wei_base to Eb_base_end
            int addr = Wei_base;
            ap2.ssram_set_skip(1);
            ap2.ssram_set_highest_addr(Eb_base_end);
            ap2.ssram_set_block_size(Eb_base_end - Wei_base - 1);
            while (addr <= Eb_base_end)
            {
                // confirm APU instruction FIFO has space
                ap2.ssram_set_addr(addr);
                ap2.ssram_reset(512);
                addr = addr + 512;
            }
        }

        /// <summary>
        /// AEC function that process a single frame of data.
        /// </summary>
        public void aec(int[] dn, int[] xn, int[] output)
        {
            index++; //originally done in main()

            int i, k, m;
            int mu, mu_k;

            // Saturate xn[] and dn[]
            // For FPGA, only INT16_MIN, which is 100...000 needs to be checked
            for (i = 0; i < N; i++)
            {
                if (xn[i] > INT16_MAX) xn[i] = INT16_MAX;
                else if (xn[i] < INT16_MIN) xn[i] = INT16_MIN;
                if (dn[i] > INT16_MAX) dn[i] = INT16_MAX;
                else if (dn[i] < INT16_MIN) dn[i] = INT16_MIN;
            }

            //-------------------------------------------------------------
            // NIOS 2 --> data --> FPGA, Xc will be in memory B0 and B1
            // Xc[0~255] = xb[] <<16
            // Xc[256~512] = xn[] << 16
            ap2.reset_memory(ArrayProc2.DEST.A0, 0, N);
            ap2.reset_memory(ArrayProc2.DEST.A1, 0, N);
            ap2.send_data(ArrayProc2.DEST.A0r, xb, N);
            ap2.send_data(ArrayProc2.DEST.A1r, xn, N);
            ap2.copy_shift16(ArrayProc2.SOURCE.A0, ArrayProc2.DEST.B0, N, 0, 0);
            ap2.copy_shift16(ArrayProc2.SOURCE.A1, ArrayProc2.DEST.B1, N, 0, 0);

            //--------------------------------------------------------------

            //--------------------------------------------------------------
            // Xc FFT and bitshift
            ap2.FFT512_B2B(3);            
            //--------------------------------------------------------------

            //--------------------------------------------------------------
            // Save xn[] as xb[] for use with next frame, no more use of
            // xb[] after this
            for (i = 0; i < N; i++) xb[i] = xn[i];
            //--------------------------------------------------------------

            //---------------------------------------------------------------------
            // The Xc, after computing FFT of Xc, store it in matrix Xb
            // in a circular buffer format. "Xb_offset" is the 0th
            // row of this circular buffer. 
            Xb_offset--;
            if (Xb_offset < 0) Xb_offset = Xb_offset + XB_NUM_ROWS;

            // Store B0 = Xc[0~255] --> Xb[]
            ap2.ssram_set_addr(Xb_base + Xb_offset * XB_NUM_COLS);
            ap2.ssram_set_skip(1);
            ap2.ssram_set_highest_addr(Xb_base_i - 1);
            ap2.ssram_set_block_size(XB_BLOCK_SIZE);
            ap2.ssram_write(ArrayProc2.SOURCE.B0, 0, N, 0); // real
            ap2.ssram_set_addr(Xb_base_i + Xb_offset * XB_NUM_COLS);
            ap2.ssram_set_highest_addr(Xb_base_end);
            ap2.ssram_write(ArrayProc2.SOURCE.B0, 1, N, 0); // imag

            // Store B1 -> Xc[256] --> Xb[]
            ap2.ssram_set_addr(Xb_base + Xb_offset * XB_NUM_COLS + N);
            ap2.ssram_set_highest_addr(Xb_base_i - 1);
            ap2.ssram_write(ArrayProc2.SOURCE.B1, 0, 16, 0); // real
            ap2.ssram_set_addr(Xb_base_i + Xb_offset * XB_NUM_COLS + N);
            ap2.ssram_set_highest_addr(Xb_base_end);
            ap2.ssram_write(ArrayProc2.SOURCE.B1, 1, 16, 0); // imag
            //---------------------------------------------------------------------


            //---------------------------------------------------------------------
            // Compute Ys, which is later used to compute the output
            for (k = 0; k < N + 1; k++)
            {
                // Xb buffer --> A0
                ap2.ssram_set_addr(Xb_base + Xb_offset * XB_NUM_COLS + k);
                ap2.ssram_set_skip(XB_NUM_COLS);
                ap2.ssram_set_highest_addr(Xb_base_i - 1);
                ap2.ssram_set_block_size(XB_BLOCK_SIZE - XB_NUM_COLS);
                ap2.ssram_read(ArrayProc2.DEST.A0r, M, 0); // real
                ap2.ssram_set_addr(Xb_base_i + Xb_offset * XB_NUM_COLS + k);
                ap2.ssram_set_highest_addr(Xb_base_end);
                ap2.ssram_read(ArrayProc2.DEST.A0i, M, 0); // imag

                // Wei buffer --> A1
                ap2.ssram_set_addr(Wei_base + k);
                ap2.ssram_set_skip(WEI_NUM_COLS);
                ap2.ssram_set_highest_addr(Wei_base_i - 1);
                ap2.ssram_set_block_size(WEI_BLOCK_SIZE - WEI_NUM_COLS);
                ap2.ssram_read(ArrayProc2.DEST.A1r, M, 0); // real
                ap2.ssram_set_addr(Wei_base_i + k);
                ap2.ssram_set_highest_addr(Wei_base_end);
                ap2.ssram_read(ArrayProc2.DEST.A1i, M, 0); // real

                ap2.mac(ArrayProc2.SOURCE.A1, ArrayProc2.T_SOURCE.A0, ArrayProc2.DEST.B0, 0, k, M);
            }
            // The Ys[] is now in memory B0

            //---------------------------------------------------------------------
            // Prepare Ys for inverse FFT:
            
            // B0[N] (1 element only) copied to B1[0]            
            // B1[256-k] = Complex.Conjugate(B0[k]), k = 1 to N-1
            ap2.copy_data(ArrayProc2.SOURCE.B0, ArrayProc2.DEST.B1, 16, N, 0);
            ap2.conjugate_mirror(ArrayProc2.SOURCE.B0, ArrayProc2.DEST.B1, N - 1, 1, N - 1);

            //---------------------------------------------------------------------
            // YS --> inverse FFT and bit shift
            ap2.iFFT512_B2B(0);
            // At this point, Ys is in B0[0~255] and B1[0~255]

            //---------------------------------------------------------------------            
            // NIOS 2 will compute the "pwr" variable. It is the sum of |xn[i]|
            int pwr_int = 0;
            for (i = 0; i < N; i++)
            {
                if (xn[i] > 0) pwr_int += xn[i];
                else pwr_int -= xn[i];
            }
            pwr = (float)pwr_int / (INT16_MAX * N);

            //---------------------------------------------------------------------
            // NIOS 2 needs to read yp[i], which is Ys[256~511].Real
            yp = ap2.get_data(ArrayProc2.SOURCE.B1, 1, 0, N);

            //---------------------------------------------------------------------
            // NIOS 2 will the error vector ep[i] and send it to the output            
            long ep_long;
            for (i = 0; i < N; i++)
            {
                dn[i] = dn[i] << 16; //dn is now same as "dp" from this point onward

                //ep[i] = dp[i] - yp[i] :
                ep_long = dn[i] - yp[i];
                if (ep_long > INT32_MAX) ep[i] = (int)INT32_MAX;
                else if (ep_long < INT32_MIN) ep[i] = (int)INT32_MIN;
                else ep[i] = (int)ep_long;
            }

            //---------------------------------------------------------------------
            // NIOS 2 --> ep[] --> FPGA
            // Ec[0 ~ 255] = 0 --> B0
            // Ec[256 ~ 512] = ep[0 ~ 255] --> B1
            // Create Ec and do FFT
            ap2.reset_memory(ArrayProc2.DEST.B0, 0, N);
            ap2.reset_memory(ArrayProc2.DEST.B1, 0, N);
            ap2.send_data(ArrayProc2.DEST.B1r, ep, N);

            //---------------------------------------------------------------------
            // Do FFT on Ec, and bitshift
            ap2.FFT512_B2B(3);

            //---------------------------------------------------------------------
            // Store Ec[] in matrix Eb. It is a circular buffer where 
            //  "Eb_offset" is the index of the 0th row.
            Eb_offset--;
            if (Eb_offset < 0) Eb_offset += EB_NUM_ROWS;

            // Store B0 -> Eb[0~255]
            ap2.ssram_set_addr(Eb_base + Eb_offset * EB_NUM_COLS);
            ap2.ssram_set_skip(1);
            ap2.ssram_set_highest_addr(Eb_base_i - 1);
            ap2.ssram_set_block_size(EB_BLOCK_SIZE - 1);
            ap2.ssram_write(ArrayProc2.SOURCE.B0, 0, N, 0); // real
            ap2.ssram_set_addr(Eb_base_i + Eb_offset * EB_NUM_COLS);
            ap2.ssram_set_highest_addr(Eb_base_end);
            ap2.ssram_write(ArrayProc2.SOURCE.B0, 1, N, 0); // imag

            // Store B1[0] -> Eb[]
            ap2.ssram_set_addr(Eb_base + Eb_offset * EB_NUM_COLS + N);
            ap2.ssram_set_highest_addr(Eb_base_i - 1);
            ap2.ssram_write(ArrayProc2.SOURCE.B1, 0, 16, 0); // real
            ap2.ssram_set_addr(Eb_base_i + Eb_offset * EB_NUM_COLS + N);
            ap2.ssram_set_highest_addr(Eb_base_end);
            ap2.ssram_write(ArrayProc2.SOURCE.B1, 1, 16, 0); // imag

            //---------------------------------------------------------------------
            // Compute power of freq bins
            for (k = 0; k < N + 1; k++)
            {
                // Xb[] -> A0
                ap2.ssram_set_addr(Xb_base + Xb_offset * XB_NUM_COLS + k);
                ap2.ssram_set_skip(XB_NUM_COLS);
                ap2.ssram_set_highest_addr(Xb_base_i - 1);
                ap2.ssram_set_block_size(XB_BLOCK_SIZE - XB_NUM_COLS);
                ap2.ssram_read(ArrayProc2.DEST.A0r, M + nd + 4, 0); // real
                ap2.ssram_set_addr(Xb_base_i + Xb_offset * XB_NUM_COLS + k);
                ap2.ssram_set_highest_addr(Xb_base_end);
                ap2.ssram_read(ArrayProc2.DEST.A0i, M + nd + 4, 0); // imag

                ap2.compute_power(M + nd + 4, 0, k);
                // power is a single number stored at C0[k]
            }
            //Pi_int[k] is in C0 at this point

            //---------------------------------------------------------------------
            // Do the following in NIOS 2 - compute output, and compute power
            // use floating point for the power computations
            // Compute ps_c_array[i] = | dp[i]^2 - yp[i]^2 |
            // Compute pe_c_array[i] = ep[i] * ep[i];
            // Start of long NIOS 2 block

            // Output calculation, with saturation
            for (i = 0; i < N; i++)
            {
                // output[i] = ep[i] >> 16; plus rounding bit
                output[i] = ep[i] >> 15;
                output[i]++;
                output[i] = output[i] >> 1;
                if (output[i] > INT16_MAX) output[i] = INT16_MAX;
            }

            float[] ps_c_array = new float[N];
            float[] pe_c_array = new float[N];
            float dp_float, yp_float;
            for (i = 0; i < N; i++)
            {
                dp_float = dn[i] * ap2.Fraction_F;
                yp_float = yp[i] * ap2.Fraction_F;
                ps_c_array[i] = dp_float * dp_float - yp_float * yp_float;
                if (ps_c_array[i] < 0) ps_c_array[i] *= (-1);

                dp_float = ep[i] * ap2.Fraction_F;
                pe_c_array[i] = dp_float * dp_float; //really ep_float ^ 2
            }

            // Step-size control
            if (p_start == 0)
            {
                p_start = 1;
            }
            else
            {
                pwr = lam_p * pwr + (1f - lam_p) * pwr;
            }
            for (i = 0; i < N; i++)
            {
                if (ps_c_array[i] > ps)
                    ps = lam_f * ps + (1f - lam_f) * ps_c_array[i];
                else
                    ps = lam_s * ps + (1f - lam_s) * ps_c_array[i];

                if (pe_c_array[i] > pe)
                    pe = lam_f * pe + (1f - lam_f) * pe_c_array[i];
                else
                    pe = lam_s * pe + (1f - lam_s) * pe_c_array[i];
            }

            if (index < 200)
                mu = mu1;
            else
                mu = mu2;

            // Adaptation control
            if (pwr < pwr_th)
            {
                mu_k = 0;
            }
            else
            {
                // Run initial tens frame without condition
                if (init_blk_cnt < 100)
                {
                    init_blk_cnt++;
                    mu_k = mu;
                }
                else
                {
                    if (pe < 0.35f * ps)
                    {
                        mu_k = mu;
                    }
                    else if (pe < 0.4f * ps)
                    {
                        mu_k = mu / 2;
                    }
                    else if (pe < 0.5f * ps)
                    {
                        mu_k = mu / 4;
                    }
                    else if (pe < 0.65f * ps)
                    {
                        mu_k = mu / 8;
                    }
                    else
                    {
                        mu_k = 0;
                    }
                }
            }

            // Weight update -NLMS
            if (Const_index < 3)
                Const_index++;
            else
                Const_index = 0;
            // End of long NIOS 2 block
            //---------------------------------------------------------------------            


            for (m = 0; m < M; m++)
            {
                Xb_index = Xb_offset + m;
                if (Xb_index > XB_NUM_ROWS - 1) Xb_index = Xb_index - XB_NUM_ROWS;
                Eb_index = Eb_offset + nd;
                if (Eb_index > EB_NUM_ROWS - 1) Eb_index = Eb_index - EB_NUM_ROWS;

                //---------------------------------------------------------------------
                // Compute Rb[] from Xb[][], Eb[][], and Pi_int[]
                // The Pi_int[] is already in memory C0

                //Xb_Vec --> A0
                ap2.ssram_set_addr(Xb_base + (Xb_index + nd) * XB_NUM_COLS);
                ap2.ssram_set_skip(1);
                ap2.ssram_set_highest_addr(Xb_base_i - 1);
                ap2.ssram_set_block_size(XB_BLOCK_SIZE - 1);
                ap2.ssram_read(ArrayProc2.DEST.A0r, N + 1, 0); // real
                ap2.ssram_set_addr(Xb_base_i + (Xb_index + nd) * XB_NUM_COLS);
                ap2.ssram_set_highest_addr(Xb_base_end);
                ap2.ssram_read(ArrayProc2.DEST.A0i, N + 1, 0); // imag

                //Eb_Vec --> A1
                ap2.ssram_set_addr(Eb_base + Eb_index * EB_NUM_COLS);
                ap2.ssram_set_skip(1);
                ap2.ssram_set_highest_addr(Eb_base_i - 1);
                ap2.ssram_set_block_size(EB_BLOCK_SIZE - 1);
                ap2.ssram_read(ArrayProc2.DEST.A1r, N + 1, 0); // real
                ap2.ssram_set_addr(Eb_base_i + Eb_index * EB_NUM_COLS);
                ap2.ssram_set_highest_addr(Eb_base_end);
                ap2.ssram_read(ArrayProc2.DEST.A1i, N + 1, 0); // imag
                //-----------------------------------------------------------------------                
                // Rb[] --> B0
                // B0[k] = mu_k * Complex.Conjugate(A0[k]) * A1[k] * (double)(1 &lt;&lt; Pi_int[k]);
                ap2.compute_Rb(ArrayProc2.SOURCE.A1, ArrayProc2.DEST.B0, N + 1, 0, 0, mu_k);

                // Weight Vector Constraint Part
                if ((m == Const_index) || (m == (Const_index + 4)) || (m == (Const_index + 8)) || (m == (Const_index + 12)))
                {
                    //---------------------------------------------------------------------
                    // Create dW[] from Wei and Rb[]
                    // Wei[] --> B1
                    ap2.ssram_set_addr(Wei_base + m * WEI_NUM_COLS);
                    ap2.ssram_set_skip(1);
                    ap2.ssram_set_highest_addr(Wei_base_i - 1);
                    ap2.ssram_set_block_size(WEI_BLOCK_SIZE - 1);
                    ap2.ssram_read(ArrayProc2.DEST.B1r, N + 1, 0); // real
                    ap2.ssram_set_addr(Wei_base_i + m * WEI_NUM_COLS);
                    ap2.ssram_set_highest_addr(Wei_base_end);
                    ap2.ssram_read(ArrayProc2.DEST.B1i, N + 1, 0); // imag

                    // dW[k] = Wei[k] + Rb[k], for k = 0 to N; dW --> A0
                    ap2.add_array(ArrayProc2.SOURCE.B0, ArrayProc2.SOURCE.B1, 0, N + 1, ArrayProc2.DEST.A0);

                    // Prepare for inverse FFT. Copy A0[N] to A1[0], one element copy
                    // A1[256-k] = Complex.Conjugate(A[k]), k = 1 to N-1
                    ap2.copy_data(ArrayProc2.SOURCE.A0, ArrayProc2.DEST.A1, 16, N, 0);
                    ap2.conjugate_mirror(ArrayProc2.SOURCE.A0, ArrayProc2.DEST.A1, N - 1, 1, N - 1);

                    //---------------------------------------------------------------------
                    // Inverse FFT and bitshift on dW, which is mem A right now
                    ap2.iFFT512_A2A(0);

                    // To prepare for the next FFT, A0[0~255] copy to B0[0~255], copy real part only
                    // set the imaginary part to zero.
                    // Then set B1[0~255] to zero completely.

                    // for similarity with old code, copy from A0 to B0 for now - may not be
                    // necessary
                    ap2.reset_memory(ArrayProc2.DEST.B0, 0, N);
                    ap2.copy_data(ArrayProc2.SOURCE.A0, ArrayProc2.DEST.B0r, N, 0, 0);
                    ap2.reset_memory(ArrayProc2.DEST.B1, 0, N);

                    // dW now in B
                    // Do FFT on dW and bitshift
                    ap2.FFT512_B2B(3);

                    //---------------------------------------------------------------------
                    // Store dW to Wei matrix
                    // store B0[0:255] --> Wei[]
                    ap2.ssram_set_addr(Wei_base + m * WEI_NUM_COLS);
                    ap2.ssram_set_skip(1);
                    ap2.ssram_set_highest_addr(Wei_base_i - 1);
                    ap2.ssram_set_block_size(WEI_BLOCK_SIZE);
                    ap2.ssram_write(ArrayProc2.SOURCE.B0, 0, N, 0); // real
                    ap2.ssram_set_addr(Wei_base_i + m * WEI_NUM_COLS);
                    ap2.ssram_set_highest_addr(Wei_base_end);
                    ap2.ssram_write(ArrayProc2.SOURCE.B0, 1, N, 0); // imag

                    // store B1[0] --> Wei
                    ap2.ssram_set_addr(Wei_base + m * WEI_NUM_COLS + N);
                    ap2.ssram_set_skip(1);
                    ap2.ssram_set_highest_addr(Wei_base_i - 1);
                    ap2.ssram_set_block_size(WEI_BLOCK_SIZE);
                    ap2.ssram_write(ArrayProc2.SOURCE.B1, 0, 16, 0); // real
                    ap2.ssram_set_addr(Wei_base_i + m * WEI_NUM_COLS + N);
                    ap2.ssram_set_highest_addr(Wei_base_end);
                    ap2.ssram_write(ArrayProc2.SOURCE.B1, 1, 16, 0); // imag
                }
                else
                {
                    //---------------------------------------------------------------------
                    // Unconstraint Part
                    // Add Rb to Wei, Rb is in B0, read Wei from matrix --> A1
                    ap2.ssram_set_addr(Wei_base + m * WEI_NUM_COLS);
                    ap2.ssram_set_skip(1);
                    ap2.ssram_set_highest_addr(Wei_base_i - 1);
                    ap2.ssram_set_block_size(WEI_BLOCK_SIZE);
                    ap2.ssram_read(ArrayProc2.DEST.A1r, N + 1, 0); // real
                    ap2.ssram_set_addr(Wei_base_i + m * WEI_NUM_COLS);
                    ap2.ssram_set_highest_addr(Wei_base_end);
                    ap2.ssram_read(ArrayProc2.DEST.A1i, N + 1, 0); // imag

                    ap2.add_array(ArrayProc2.SOURCE.B0, ArrayProc2.SOURCE.A1, 0, N + 1, ArrayProc2.DEST.B1);
                    // The updated Wei_Vec is now in B1

                    // Store Wei to the Wei matrix
                    ap2.ssram_set_addr(Wei_base + m * WEI_NUM_COLS);
                    ap2.ssram_set_skip(1);
                    ap2.ssram_set_highest_addr(Wei_base_i - 1);
                    ap2.ssram_set_block_size(WEI_BLOCK_SIZE);
                    ap2.ssram_write(ArrayProc2.SOURCE.B1, 0, N + 1, 0); // real
                    ap2.ssram_set_addr(Wei_base_i + m * WEI_NUM_COLS);
                    ap2.ssram_set_highest_addr(Wei_base_end);
                    ap2.ssram_write(ArrayProc2.SOURCE.B1, 1, N + 1, 0); // imag
                }
            }


            //compute power of the frame for d[n] and output[n]
            double total_power_dn = 1;
            // in this port of the code, dn has been shifted left by 16 previously
            for (i = 0; i < dn.Length; i++) dn[i] = dn[i] >> 16;
            for (i = 0; i < dn.Length; i++)
                total_power_dn += (double)dn[i] * (double)dn[i];
            double total_power_output = 1;
            for (i = 0; i < output.Length; i++)
                total_power_output += (double)output[i] * (double)output[i];
            double atten = -10 * Math.Log10(total_power_output / total_power_dn);
            power_atten.Add(atten);
        }

        /// <summary>
        /// This function is meant to be run after all packets have been 
        /// processed. This function converts the "power_atten" list to
        /// a graph, which the main program can then plot.
        /// </summary>
        public void aec_end()
        {
            double[] atten_val = new double[power_atten.Count];
            for (int i = 0; i < atten_val.Length; i++)
            {
                atten_val[i] = power_atten[i];
            }

            //fill the "output_graph"
            output_graphs = new MyGraph[1];
            output_graphs[0] = new MyGraph("Attenuation of output[n] compared to d[n]",
                    "frame #", "Attenuation (dB)", atten_val);
        }
        #endregion
    }
}

