/*
 * aec.h
 *
 *  Created on: May 16, 2011
 *      Author: louisy
 */

#ifndef AEC_H_
#define AEC_H_

// Set simulation parameters
#define L	2048*2
#define M	16
#define	N	(L/M)
#define N2	(N*2)

// Set parameters for DTD
#define	lam_s  0.9995f
#define lam_f  0.99f
#define lam_p  0.92f

// Set adaptation parameters
// const float mu1 = 0.015625f;	    // 2^(-6)
// const float mu2 = 0.03125f;		// 2^(-5)
#define mu1 33554432 // mu1 / 2^(-31)
#define mu2 67108864 // mu2 / 2^(-31)
#define nd  0

// Set Threshold
#define pwr_th  0.025f


// Frequency domain data buffer
// int[] ssram = new int[(M * (N + 1) + (M + 3 + nd + 1) * (N + 1) + (M + nd + 1) * (N + 1)) * 2];
// Complex[,] Wei = new Complex[M, N + 1];
// Complex[,] Xb = new Complex[M + 3 + nd + 1, N + 1];
// Complex[,] Eb = new Complex[M + nd + 1, N + 1];

// locations of the 2D arrays in "ssram"
// Complex[,] Wei = new Complex[M, N + 1];
// Complex[,] Xb = new Complex[M + 3 + nd + 1, N + 1];
// Complex[,] Eb = new Complex[M + nd + 1, N + 1];
#define Wei_base 	0
#define Wei_base_i 	Wei_base+M*(N+16)
#define Wei_base_end 	Wei_base+M*(N+16)*2-1
#define Xb_base 		Wei_base + M * (N + 16) * 2
#define Xb_base_i 		Xb_base + (M + 3 + nd + 1) * (N + 16)
#define Xb_base_end 	Xb_base + (M + 3 + nd + 1) * (N + 16) * 2 - 1
#define Eb_base 		Xb_base + (M + 3 + nd + 1) * (N + 16) * 2
#define Eb_base_i 		Eb_base + (M + nd + 1) * (N + 16)
#define Eb_base_end 	Eb_base + (M + nd + 1) * (N + 16) * 2 - 1
#define XB_NUM_ROWS 	M + 3 + nd + 1
#define EB_NUM_ROWS 	M + nd + 1
#define WEI_NUM_COLS	N + 16
#define XB_NUM_COLS 	N + 16
#define EB_NUM_COLS 	N + 16
#define WEI_BLOCK_SIZE 	M * (N + 16)
#define XB_BLOCK_SIZE 	(M + 3 + nd + 1) * (N + 16)
#define EB_BLOCK_SIZE 	(M + nd + 1) * (N + 16)

#define INT16_MAX  32767
#define INT16_MIN  -32767
#define INT32_MAX  2147483647
#define INT32_MIN  -2147483647


void aec_init();
void aec(int* dn, int* xn, int* out);

#endif /* AEC_H_ */
