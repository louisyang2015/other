/*
 * flash.c
 *
 *  Created on: Oct 10, 2010
 *      Author: louisy
 */

#include "flash.h"
#include "data_types.h"


int flash_poll_rdy()
{
	return IORD(FLASH_MEM, 0);
}

void flash_chip_erase()
{
	//the sequence is from data sheet, section 10.9 - command definitions
	IOWR(FLASH_MEM, 0x555, 0xAA);
	IOWR(FLASH_MEM, 0x2AA, 0x55);
	IOWR(FLASH_MEM, 0x555, 0x80);
	IOWR(FLASH_MEM, 0x555, 0xAA);
	IOWR(FLASH_MEM, 0x2AA, 0x55);
	IOWR(FLASH_MEM, 0x555, 0x10);

	while(IORD(FLASH_MEM, 0) == 0);
}

void flash_sector_erase(int sector_address)
{
	IOWR(FLASH_MEM, 0x555, 0xAA);
	IOWR(FLASH_MEM, 0x2AA, 0x55);
	IOWR(FLASH_MEM, 0x555, 0x80);
	IOWR(FLASH_MEM, 0x555, 0xAA);
	IOWR(FLASH_MEM, 0x2AA, 0x55);
	IOWR(FLASH_MEM, sector_address, 0x30);

	while(IORD(FLASH_MEM, 0) == 0);
}

void flash_buffer_write(int sector_address, int start_address,
		short* content, int count)
{
	int i;

	if(count < 1 || count > 16) return;

	IOWR(FLASH_MEM, 0x555, 0xAA);
	IOWR(FLASH_MEM, 0x2AA, 0x55);

	IOWR(FLASH_MEM, sector_address, 0x25);
	IOWR(FLASH_MEM, sector_address, count-1);

	for(i=0; i<count; i++)
		IOWR(FLASH_MEM, start_address+i, content[i]);

	while(IORD(FLASH_MEM, 0) == 0);

	//"program buffer to flash" command
	IOWR(FLASH_MEM, sector_address, 0x29);
}

void flash_test()
{
	int command;
	TwoShorts two_shorts;
	do
	{
		rs232_wait_for_input(4);
		command = rs232_read();

		if(command == 1)
		{
			//read flash memory
			int address;		//address to start reading
			int words_to_read;	//words to read
								//the code assume words_to_read will be
								//small and does not check RS232 output FIFO status
			int i, temp;

			rs232_wait_for_input(4*2);
			address = rs232_read();
			words_to_read = rs232_read();

			for(i=0; i<words_to_read; i++)
			{
				temp = IORD(FLASH_AVALON_0_BASE, address+i);
				rs232_write(temp);
			}
		}
		else if(command == 2)
		{
			//chip erase command
			flash_chip_erase();
			rs232_char_mode_reset();
			rs232_write(1);
		}
		else if(command == 3)
		{
			//buffer write command
			int sector_address;
			int address;

			int i;
			short write_buffer[16];

			rs232_wait_for_input(2*4);
			sector_address = rs232_read();
			address = rs232_read();

			rs232_wait_for_input(2*16);
			for(i=0; i<8; i++)
			{
				two_shorts.int_value = rs232_read();
				write_buffer[2*i] = two_shorts.short_array[0];
				write_buffer[2*i + 1] = two_shorts.short_array[1];
			}

			flash_buffer_write(sector_address, address, write_buffer, 16);

			rs232_write(1); //reply to PC
		}
		else if(command == 4)
		{
			//sector erase command
			int sector_address;

			rs232_wait_for_input(4);
			sector_address = rs232_read();

			flash_sector_erase(sector_address);

			rs232_write(1); //reply to PC
		}

	}while(command != 0);
}
