/*
 * flash.h
 *
 *  Created on: Oct 10, 2010
 *      Author: louisy
 */

#ifndef FLASH_H_
#define FLASH_H_

#include "io.h"
#include "system.h"
#include "rs232.h"

#define FLASH_MEM FLASH_AVALON_0_BASE

int flash_poll_rdy();
void flash_chip_erase();
void flash_sector_erase(int sector_address);
void flash_buffer_write(int sector_address, int start_address,
		short* content, int count);
void flash_test();

#endif /* FLASH_H_ */
