/*
 * data_types.h
 *
 *  Created on: May 16, 2011
 *      Author: louisy
 */

#ifndef DATA_TYPES_H_
#define DATA_TYPES_H_

typedef union {
    unsigned short short_array[2];
    int int_value;
} TwoShorts;


#endif /* DATA_TYPES_H_ */
