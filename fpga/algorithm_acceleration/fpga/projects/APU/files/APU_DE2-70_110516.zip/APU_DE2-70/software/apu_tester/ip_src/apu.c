/*
 * apu.c
 *
 *  Created on: Apr 27, 2011
 *      Author: louisy
 */

#include "apu.h"
#include "system.h"

// ---------- Status instructions ---------------------------------------------
int apu_running()
{
	return ALT_CI_APU_CI_INST(1, 0, 0);
}
int apu_i_fifo_size()
{
	return ALT_CI_APU_CI_INST(1, 1, 0);
}
int apu_r_fifo_size()
{
	return ALT_CI_APU_CI_INST(1, 2, 0);
}
int apu_read_r_fifo()
{
	return ALT_CI_APU_CI_INST(1, 3, 0);
}
void apu_wait_till(int n)
{
	while(apu_i_fifo_size() > n);
}

// ---------- APU instructions ------------------------------------------------
void apu_send_data(DEST dest, int array[], int length)
{
	if(length<1 || length>512) return;

	int arg_length;
	arg_length = 512-length;
	int word = 0x02000000;
	word += arg_length;
	word += (dest << 16);
	ALT_CI_APU_CI_INST(0, word, 0);

	int i;
	for(i=0; i<length; i++)
	{
		while(apu_i_fifo_size() > 250);
		ALT_CI_APU_CI_INST(0, array[i], 0);
	}
}
void apu_get_data(SRC src, int real, int start_index, int length)
{
	if(length<1 || length>256) return; // 256 limit due to result FIFO size
	int word = 0x610F0000;
	word += (src << 20);
	int arg_length = 512 - length;
	word += arg_length;
	ALT_CI_APU_CI_INST(0, word, 0);

	if(real) word = 0;
	else word = 0x80000000;
	word += start_index;
	ALT_CI_APU_CI_INST(0, word, 0);
}

void apu_copy_general(ALU_COPY_MODE alu_mode, SRC src, DEST dest, int length, int src_start, int dest_start)
{
	if(length<1 || length>512) return;
	int word= alu_mode<<28;
	word += (src << 20);
	word += (dest << 16);
	int arg_length = 512 - length;
	word += arg_length;
	ALT_CI_APU_CI_INST(0, word, 0);

	word = src_start << 16;
	word += dest_start;
	ALT_CI_APU_CI_INST(0, word, 0);
}

void apu_copy_data(SRC src, DEST dest, int length, int src_start, int dest_start)
{
	apu_copy_general(2, src, dest, length, src_start, dest_start);
}
void apu_copy_real(SRC src, DEST dest, int length, int src_start, int dest_start)
{
	apu_copy_general(3, src, dest, length, src_start, dest_start);
}
void apu_copy_swap(SRC src, DEST dest, int length, int src_start, int dest_start)
{
	apu_copy_general(4, src, dest, length, src_start, dest_start);
}
void apu_copy_conjugate(SRC src, DEST dest, int length, int src_start, int dest_start)
{
	apu_copy_general(5, src, dest, length, src_start, dest_start);
}
void apu_copy_round(SRC src, DEST dest, int length, int src_start, int dest_start)
{
	apu_copy_general(6, src, dest, length, src_start, dest_start);
}
void apu_copy_shift16(SRC src, DEST dest, int length, int src_start, int dest_start)
{
	apu_copy_general(7, src, dest, length, src_start, dest_start);
}

// to reset memory to zero
void apu_reset_memory(DEST dest, int dest_start, int length)
{
	int word = 0 + (dest << 16) + (512-length);
	ALT_CI_APU_CI_INST(0, word, 0);
	word = dest_start;
	ALT_CI_APU_CI_INST(0, word, 0);
}

// ---------- APU Instructions - Math ------------------------------------------
// add two arrays together
void apu_add_array(SRC src1, SRC src2, int src_start, int length, DEST dest)
{
	int word = 0x11000000;
	word = word + (src1 << 22) + (src2 << 20) + (dest << 16) + (512-length);
	ALT_CI_APU_CI_INST(0, word, 0);
	word = (src_start << 16) + src_start;
	ALT_CI_APU_CI_INST(0, word, 0);
}

// perform MAC on two arrays of data and store it into dest[dest_index]
void apu_mac(SRC src, T_SRC t_src, DEST dest, int src_start, int dest_index, int length)
{
	int word=0x24000000;
	word = word + (src << 22) + (t_src << 20) + (dest << 16) + (512 - length);
	ALT_CI_APU_CI_INST(0, word, 0);
	word = (src_start << 16) + dest_index;
	ALT_CI_APU_CI_INST(0, word, 0);
}

// copies the conjugate of one array to another array. If copying from A0 to A1, then
// A1[dest_start - k] = Complex.Conjugate(A0[src_start + k]).
// The "k" runs from 0 to length-1.
void apu_conjugate_mirror(SRC src, DEST dest, int length, int src_start, int dest_start)
{
	int word = 0x51000000;
	word = word + (src << 20) + (dest << 16) + (512 - length);
	ALT_CI_APU_CI_INST(0, word, 0);
	word = (src_start << 16) + dest_start;
	ALT_CI_APU_CI_INST(0, word, 0);
}

// Compute the power by adding the sum of square of the real and imaginary parts,
// for the values stored in buffer A0. This is implemented as A0 times its
// conjugate. Next find the log2 of this power (but it's not quite log2 - see
// ALU section for a table showing the exact mapping). Then take 16 minus the log2 result
// and store it at C0[dest_index].
void apu_compute_power(int length, int src_start, int dest_index)
{
	int word = 0x0E0F0000;
	word = word + (512 - length);
	ALT_CI_APU_CI_INST(0, word, 0);
	word = (src_start << 16) + dest_index;
	ALT_CI_APU_CI_INST(0, word, 0);
}

// Computes: B0[k] = mu_k * Complex.Conjugate(A0[k]) * A1[k] * (double)(1 << Pi_int[k]);
// The k will run from 0 to length-1. src should be A0 or A1. The conjugate array
// source should always be A0, because only A0 is conjugated and feeding the T input.
// dest should be "2" or "3" - the target is always memory B0 or B1.
void apu_compute_Rb(SRC src, DEST dest, int length, int src_start, int dest_start, int mu_k)
{
	// check that source is A0 or A1
	if((src != SRC_A0) && (src != SRC_A1)) return;
	// check that destination is B0 or B1
	if((dest != DEST_B0) && (dest != DEST_B1)) return;

	int word = 0x31000000 + (src << 22) + (dest << 16) + (512 - length);
	ALT_CI_APU_CI_INST(0, word, 0);
	word = (src_start << 16) + dest_start;
	ALT_CI_APU_CI_INST(0, word, 0);
	word = mu_k;
	ALT_CI_APU_CI_INST(0, word, 0);
}


// ---------- APU Instructions - FFT ------------------------------------------
// The bit reverse length is actually the half length of the FFT. For example,
// a length 32 FFT would have 16 numbers in each array.
// The data is copied from "source" to "dest". The starting index is 0. It's like
// copy, with starting index 0, and the destination address having a bit reverse
// applied to it.
// The source should be either '4' for (A1, A0) or '0xE' for (B1, B0).
// The destination should be either '0xC' for A0/1 or '0xD' for B0/1.
void apu_bit_reverse_copy(int source, DEST dest, int length, int bit_reverse_type)
{
	int word = 0xF0000000;
	word = word + (source << 20) + (dest << 16) + (512 - length);
	ALT_CI_APU_CI_INST(0, word, 0);
	ALT_CI_APU_CI_INST(0, bit_reverse_type, 0);
}

// Runs one set of FFT butterfly operations. If the source is memory A, then the
// destination is memory B. If the source is memory B, then the destination is memory A.
// The source should be either '4' for (A1, A0) or '0xE' for (B1, B0).
// The destination should be either '0xC' for A0/1 or '0xD' for B0/1.
void apu_FFT(int source, DEST dest, int length, int fft_shift,
			int read_stage_number, int write_stage_number)
{
	int word = 0x10000000 + (source << 20) + (dest << 16) + (512-length);
	ALT_CI_APU_CI_INST(0, word, 0);
	word = (fft_shift << 28) + (read_stage_number << 4) + (write_stage_number);
	ALT_CI_APU_CI_INST(0, word, 0);
}

// various FFT functions
// fft_shift: 0=no shift; 1=left shift; 3=right shift;
void apu_FFT32_A2A(int fft_shift)
{
	apu_bit_reverse_copy(4, 0xD, 16, 1); // bit reverse: A->B
	apu_FFT(0xE, 0xC, 16, fft_shift, 0, 0); // fft stage 0, B->A
	apu_FFT(4, 0xD, 16, fft_shift, 1, 1); // fft stage 1, A->B
	apu_FFT(0xE, 0xC, 16, fft_shift, 2, 2); // fft stage 2, B->A
	apu_FFT(4, 0xD, 16, fft_shift, 3, 3); // fft stage 3, A->B
	apu_FFT(0xE, 0xC, 16, fft_shift, 4, 0xF); // fft stage 4, B->A
}
void apu_FFT32_B2B(int fft_shift)
{
	apu_bit_reverse_copy(0xE, 0xC, 16, 1); // bit reverse: B->A
	apu_FFT(4, 0xD, 16, fft_shift, 0, 0); // fft stage 0, A->B
	apu_FFT(0xE, 0xC, 16, fft_shift, 1, 1); // fft stage 1, B->A
	apu_FFT(4, 0xD, 16, fft_shift, 2, 2); // fft stage 2, A->B
	apu_FFT(0xE, 0xC, 16, fft_shift, 3, 3); // fft stage 3, B->A
	apu_FFT(4, 0xD, 16, fft_shift, 4, 0xF); // fft stage 4, A->B
}
void apu_iFFT32_A2A(int fft_shift)
{
	apu_copy_swap(SRC_A0, DEST_B0, 16, 0, 0); // copy swap A->B
	apu_copy_swap(SRC_A1, DEST_B1, 16, 0, 0); // copy swap A->B
	apu_FFT32_B2B(fft_shift);
	apu_copy_swap(SRC_B0, DEST_A0, 16, 0, 0); // copy swap B->A
	apu_copy_swap(SRC_B1, DEST_A1, 16, 0, 0); // copy swap B->A
}
void apu_iFFT32_B2B(int fft_shift)
{
	apu_copy_swap(SRC_B0, DEST_A0, 16, 0, 0); // copy swap B->A
	apu_copy_swap(SRC_B1, DEST_A1, 16, 0, 0); // copy swap B->A
	apu_FFT32_A2A(fft_shift);
	apu_copy_swap(SRC_A0, DEST_B0, 16, 0, 0); // copy swap A->B
	apu_copy_swap(SRC_A1, DEST_B1, 16, 0, 0); // copy swap A->B
}

void apu_FFT512_A2A(int fft_shift)
{
	apu_bit_reverse_copy(4, 0xD, 256, 5); // bit reverse: A->B
	apu_FFT(0xE, 0xC, 256, fft_shift, 0, 0); // fft stage 0, B->A
	apu_FFT(4, 0xD, 256, fft_shift, 1, 1); // fft stage 1, A->B
	apu_FFT(0xE, 0xC, 256, fft_shift, 2, 2); // fft stage 2, B->A
	apu_FFT(4, 0xD, 256, fft_shift, 3, 3); // fft stage 3, A->B
	apu_FFT(0xE, 0xC, 256, fft_shift, 4, 4); // fft stage 4, B->A
	apu_FFT(4, 0xD, 256, fft_shift, 5, 5); // fft stage 5, A->B
	apu_FFT(0xE, 0xC, 256, fft_shift, 6, 6); // fft stage 6, B->A
	apu_FFT(4, 0xD, 256, fft_shift, 7, 7); // fft stage 7, A->B
	apu_FFT(0xE, 0xC, 256, fft_shift, 8, 0xF); // fft stage 8, B->A
}
void apu_FFT512_B2B(int fft_shift)
{
	apu_bit_reverse_copy(0xE, 0xC, 256, 5); // bit reverse: B->A
	apu_FFT(0x4, 0xD, 256, fft_shift, 0, 0); // fft stage 0, A->B
	apu_FFT(0xE, 0xC, 256, fft_shift, 1, 1); // fft stage 1, B->A
	apu_FFT(0x4, 0xD, 256, fft_shift, 2, 2); // fft stage 2, A->B
	apu_FFT(0xE, 0xC, 256, fft_shift, 3, 3); // fft stage 3, B->A
	apu_FFT(0x4, 0xD, 256, fft_shift, 4, 4); // fft stage 4, A->B
	apu_FFT(0xE, 0xC, 256, fft_shift, 5, 5); // fft stage 5, B->A
	apu_FFT(0x4, 0xD, 256, fft_shift, 6, 6); // fft stage 6, A->B
	apu_FFT(0xE, 0xC, 256, fft_shift, 7, 7); // fft stage 7, B->A
	apu_FFT(0x4, 0xD, 256, fft_shift, 8, 0xF); // fft stage 8, A->B
}
void apu_iFFT512_A2A(int fft_shift)
{
	apu_copy_swap(SRC_A0, DEST_B0, 256, 0, 0); // copy swap A->B
	apu_copy_swap(SRC_A1, DEST_B1, 256, 0, 0); // copy swap A->B
	apu_FFT512_B2B(fft_shift);
	apu_copy_swap(SRC_B0, DEST_A0, 256, 0, 0); // copy swap B->A
	apu_copy_swap(SRC_B1, DEST_A1, 256, 0, 0); // copy swap B->A
}
void apu_iFFT512_B2B(int fft_shift)
{
	apu_copy_swap(SRC_B0, DEST_A0, 256, 0, 0); // copy swap B->A
	apu_copy_swap(SRC_B1, DEST_A1, 256, 0, 0); // copy swap B->A
	apu_FFT512_A2A(fft_shift);
	apu_copy_swap(SRC_A0, DEST_B0, 256, 0, 0); // copy swap A->B
	apu_copy_swap(SRC_A1, DEST_B1, 256, 0, 0); // copy swap A->B
}

// ---------- APU Instructions - SSRAM ----------------------------------------
void apu_ssram_set_addr(int n)
{
	int word = 0xF10F0FFF;
	ALT_CI_APU_CI_INST(0, word, 0);
	word = n;
	ALT_CI_APU_CI_INST(0, word, 0);
}
void apu_ssram_set_skip(int n)
{
	int word = 0xF10F0FFF;
	ALT_CI_APU_CI_INST(0, word, 0);
	word = 0x100000 + n;
	ALT_CI_APU_CI_INST(0, word, 0);
}
void apu_ssram_set_highest_addr(int n)
{
	int word = 0xF10F0FFF;
	ALT_CI_APU_CI_INST(0, word, 0);
	word = 0x200000 + n;
	ALT_CI_APU_CI_INST(0, word, 0);
}
void apu_ssram_set_block_size(int n)
{
	int word = 0xF10F0FFF;
	ALT_CI_APU_CI_INST(0, word, 0);
	word = 0x300000 + n;
	ALT_CI_APU_CI_INST(0, word, 0);
}
void apu_ssram_reset(int length)
{
	int word = 0x010F0000 + (512 - length);
	ALT_CI_APU_CI_INST(0, word, 0);
}
void apu_ssram_write(SRC source, int imag, int length, int source_start)
{
	int word = 0xE1000000 + (source << 22) + (imag << 20) + (512 - length);
	ALT_CI_APU_CI_INST(0, word, 0);
	word = source_start << 16;
	ALT_CI_APU_CI_INST(0, word, 0);
}
void apu_ssram_read(DEST dest, int length, int dest_start)
{
	int word = 0x03000000 + (dest << 16) + (512 - length);
	ALT_CI_APU_CI_INST(0, word, 0);
	word = dest_start;
	ALT_CI_APU_CI_INST(0, word, 0);
}

