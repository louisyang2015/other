#include "rs232.h"

//Get current FIFO content length
//return words to be sent out
int rs232_tx_fifo_size()
{
	return IORD(RS232_UART, 1);
}

//return bytes that can be read
int rs232_rx_fifo_size()
{
	return IORD(RS232_UART, 2);
}

//Operating Modes
//0 = 4 byte mode; 2 = 2 byte mode; 1 = 1 byte mode
//TX mode should only be changed when output FIFO is empty
//"rs232_set_tx_mode" does not call "rs232_output_flush"
void rs232_set_tx_mode(int mode)
{
	int current_mode;
	current_mode = IORD(RS232_UART, 3);
	current_mode = current_mode & 0xFFFC; //LSB 1100 - to preserve existing bits
	current_mode = current_mode + mode;
	IOWR(RS232_UART, 3, current_mode);
}
void rs232_set_rx_mode(int mode)
{
	int current_mode;
	current_mode = IORD(RS232_UART, 3);
	current_mode = current_mode & 0xFFF3; //LSB 0011 - to preserve existing bits
	mode = mode << 2;
	current_mode = current_mode + mode;
	IOWR(RS232_UART, 3, current_mode);
}

//Blocking / wait functions
//wait for TX FIFO to deplete
void rs232_output_flush()
{
	while(rs232_tx_fifo_size() > 0);
}
//wait for n bytes of input
void rs232_wait_for_input(int n)
{
	while(rs232_rx_fifo_size() < n);
}

//General operations
int rs232_read()
{
	return IORD(RS232_UART, 0);
}
void rs232_write(int value)
{
	IOWR(RS232_UART, 0, value);
}

//Character Mode operations
void rs232_str_print(char* str)
{
	while(*str != 0)
	{
		IOWR(RS232_UART, 0, *str);
		str++;
	}
}

void rs232_print_newline()
{
	rs232_str_print("\r\n"); //newline for windows
}

void rs232_str_print_unsigned_int(unsigned int value)
{
	int digits[10];
	int i;

	//initialization
	for(i=0; i<10; i++) digits[i] = 0;

	//break "value" into the "digits[]" array
	i = 0;
	while(value > 0)
	{
		digits[i] = value % 10;
		i++;
		value = value / 10;
	}

	//print the digits[] array
	//skip the leading zeros
	i=9;
	while((digits[i] == 0) && (i>=1)) i--;

	//the "i" now points to the first digits[i] that is non-zero
	while(i >= 0)
	{
		//temp_c = digits[i] + 48;
		//add 48 to get ASCII code
		IOWR(RS232_UART, 0, digits[i] + 48);
		i--;
	}
}

//Initialization functions
void rs232_read_all()
{
	rs232_set_rx_mode(1); //read in bytes
	while(rs232_rx_fifo_size() > 0)		rs232_read();
}
void rs232_char_mode_reset()
{
	rs232_read_all(); //this will put rs232 receive in char mode
	rs232_output_flush(); //wait for all bytes to go out
	rs232_set_tx_mode(1); //put rs232 send in char mode
}

//Testing use - assume starting in char mode
void rs232_test()
{
	int command, i;
	int a_rs232_input;

	do
	{
		//get a command
		rs232_wait_for_input(1);
		command = rs232_read();

		if(command == 1) rs232_write(1);

		else if(command ==2) //read 100 bytes in char mode and write it back
		{
			for(i=0; i<100; i++)
			{
				rs232_wait_for_input(1);
				a_rs232_input = rs232_read();
				rs232_write(a_rs232_input);
			}
		}

		else if(command == 3) //read 100 bytes in 2 byte mode and write it back
		{
			rs232_output_flush();
			rs232_set_tx_mode(2);
			rs232_set_rx_mode(2);

			for(i=0; i<50; i++)
			{
				rs232_wait_for_input(2);
				a_rs232_input = rs232_read();
				rs232_write(a_rs232_input);
			}

			//need to go back to char mode to process commands
			rs232_output_flush();
			rs232_set_tx_mode(1);
			rs232_set_rx_mode(1);
		}

		else if(command == 4) //read 100 bytes in 4 byte mode and write it back
		{
			rs232_output_flush();
			rs232_set_tx_mode(0);
			rs232_set_rx_mode(0);

			for(i=0; i<25; i++)
			{
				rs232_wait_for_input(4);
				a_rs232_input = rs232_read();
				rs232_write(a_rs232_input);
			}

			//need to go back to char mode to process commands
			rs232_output_flush();
			rs232_set_tx_mode(1);
			rs232_set_rx_mode(1);
		}

		//Note: not done yet:
		//transmitter overflow test
        //receiver overflow test

	}while(command != 0);
}
