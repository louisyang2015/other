/*
 * apu_test.c
 *
 *  Created on: Apr 28, 2011
 *      Author: louisy
 */

#include "apu.h"
#include "rs232.h"

// ---------- Management Functions --------------------------------------------
void empty_result_fifo()
{
	while(apu_r_fifo_size() > 0) apu_read_r_fifo();
}

// ---------- Test functions --------------------------------------------------
// PC sends data to the array processor
void test_send_data()
{
	// gather data from the PC
	int dest, length;
	int array[512];
	rs232_wait_for_input(2*4);
	dest = rs232_read();
	length = rs232_read();
	int i;
	for(i=0; i<length; i++)
	{
		rs232_wait_for_input(4);
		array[i] = rs232_read();
	}

	// send data to APU
	apu_send_data(dest, array, length);
}

// retrieve data from array processor and sends it back to the PC
void test_get_data()
{
	// gather parameters from the PC
	int source, real, start_index, length;
	rs232_wait_for_input(16);
	source = rs232_read();
	real = rs232_read();
	start_index = rs232_read();
	length = rs232_read();

	// gather data from the APU
	int array[256];
	if(length > 256) return;
	apu_get_data(source, real, start_index, length);
	int i;
	for(i=0; i<length; i++)
	{
		while(apu_r_fifo_size() < 1);
		array[i] = apu_read_r_fifo();
	}

	// send data back to the PC
	for(i=0; i<length; i++)
	{
		while(rs232_tx_fifo_size() > 100);
		rs232_write(array[i]);
	}
}

// copy data from one memory to another
void test_copy_data()
{
	// gather parameters from the PC
	int alu_mode, src, dest, length, src_start, dest_start;
	rs232_wait_for_input(6*4);
	alu_mode = rs232_read();
	src = rs232_read();
	dest = rs232_read();
	length = rs232_read();
	src_start = rs232_read();
	dest_start = rs232_read();
	apu_copy_general(alu_mode, src, dest, length, src_start, dest_start);
}

// reset a section of the memory buffers
void test_reset_memory()
{
	int dest, dest_start, length;
	rs232_wait_for_input(3*4);
	dest = rs232_read();
	dest_start = rs232_read();
	length = rs232_read();
	apu_reset_memory(dest, dest_start, length);
}

// adds two arrays together
void test_add_array()
{
	int src1, src2, src_start, length, dest;
	rs232_wait_for_input(5*4);
	src1 = rs232_read();
	src2 = rs232_read();
	src_start = rs232_read();
	length = rs232_read();
	dest = rs232_read();
	apu_add_array(src1, src2, src_start, length, dest);
}

// test #6
void test_mac()
{
	int src, t_src, dest, src_start, dest_index, length;
	rs232_wait_for_input(6*4);
	src = rs232_read();
	t_src = rs232_read();
	dest = rs232_read();
	src_start = rs232_read();
	dest_index = rs232_read();
	length = rs232_read();

	apu_mac(src, t_src, dest, src_start, dest_index, length);
}


// test #7 - conjugate_mirror() instruction
void test_conjugate_mirror()
{
	int src, dest, length, src_start, dest_start;
	rs232_wait_for_input(5*4);
	src = rs232_read();
	dest = rs232_read();
	length = rs232_read();
	src_start = rs232_read();
	dest_start = rs232_read();

	apu_conjugate_mirror(src, dest, length, src_start, dest_start);
}

// test #8 - compute_power() instruction
void test_compute_power()
{
	int length, src_start, dest_index;
	rs232_wait_for_input(3*4);
	length = rs232_read();
	src_start = rs232_read();
	dest_index = rs232_read();

	apu_compute_power(length, src_start, dest_index);
}

// test#9 - compute_Rb() instruction
void test_compute_Rb()
{
	int src, dest, length, src_start, dest_start, mu_k;
	rs232_wait_for_input(6*4);
	src = rs232_read();
	dest = rs232_read();
	length = rs232_read();
	src_start = rs232_read();
	dest_start = rs232_read();
	mu_k = rs232_read();
	apu_compute_Rb(src, dest, length, src_start, dest_start, mu_k);
}

// test#10 - various fft32 instructions
void test_fft32()
{
	int source, inverse, fft_shift;
	rs232_wait_for_input(3*4);
	source = rs232_read();
	inverse = rs232_read();
	fft_shift = rs232_read();

	if(inverse == 0)
	{
		if(source == 4) apu_FFT32_A2A(fft_shift);
		else apu_FFT32_B2B(fft_shift);
	}
	else
	{
		if(source == 4) apu_iFFT32_A2A(fft_shift);
		else apu_iFFT32_B2B(fft_shift);
	}
}

// test#11 - various fft512 instructions
void test_fft512()
{
	int source, inverse, fft_shift;
	rs232_wait_for_input(3*4);
	source = rs232_read();
	inverse = rs232_read();
	fft_shift = rs232_read();

	if(inverse == 0)
	{
		if(source == 4) apu_FFT512_A2A(fft_shift);
		else apu_FFT512_B2B(fft_shift);
	}
	else
	{
		if(source == 4) apu_iFFT512_A2A(fft_shift);
		else apu_iFFT512_B2B(fft_shift);
	}
}

// test #12 - trigger ssram_set_addr()
void test_ssram_set_addr()
{
	int n;
	rs232_wait_for_input(1*4);
	n = rs232_read();
	apu_ssram_set_addr(n);
}

// test #13 - trigger ssram_set_skip()
void test_ssram_set_skip()
{
	int n;
	rs232_wait_for_input(1*4);
	n = rs232_read();
	apu_ssram_set_skip(n);
}

// test #14 - trigger ssram_set_highest_addr()
void test_ssram_set_highest_addr()
{
	int n;
	rs232_wait_for_input(1*4);
	n = rs232_read();
	apu_ssram_set_highest_addr(n);
}

// test #15 - trigger ssram_set_block_size()
void test_ssram_set_block_size()
{
	int n;
	rs232_wait_for_input(1*4);
	n = rs232_read();
	apu_ssram_set_block_size(n);
}

// test #16 - ssram_reset()
void test_ssram_reset()
{
	int length;
	rs232_wait_for_input(1*4);
	length = rs232_read();
	apu_ssram_reset(length);
}

// test #17 - trigger ssram_write()
void test_ssram_write()
{
	int source, imag, length, source_start;
	rs232_wait_for_input(4*4);
	source = rs232_read();
	imag = rs232_read();
	length = rs232_read();
	source_start = rs232_read();
	apu_ssram_write(source, imag, length, source_start);
}

// test #18 - trigger ssram_read()
void test_ssram_read()
{
	int dest, length, dest_start;
	rs232_wait_for_input(3*4);
	dest = rs232_read();
	length = rs232_read();
	dest_start = rs232_read();
	apu_ssram_read(dest, length, dest_start);
}


