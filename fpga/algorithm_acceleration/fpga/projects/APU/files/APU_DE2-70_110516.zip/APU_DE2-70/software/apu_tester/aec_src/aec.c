/*
 * aec.c
 *
 *  Created on: May 16, 2011
 *      Author: louisy
 */

#include "aec.h"
#include "../ip_src/apu.h"


int p_start;
float pwr, pe, ps;

int init_blk_cnt;
short Const_index;
int index;

// Xb and Eb zero location
int Xb_offset, Eb_offset;
int Xb_index, Eb_index; //real index = Xb_offset + for loop index




void aec_init()
{
	p_start = 0;
	pe = 0;
	ps = 0;
	init_blk_cnt = 0;
	Const_index = -1;

	index = -1; //originally done in main()

	//additional variables for FPGA
	Xb_offset = 0;
	Eb_offset = 0;

	// clear the SSRAM, from Wei_base to Eb_base_end
	int addr = Wei_base;
	apu_wait_till(230);
	apu_wait_till(10);
	apu_ssram_set_skip(1);
	apu_ssram_set_highest_addr(Eb_base_end);
	apu_ssram_set_block_size(Eb_base_end - Wei_base - 1);
	while (addr <= Eb_base_end)
	{
		apu_wait_till(230);
		apu_wait_till(10);
		apu_ssram_set_addr(addr);
		apu_ssram_reset(512);
		addr = addr + 512;
	}
}

void aec(int* dn, int* xn, int* out)
{
    int xb[N], yp[N], ep[N];

    index++; //originally done in main()

	int i, k, m;
	int mu, mu_k;

	// Saturate xn[] and dn[]
	// For FPGA, only INT16_MIN, which is 100...000 needs to be checked
	for (i = 0; i < N; i++)
	{
		if (xn[i] > INT16_MAX) xn[i] = INT16_MAX;
		else if (xn[i] < INT16_MIN) xn[i] = INT16_MIN;
		if (dn[i] > INT16_MAX) dn[i] = INT16_MAX;
		else if (dn[i] < INT16_MIN) dn[i] = INT16_MIN;
	}

	//-------------------------------------------------------------
	// NIOS 2 --> data --> FPGA, Xc will be in memory B0 and B1
	// Xc[0~255] = xb[] <<16
	// Xc[256~512] = xn[] << 16
	apu_wait_till(190);
	apu_wait_till(10);
	apu_reset_memory(DEST_A0, 0, N);
	apu_reset_memory(DEST_A1, 0, N);
	apu_send_data(DEST_A0r, xb, N);
	apu_send_data(DEST_A1r, xn, N);
	apu_copy_shift16(SRC_A0, DEST_B0, N, 0, 0);
	apu_copy_shift16(SRC_A1, DEST_B1, N, 0, 0);

	//--------------------------------------------------------------

	//--------------------------------------------------------------
	// Xc FFT and bitshift
	apu_FFT512_B2B(3);
	//--------------------------------------------------------------

	//--------------------------------------------------------------
	// Save xn[] as xb[] for use with next frame, no more use of
	// xb[] after this
	for (i = 0; i < N; i++) xb[i] = xn[i];
	//--------------------------------------------------------------

	//---------------------------------------------------------------------
	// The Xc, after computing FFT of Xc, store it in matrix Xb
	// in a circular buffer format. "Xb_offset" is the 0th
	// row of this circular buffer.
	Xb_offset--;
	if (Xb_offset < 0) Xb_offset = Xb_offset + XB_NUM_ROWS;

	// Store B0 = Xc[0~255] --> Xb[]
	apu_wait_till(190);
	apu_wait_till(10);
	apu_ssram_set_addr(Xb_base + Xb_offset * XB_NUM_COLS);
	apu_ssram_set_skip(1);
	apu_ssram_set_highest_addr(Xb_base_i - 1);
	apu_ssram_set_block_size(XB_BLOCK_SIZE);
	apu_ssram_write(SRC_B0, 0, N, 0); // real
	apu_ssram_set_addr(Xb_base_i + Xb_offset * XB_NUM_COLS);
	apu_ssram_set_highest_addr(Xb_base_end);
	apu_ssram_write(SRC_B0, 1, N, 0); // imag

	// Store B1 -> Xc[256] --> Xb[]
	apu_ssram_set_addr(Xb_base + Xb_offset * XB_NUM_COLS + N);
	apu_ssram_set_highest_addr(Xb_base_i - 1);
	apu_ssram_write(SRC_B1, 0, 16, 0); // real
	apu_ssram_set_addr(Xb_base_i + Xb_offset * XB_NUM_COLS + N);
	apu_ssram_set_highest_addr(Xb_base_end);
	apu_ssram_write(SRC_B1, 1, 16, 0); // imag
	//---------------------------------------------------------------------


	//---------------------------------------------------------------------
	// Compute Ys, which is later used to compute the output
	for (k = 0; k < N + 1; k++)
	{
		// Xb buffer --> A0
		apu_wait_till(180);
		apu_wait_till(10);
		apu_ssram_set_addr(Xb_base + Xb_offset * XB_NUM_COLS + k);
		apu_ssram_set_skip(XB_NUM_COLS);
		apu_ssram_set_highest_addr(Xb_base_i - 1);
		apu_ssram_set_block_size(XB_BLOCK_SIZE - XB_NUM_COLS);
		apu_ssram_read(DEST_A0r, M, 0); // real
		apu_ssram_set_addr(Xb_base_i + Xb_offset * XB_NUM_COLS + k);
		apu_ssram_set_highest_addr(Xb_base_end);
		apu_ssram_read(DEST_A0i, M, 0); // imag

		// Wei buffer --> A1
		apu_ssram_set_addr(Wei_base + k);
		apu_ssram_set_skip(WEI_NUM_COLS);
		apu_ssram_set_highest_addr(Wei_base_i - 1);
		apu_ssram_set_block_size(WEI_BLOCK_SIZE - WEI_NUM_COLS);
		apu_ssram_read(DEST_A1r, M, 0); // real
		apu_ssram_set_addr(Wei_base_i + k);
		apu_ssram_set_highest_addr(Wei_base_end);
		apu_ssram_read(DEST_A1i, M, 0); // real

		apu_mac(SRC_A1, T_SRC_A0, DEST_B0, 0, k, M);
	}
	// The Ys[] is now in memory B0

	//---------------------------------------------------------------------
	// Prepare Ys for inverse FFT:

	// B0[N] (1 element only) copied to B1[0]
	// B1[256-k] = Complex.Conjugate(B0[k]), k = 1 to N-1
	apu_wait_till(180);
	apu_wait_till(10);
	apu_copy_data(SRC_B0, DEST_B1, 16, N, 0);
	apu_conjugate_mirror(SRC_B0, DEST_B1, N - 1, 1, N - 1);

	//---------------------------------------------------------------------
	// YS --> inverse FFT and bit shift
	apu_iFFT512_B2B(0);
	// At this point, Ys is in B0[0~255] and B1[0~255]

	//---------------------------------------------------------------------
	// NIOS 2 will compute the "pwr" variable. It is the sum of |xn[i]|
	int pwr_int = 0;
	for (i = 0; i < N; i++)
	{
		if (xn[i] > 0) pwr_int += xn[i];
		else pwr_int -= xn[i];
	}
	pwr = (float)pwr_int / (INT16_MAX * N);

	//---------------------------------------------------------------------
	// NIOS 2 needs to read yp[i], which is Ys[256~511].Real
	// yp = apu_get_data(SRC_B1, 1, 0, N);
	apu_wait_till(0); // wait for all instructions to run
	while(apu_running() == 1);
	while(apu_r_fifo_size() > 0)
	{
		yp[0] = apu_read_r_fifo();
	}
	//N is the size of the whole FIFO, get the data in two batches
	apu_get_data(SRC_B1, 1, 0, 128);
	while(apu_running() == 1);
	for(i = 0; i < 128; i++)
	{
		// while(apu_read_r_fifo() == 0);
		yp[i] = apu_read_r_fifo();
	}
	apu_get_data(SRC_B1, 1, 128, 128);
	while(apu_running() == 1);
	for(i = 128; i < 256; i++)
	{
		// while(apu_read_r_fifo() == 0);
		yp[i] = apu_read_r_fifo();
	}


	//---------------------------------------------------------------------
	// NIOS 2 will the error vector ep[i] and send it to the output
	long ep_long;
	for (i = 0; i < N; i++)
	{
		dn[i] = dn[i] << 16; //dn is now same as "dp" from this point onward

		//ep[i] = dp[i] - yp[i] :
		ep_long = dn[i] - yp[i];
		if (ep_long > INT32_MAX) ep[i] = (int)INT32_MAX;
		else if (ep_long < INT32_MIN) ep[i] = (int)INT32_MIN;
		else ep[i] = (int)ep_long;
	}

	//---------------------------------------------------------------------
	// NIOS 2 --> ep[] --> FPGA
	// Ec[0 ~ 255] = 0 --> B0
	// Ec[256 ~ 512] = ep[0 ~ 255] --> B1
	// Create Ec and do FFT
	apu_wait_till(190);
	apu_wait_till(10);
	apu_reset_memory(DEST_B0, 0, N);
	apu_reset_memory(DEST_B1, 0, N);
	apu_send_data(DEST_B1r, ep, N);

	//---------------------------------------------------------------------
	// Do FFT on Ec, and bitshift
	apu_FFT512_B2B(3);

	//---------------------------------------------------------------------
	// Store Ec[] in matrix Eb. It is a circular buffer where
	//  "Eb_offset" is the index of the 0th row.
	Eb_offset--;
	if (Eb_offset < 0) Eb_offset += EB_NUM_ROWS;

	// Store B0 -> Eb[0~255]
	apu_wait_till(190);
	apu_wait_till(10);
	apu_ssram_set_addr(Eb_base + Eb_offset * EB_NUM_COLS);
	apu_ssram_set_skip(1);
	apu_ssram_set_highest_addr(Eb_base_i - 1);
	apu_ssram_set_block_size(EB_BLOCK_SIZE - 1);
	apu_ssram_write(SRC_B0, 0, N, 0); // real
	apu_ssram_set_addr(Eb_base_i + Eb_offset * EB_NUM_COLS);
	apu_ssram_set_highest_addr(Eb_base_end);
	apu_ssram_write(SRC_B0, 1, N, 0); // imag

	// Store B1[0] -> Eb[]
	apu_ssram_set_addr(Eb_base + Eb_offset * EB_NUM_COLS + N);
	apu_ssram_set_highest_addr(Eb_base_i - 1);
	apu_ssram_write(SRC_B1, 0, 16, 0); // real
	apu_ssram_set_addr(Eb_base_i + Eb_offset * EB_NUM_COLS + N);
	apu_ssram_set_highest_addr(Eb_base_end);
	apu_ssram_write(SRC_B1, 1, 16, 0); // imag

	//---------------------------------------------------------------------
	// Compute power of freq bins
	for (k = 0; k < N + 1; k++)
	{
		// Xb[] -> A0
		apu_wait_till(210);
		apu_wait_till(10);
		apu_ssram_set_addr(Xb_base + Xb_offset * XB_NUM_COLS + k);
		apu_ssram_set_skip(XB_NUM_COLS);
		apu_ssram_set_highest_addr(Xb_base_i - 1);
		apu_ssram_set_block_size(XB_BLOCK_SIZE - XB_NUM_COLS);
		apu_ssram_read(DEST_A0r, M + nd + 4, 0); // real
		apu_ssram_set_addr(Xb_base_i + Xb_offset * XB_NUM_COLS + k);
		apu_ssram_set_highest_addr(Xb_base_end);
		apu_ssram_read(DEST_A0i, M + nd + 4, 0); // imag

		apu_compute_power(M + nd + 4, 0, k);
		// power is a single number stored at C0[k]
	}
	//Pi_int[k] is in C0 at this point

	//---------------------------------------------------------------------
	// Do the following in NIOS 2 - compute output, and compute power
	// use floating point for the power computations
	// Compute ps_c_array[i] = | dp[i]^2 - yp[i]^2 |
	// Compute pe_c_array[i] = ep[i] * ep[i];
	// Start of long NIOS 2 block

	// Output calculation, with saturation
	for (i = 0; i < N; i++)
	{
		// output[i] = ep[i] >> 16; plus rounding bit
		out[i] = ep[i] >> 15;
		out[i]++;
		out[i] = out[i] >> 1;
		if (out[i] > INT16_MAX) out[i] = INT16_MAX;
	}

	float ps_c_array[N];
	float pe_c_array[N];
	float dp_float, yp_float;
	for (i = 0; i < N; i++)
	{
		dp_float = dn[i] * apu_Fraction_F;
		yp_float = yp[i] * apu_Fraction_F;
		ps_c_array[i] = dp_float * dp_float - yp_float * yp_float;
		if (ps_c_array[i] < 0) ps_c_array[i] *= (-1);

		dp_float = ep[i] * apu_Fraction_F;
		pe_c_array[i] = dp_float * dp_float; //really ep_float ^ 2
	}

	// Step-size control
	if (p_start == 0)
	{
		p_start = 1;
	}
	else
	{
		pwr = lam_p * pwr + (1.0f - lam_p) * pwr;
	}
	for (i = 0; i < N; i++)
	{
		if (ps_c_array[i] > ps)
			ps = lam_f * ps + (1.0f - lam_f) * ps_c_array[i];
		else
			ps = lam_s * ps + (1.0f - lam_s) * ps_c_array[i];

		if (pe_c_array[i] > pe)
			pe = lam_f * pe + (1.0f - lam_f) * pe_c_array[i];
		else
			pe = lam_s * pe + (1.0f - lam_s) * pe_c_array[i];
	}

	if (index < 200)
		mu = mu1;
	else
		mu = mu2;

	// Adaptation control
	if (pwr < pwr_th)
	{
		mu_k = 0;
	}
	else
	{
		// Run initial tens frame without condition
		if (init_blk_cnt < 100)
		{
			init_blk_cnt++;
			mu_k = mu;
		}
		else
		{
			if (pe < 0.35f * ps)
			{
				mu_k = mu;
			}
			else if (pe < 0.4f * ps)
			{
				mu_k = mu / 2;
			}
			else if (pe < 0.5f * ps)
			{
				mu_k = mu / 4;
			}
			else if (pe < 0.65f * ps)
			{
				mu_k = mu / 8;
			}
			else
			{
				mu_k = 0;
			}
		}
	}

	// Weight update -NLMS
	if (Const_index < 3)
		Const_index++;
	else
		Const_index = 0;
	// End of long NIOS 2 block
	//---------------------------------------------------------------------


	for (m = 0; m < M; m++)
	{
		Xb_index = Xb_offset + m;
		if (Xb_index > XB_NUM_ROWS - 1) Xb_index = Xb_index - XB_NUM_ROWS;
		Eb_index = Eb_offset + nd;
		if (Eb_index > EB_NUM_ROWS - 1) Eb_index = Eb_index - EB_NUM_ROWS;

		//---------------------------------------------------------------------
		// Compute Rb[] from Xb[][], Eb[][], and Pi_int[]
		// The Pi_int[] is already in memory C0

		//Xb_Vec --> A0
		apu_wait_till(180);
		apu_wait_till(10);
		apu_ssram_set_addr(Xb_base + (Xb_index + nd) * XB_NUM_COLS);
		apu_ssram_set_skip(1);
		apu_ssram_set_highest_addr(Xb_base_i - 1);
		apu_ssram_set_block_size(XB_BLOCK_SIZE - 1);
		apu_ssram_read(DEST_A0r, N + 1, 0); // real
		apu_ssram_set_addr(Xb_base_i + (Xb_index + nd) * XB_NUM_COLS);
		apu_ssram_set_highest_addr(Xb_base_end);
		apu_ssram_read(DEST_A0i, N + 1, 0); // imag

		//Eb_Vec --> A1
		apu_ssram_set_addr(Eb_base + Eb_index * EB_NUM_COLS);
		apu_ssram_set_skip(1);
		apu_ssram_set_highest_addr(Eb_base_i - 1);
		apu_ssram_set_block_size(EB_BLOCK_SIZE - 1);
		apu_ssram_read(DEST_A1r, N + 1, 0); // real
		apu_ssram_set_addr(Eb_base_i + Eb_index * EB_NUM_COLS);
		apu_ssram_set_highest_addr(Eb_base_end);
		apu_ssram_read(DEST_A1i, N + 1, 0); // imag
		//-----------------------------------------------------------------------
		// Rb[] --> B0
		// B0[k] = mu_k * Complex.Conjugate(A0[k]) * A1[k] * (double)(1 &lt;&lt; Pi_int[k]);
		apu_compute_Rb(SRC_A1, DEST_B0, N + 1, 0, 0, mu_k);

		// Weight Vector Constraint Part
		if ((m == Const_index) || (m == (Const_index + 4)) || (m == (Const_index + 8)) || (m == (Const_index + 12)))
		{
			//---------------------------------------------------------------------
			// Create dW[] from Wei and Rb[]
			// Wei[] --> B1
			apu_wait_till(200);
			apu_wait_till(10);
			apu_ssram_set_addr(Wei_base + m * WEI_NUM_COLS);
			apu_ssram_set_skip(1);
			apu_ssram_set_highest_addr(Wei_base_i - 1);
			apu_ssram_set_block_size(WEI_BLOCK_SIZE - 1);
			apu_ssram_read(DEST_B1r, N + 1, 0); // real
			apu_ssram_set_addr(Wei_base_i + m * WEI_NUM_COLS);
			apu_ssram_set_highest_addr(Wei_base_end);
			apu_ssram_read(DEST_B1i, N + 1, 0); // imag

			// dW[k] = Wei[k] + Rb[k], for k = 0 to N; dW --> A0
			apu_add_array(SRC_B0, SRC_B1, 0, N + 1, DEST_A0);

			// Prepare for inverse FFT. Copy A0[N] to A1[0], one element copy
			// A1[256-k] = Complex.Conjugate(A[k]), k = 1 to N-1
			apu_copy_data(SRC_A0, DEST_A1, 16, N, 0);
			apu_conjugate_mirror(SRC_A0, DEST_A1, N - 1, 1, N - 1);

			//---------------------------------------------------------------------
			// Inverse FFT and bitshift on dW, which is mem A right now
			apu_wait_till(180);
			apu_wait_till(10);
			apu_iFFT512_A2A(0);

			// To prepare for the next FFT, A0[0~255] copy to B0[0~255], copy real part only
			// set the imaginary part to zero.
			// Then set B1[0~255] to zero completely.

			// for similarity with old code, copy from A0 to B0 for now - may not be
			// necessary
			apu_reset_memory(DEST_B0, 0, N);
			apu_copy_data(SRC_A0, DEST_B0r, N, 0, 0);
			apu_reset_memory(DEST_B1, 0, N);

			// dW now in B
			// Do FFT on dW and bitshift
			apu_wait_till(190);
			apu_wait_till(10);
			apu_FFT512_B2B(3);

			//---------------------------------------------------------------------
			// Store dW to Wei matrix
			// store B0[0:255] --> Wei[]
			apu_wait_till(190);
			apu_wait_till(10);
			apu_ssram_set_addr(Wei_base + m * WEI_NUM_COLS);
			apu_ssram_set_skip(1);
			apu_ssram_set_highest_addr(Wei_base_i - 1);
			apu_ssram_set_block_size(WEI_BLOCK_SIZE);
			apu_ssram_write(SRC_B0, 0, N, 0); // real
			apu_ssram_set_addr(Wei_base_i + m * WEI_NUM_COLS);
			apu_ssram_set_highest_addr(Wei_base_end);
			apu_ssram_write(SRC_B0, 1, N, 0); // imag

			// store B1[0] --> Wei
			apu_ssram_set_addr(Wei_base + m * WEI_NUM_COLS + N);
			apu_ssram_set_skip(1);
			apu_ssram_set_highest_addr(Wei_base_i - 1);
			apu_ssram_set_block_size(WEI_BLOCK_SIZE);
			apu_ssram_write(SRC_B1, 0, 16, 0); // real
			apu_ssram_set_addr(Wei_base_i + m * WEI_NUM_COLS + N);
			apu_ssram_set_highest_addr(Wei_base_end);
			apu_ssram_write(SRC_B1, 1, 16, 0); // imag
		}
		else
		{
			//---------------------------------------------------------------------
			// Unconstraint Part
			// Add Rb to Wei, Rb is in B0, read Wei from matrix --> A1
			apu_wait_till(180);
			apu_wait_till(10);
			apu_ssram_set_addr(Wei_base + m * WEI_NUM_COLS);
			apu_ssram_set_skip(1);
			apu_ssram_set_highest_addr(Wei_base_i - 1);
			apu_ssram_set_block_size(WEI_BLOCK_SIZE);
			apu_ssram_read(DEST_A1r, N + 1, 0); // real
			apu_ssram_set_addr(Wei_base_i + m * WEI_NUM_COLS);
			apu_ssram_set_highest_addr(Wei_base_end);
			apu_ssram_read(DEST_A1i, N + 1, 0); // imag

			apu_add_array(SRC_B0, SRC_A1, 0, N + 1, DEST_B1);
			// The updated Wei_Vec is now in B1

			// Store Wei to the Wei matrix
			apu_ssram_set_addr(Wei_base + m * WEI_NUM_COLS);
			apu_ssram_set_skip(1);
			apu_ssram_set_highest_addr(Wei_base_i - 1);
			apu_ssram_set_block_size(WEI_BLOCK_SIZE);
			apu_ssram_write(SRC_B1, 0, N + 1, 0); // real
			apu_ssram_set_addr(Wei_base_i + m * WEI_NUM_COLS);
			apu_ssram_set_highest_addr(Wei_base_end);
			apu_ssram_write(SRC_B1, 1, N + 1, 0); // imag
		}
	}
}


