/*
 * apu_test.h
 *
 *  Created on: Apr 28, 2011
 *      Author: louisy
 */

#ifndef APU_TEST_H_
#define APU_TEST_H_

// ---------- Management Functions --------------------------------------------
void empty_result_fifo();

// ---------- Test functions --------------------------------------------------

void test_send_data(); // test #1
	// PC sends data to the array processor
void test_get_data(); // test #2
	// retrieve data from array processor and sends it back to the PC
void test_copy_data(); // test #3
	// copy data from one memory to another
void test_reset_memory(); // test #4
	// reset a section of the memory buffers

void test_add_array(); // test #5
	// adds two arrays together
void test_mac(); // test #6
	// does a MAC on two arrays
void test_conjugate_mirror(); // test #7 - conjugate_mirror() instruction
void test_compute_power(); // test #8 - compute_power() instruction
void test_compute_Rb(); // test #9 - compute_Rb() instruction
void test_fft32(); // test #10 - various fft32 instructions
void test_fft512(); // test #11 - various fft512 instructions

// ---------- APU Instructions - SSRAM ----------------------------------------
void test_ssram_set_addr(); // test #12 - trigger ssram_set_addr()
void test_ssram_set_skip(); // test #13 - trigger ssram_set_skip()
void test_ssram_set_highest_addr(); // test #14 - trigger ssram_set_highest_addr()
void test_ssram_set_block_size(); // test #15 - trigger ssram_set_block_size()
void test_ssram_reset(); // test #16 - ssram_reset()
void test_ssram_write(); // test #17 - trigger ssram_write()
void test_ssram_read(); // test #18 - trigger ssram_read()

#endif /* APU_TEST_H_ */

