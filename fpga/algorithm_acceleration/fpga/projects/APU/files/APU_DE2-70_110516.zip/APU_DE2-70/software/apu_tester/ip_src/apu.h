/*
 * apu.h
 *
 *  Created on: Apr 27, 2011
 *      Author: louisy
 */

#ifndef APU_H_
#define APU_H_

typedef enum {SRC_A0=0, SRC_A1, SRC_B0, SRC_B1} SRC;
typedef enum {DEST_A0=0, DEST_A1, DEST_B0, DEST_B1, DEST_A0r, DEST_A1r, DEST_B0r,
		DEST_B1r, DEST_A0i, DEST_A1i, DEST_B0i, DEST_B1i, DEST_A0_1, DEST_B0_1,
		DEST_ALL_MEM, DEST_NONE_MEM} DEST;
typedef enum {ALU_SIMPLE_COPY=2, ALU_REAL_COPY=3, ALU_RI_SWAP=4, ALU_CONJUGATE=5,
                ROUND_SAT=6, LSHIFT16=7} ALU_COPY_MODE;
typedef enum {T_SRC_ONE=1, T_SRC_A0, T_SRC_A0_Conjugate} T_SRC;

// Fractional value inside APU = Math.Pow(2, -31);
#define apu_Fraction_F 0.0000000004656612873077392578125f;

// ---------- Status instructions ---------------------------------------------
int apu_running(); // returns 1 if the APU is running
int apu_i_fifo_size(); // returns the number of elements in the instruction FIFO
int apu_r_fifo_size(); // returns the number of elements in the result FIFO
int apu_read_r_fifo(); // returns an element from the result FIFO
void apu_wait_till(int n); // wait till instruction FIFO has "n" elements or less

// ---------- APU instructions - Memory buffer --------------------------------
void apu_send_data(DEST dest, int array[], int length); // send data to APU
void apu_get_data(SRC src, int real, int start_index, int length); //put data into result FIFO

// copy data from one memory to another:
void apu_copy_general(ALU_COPY_MODE alu_mode, SRC src, DEST dest, int length, int src_start, int dest_start);
void apu_copy_data(SRC src, DEST dest, int length, int src_start, int dest_start); // simple copy
void apu_copy_real(SRC src, DEST dest, int length, int src_start, int dest_start);
		// copy real and set imag to zero
void apu_copy_swap(SRC src, DEST dest, int length, int src_start, int dest_start);
		// swap real and imaginary part during the copy
void apu_copy_conjugate(SRC src, DEST dest, int length, int src_start, int dest_start);
		// real part copied, imaginary part * -1 and copied
void apu_copy_round(SRC src, DEST dest, int length, int src_start, int dest_start);
		// round the value to Q31 representation during the copy
void apu_copy_shift16(SRC src, DEST dest, int length, int src_start, int dest_start);
		// during the course of the copy, shift the value by 16 bits to the left

// to reset memory to zero
void apu_reset_memory(DEST dest, int dest_start, int length);

// ---------- APU Instructions - Math ------------------------------------------
// add two arrays together
void apu_add_array(SRC src1, SRC src2, int src_start, int length, DEST dest);
// perform MAC on two arrays of data and store it into dest[dest_index]
void apu_mac(SRC src, T_SRC t_src, DEST dest, int src_start, int dest_index, int length);

// copies the conjugate of one array to another array. If copying from A0 to A1, then
// A1[dest_start - k] = Complex.Conjugate(A0[src_start + k]).
// The "k" runs from 0 to length-1.
void apu_conjugate_mirror(SRC src, DEST dest, int length, int src_start, int dest_start);

// Compute the power by adding the sum of square of the real and imaginary parts,
// for the values stored in buffer A0. This is implemented as A0 times its
// conjugate. Next find the log2 of this power (but it's not quite log2 - see
// ALU section for a table showing the exact mapping). Then take 16 minus the log2 result
// and store it at C0[dest_index].
void apu_compute_power(int length, int src_start, int dest_index);

// Computes: B0[k] = mu_k * Complex.Conjugate(A0[k]) * A1[k] * (double)(1 << Pi_int[k]);
// The k will run from 0 to length-1. src should be A0 or A1. The conjugate array
// source should always be A0, because only A0 is conjugated and feeding the T input.
// dest should be "2" or "3" - the target is always memory B0 or B1.
void apu_compute_Rb(SRC src, DEST dest, int length, int src_start, int dest_start, int mu_k);

// ---------- APU Instructions - FFT ------------------------------------------
// The bit reverse length is actually the half length of the FFT. For example,
// a length 32 FFT would have 16 numbers in each array.
// The data is copied from "source" to "dest". The starting index is 0. It's like
// copy, with starting index 0, and the destination address having a bit reverse
// applied to it.
// The source is either '4' for (A1, A0) or '0xE' for (B1, B0).
void apu_bit_reverse_copy(int source, DEST dest, int length, int bit_reverse_type);

// Runs one set of FFT butterfly operations. If the source is memory A, then the
// destination is memory B. If the source is memory B, then the destination is memory A.
// The source is either '4' for (A1, A0) or '0xE' for (B1, B0).
void apu_FFT(int source, DEST dest, int length, int fft_shift,
			int read_stage_number, int write_stage_number);

// various FFT functions
void apu_FFT32_A2A(int fft_shift);
void apu_FFT32_B2B(int fft_shift);
void apu_iFFT32_A2A(int fft_shift);
void apu_iFFT32_B2B(int fft_shift);

void apu_FFT512_A2A(int fft_shift);
void apu_FFT512_B2B(int fft_shift);
void apu_iFFT512_A2A(int fft_shift);
void apu_iFFT512_B2B(int fft_shift);

// ---------- APU Instructions - SSRAM ----------------------------------------
void apu_ssram_set_addr(int n);
void apu_ssram_set_skip(int n);
void apu_ssram_set_highest_addr(int n);
void apu_ssram_set_block_size(int n);
void apu_ssram_reset(int length);
void apu_ssram_write(SRC source, int imag, int length, int source_start);
void apu_ssram_read(DEST dest, int length, int dest_start);


#endif /* APU_H_ */

