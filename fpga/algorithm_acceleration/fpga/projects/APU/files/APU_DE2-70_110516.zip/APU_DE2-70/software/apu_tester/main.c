/*
 * main.c
 *
 *  Created on: Apr 26, 2011
 *      Author: louisy
 */

#include "system.h"
#include "io.h"

#include "ip_src/rs232.h"
#include "ip_src/apu.h"
#include "ip_src/apu_test.h"
#include "ip_src/flash.h"
#include "ip_src/data_types.h"

#include "aec_src/aec.h"

void do_aec_from_flash();

int main()
{
	rs232_char_mode_reset();
	rs232_output_flush();
	rs232_set_tx_mode(0);	//send in 4 byte mode
	rs232_set_rx_mode(0);	//receive in 4 byte mode

	int command;

	while(1)
	{
		rs232_wait_for_input(4);
		command = rs232_read();

		if(command == 0) rs232_write(0);
		else if(command == 1) test_send_data();
		else if(command == 2) test_get_data();
		else if(command == 3) test_copy_data();
		else if(command == 4) test_reset_memory();
		else if(command == 5) test_add_array();
		else if(command == 6) test_mac();
		else if(command == 7) test_conjugate_mirror();
		else if(command == 8) test_compute_power();
		else if(command == 9) test_compute_Rb();
		else if(command == 10) test_fft32();
		else if(command == 11) test_fft512();
		else if(command == 12) test_ssram_set_addr();
		else if(command == 13) test_ssram_set_skip();
		else if(command == 14) test_ssram_set_highest_addr();
		else if(command == 15) test_ssram_set_block_size();
		else if(command == 16) test_ssram_reset();
		else if(command == 17) test_ssram_write();
		else if(command == 18) test_ssram_read();
		// ---------- Flash ---------------------------------------------------
		else if(command == 100) flash_test();
		// ---------- AEC -----------------------------------------------------
		else if(command == 1024) do_aec_from_flash();
	}
}

void do_aec_from_flash()
{
	int xn_address, dn_address, out_address, num_words;

	// information from PC will be input file address, echo address, expected output address,
	// file length, totaling 4*4 = 16 bytes;

	rs232_wait_for_input(4*4);

	xn_address = rs232_read(); // address are in 32 bit words
	dn_address = rs232_read();
	out_address = rs232_read();
	num_words = rs232_read(); // number of 16 bit words to handle
						// This needs to be a multiple of "N", from aec.h

	aec_init();

	int dn[N], xn[N], out[N], out_expected[N];
	int words_read = 0;
	int file_location = 0;
	TwoShorts a_word;
	int i;
	int run_time = 0;
	int max_run_time = 0;
	int num_diff = 0;
	int max_diff = 0;
	int min_diff = 0;
	int diff = 0;

	short temp1, temp2;

	do
	{
		//read data
		for(i=0; i<N/2; i++)
		{
			a_word.int_value = IORD(FLASH_MEM, xn_address + file_location);
			temp1 = a_word.short_array[0];
			temp2 = a_word.short_array[1];
			xn[2*i] = (int)temp1;
			xn[2*i+1] = (int)temp2;

			a_word.int_value = IORD(FLASH_MEM, dn_address + file_location);
			temp1 = a_word.short_array[0];
			temp2 = a_word.short_array[1];
			dn[2*i] = (int)temp1;
			dn[2*i+1] = (int)temp2;

			a_word.int_value = IORD(FLASH_MEM, out_address + file_location);
			temp1 = a_word.short_array[0];
			temp2 = a_word.short_array[1];
			out_expected[2*i] = (int)temp1;
			out_expected[2*i+1] = (int)temp2;

			file_location++;
		}

		words_read += N;

		IOWR(TIMER_0_BASE, 0, 0);
		aec(dn, xn, out);
		run_time = IORD(TIMER_0_BASE, 0);

		//gather statistics
		if(run_time > max_run_time)		max_run_time = run_time;
		for(i=0; i<N; i++)
		{
			diff = out[i] - out_expected[i];
			if(diff != 0)
			{
				num_diff++;
				if(diff > max_diff)		max_diff = diff;
				if(diff < min_diff)		min_diff = diff;
			}
		}

	}while(words_read < num_words);


	//report statistics back
	rs232_write(max_run_time);
	rs232_write(num_diff);
	rs232_write(max_diff);
	rs232_write(min_diff);
}

