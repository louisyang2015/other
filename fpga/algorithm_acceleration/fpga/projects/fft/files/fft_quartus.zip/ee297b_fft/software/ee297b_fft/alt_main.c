/*
 * alt_main.c
 *
 *  Created on: Feb 28, 2011
 *      Author: louisy
 */

#include "system.h"
#include "io.h"

#include "ip_src/rs232.h"

int alt_main(void)
{
	rs232_char_mode_reset();
	rs232_output_flush();
	rs232_set_tx_mode(0);	//send in 4 byte mode
	rs232_set_rx_mode(0);	//receive in 4 byte mode

	int command, i, val;

	while(1)
	{
		rs232_wait_for_input(4);
		command = rs232_read();

		if (command == 1)
		{
			//PC reading from memSr and memSi
			for(i=0; i<256; i++)
			{
				//make sure RS-232 output buffer has room
				while(rs232_tx_fifo_size() > 100);
				val = ALT_CI_FFT_CI_INST(3*256+i, 0); //read from memSr
				rs232_write(val);
				val = ALT_CI_FFT_CI_INST(4*256+i, 0); //read from memSi
				rs232_write(val);
			}
		}
		else if (command == 2)
		{
			//PC writing to shared memory
			for(i=0; i<256; i++)
			{
				rs232_wait_for_input(4);
				val = rs232_read();
				ALT_CI_FFT_CI_INST(1*256+i, val); //write to memSr
				rs232_wait_for_input(4);
				val = rs232_read();
				ALT_CI_FFT_CI_INST(2*256+i, val); //write to memSi
			}
		}
		else if (command == 3)
		{
			ALT_CI_FFT_CI_INST(5*256+0, 0); //do FFT
			while(ALT_CI_FFT_CI_INST(6*256+0, 0) != 0); //wait for FFT to finish
		}
		else if (command == 4)
		{
			ALT_CI_FFT_CI_INST(5*256+1, 0); //do inverse FFT
			while(ALT_CI_FFT_CI_INST(6*256+0, 0) != 0); //wait for iFFT to finish
		}
	}
}
