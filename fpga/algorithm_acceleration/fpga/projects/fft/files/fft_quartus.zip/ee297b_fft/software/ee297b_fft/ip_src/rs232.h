/*
 * rs232.h
 *
 *  Created on: Feb 28, 2011
 *      Author: louisy
 */

#ifndef RS232_H_
#define RS232_H_

#include "io.h"
#include "system.h"

#define RS232_UART RS232_0_BASE

//Get current FIFO sizes (content length)
int rs232_tx_fifo_size(); //words to be sent out
int rs232_rx_fifo_size(); //bytes that can be read

//Operating Modes
//0 = 4 byte mode; 2 = 2 byte mode; 1 = 1 byte mode
//TX mode should only be changed when output FIFO is empty
//"rs232_set_tx_mode" does not call "rs232_output_flush"
void rs232_set_tx_mode(int mode);
void rs232_set_rx_mode(int mode);

//Blocking / wait functions
void rs232_output_flush(); //wait for TX FIFO to deplete
void rs232_wait_for_input(int n); //wait for n bytes of input

//General operations
int rs232_read();
void rs232_write(int value);

//Character Mode operations
void rs232_str_print(char* str);
void rs232_print_newline();
void rs232_str_print_unsigned_int(unsigned int value);

//Initialization functions
void rs232_read_all();
void rs232_char_mode_reset();

//Testing use:
void rs232_test(); //assumes starting in char mode


#endif /* RS232_H_ */
