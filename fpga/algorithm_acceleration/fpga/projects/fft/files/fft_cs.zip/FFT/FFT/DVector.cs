﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.Numerics;

namespace FFT
{
    /// <summary>
    /// Last updated by Louis Yang on Jan 6, 2011
    /// </summary>
    class DVector
    {
        public double[] d_array;
        
        #region Constructors        
        
        /// <summary>
        /// Creates a vector of the given size and initalize all elements to zero.
        /// </summary>
        public DVector(int size)
        {
            d_array = new double[size];
            for (int i = 0; i < d_array.Length; i++)
                d_array[i] = 0;
        }

        /// <summary>
        /// Creates a vector of the given size and initalize all elements as a
        /// sequence, starting at "start_value".
        /// </summary>
        public DVector(int size, int start_value)
        {
            d_array = new double[size];
            for (int i = 0; i < d_array.Length; i++)
                d_array[i] = start_value + i;
        }

        /// <summary>
        /// Create a wrapper for a double[] array. The newly created DVector object
        /// just wraps around the d_array. No copy of the d_array is made.
        /// </summary>
        public DVector(double[] d_arary)
        {
            this.d_array = d_arary;
        }

        /// <summary>
        /// Create a new DVector identical to dv2. The data in the dv2 
        /// vector is copied into the new vector.
        /// </summary>
        public DVector(DVector dv2)
        {
            d_array = new double[dv2.Length];            
            for (int i = 0; i < d_array.Length; i++)   
                   d_array[i] = dv2[i];
        }

        /// <summary>
        /// Create a new DVector from two DVector objects.
        /// </summary>
        public DVector(DVector dv1, DVector dv2)
        {
            double[] d_array1 = dv1.d_array;
            double[] d_array2 = dv2.d_array;

            int size = d_array1.Length + d_array2.Length;
            d_array = new double[size];
            
            int start = 0;
            for (int i = 0; i < d_array1.Length; i++)
                d_array[start + i] = d_array1[i];

            start = d_array1.Length;
            for(int i = 0; i < d_array2.Length; i++)
                d_array[start + i] = d_array2[i];
        }

        /// <summary>
        /// Create a new DVector from three DVector objects.
        /// </summary>
        public DVector(DVector dv1, DVector dv2, DVector dv3)
        {
            double[] d_array1 = dv1.d_array;
            double[] d_array2 = dv2.d_array;
            double[] d_array3 = dv3.d_array;

            int size = d_array1.Length + d_array2.Length + d_array3.Length;
            d_array = new double[size];

            int start = 0;
            for (int i = 0; i < d_array1.Length; i++)
                d_array[start + i] = d_array1[i];

            start = d_array1.Length;
            for (int i = 0; i < d_array2.Length; i++)
                d_array[start + i] = d_array2[i];

            start += d_array2.Length;
            for (int i = 0; i < d_array3.Length; i++)
                d_array[start + i] = d_array3[i];
        }

        /// <summary>
        /// Factory function that returns a DVector that starts at "start",
        /// increments by "step", and ends at "end".
        /// </summary>
        public static DVector make_series(double start, double step, double end)
        {
            double size_d = (end - start) / step + 1;
            int size = (int)Math.Ceiling(size_d);

            double[] result = new double[size];
            for (int i = 0; i < size; i++)
                result[i] = start + step * i;

            return new DVector(result);
        }
        
        #endregion

        #region Utility Functions
        /// <summary>
        /// Array indexer
        /// </summary>
        public double this[int i]
        {
            get { return d_array[i]; }
            set { d_array[i] = value; }
        }

        /// <summary>
        /// Array length
        /// </summary>
        public int Length
        {
            get { return d_array.Length; }
        }

        /// <summary>
        /// This produce a column vector string than is suitable 
        /// for pasting into Excel
        /// </summary>
        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < d_array.Length; i++)
            {
                sb.Append(d_array[i].ToString());
                sb.Append("\r\n");
            }
            return sb.ToString();
        }

        /// <summary>
        /// Divided every number by the "fraction" provided and round
        /// the result to produce an integer array.
        /// </summary>
        public int[] to_int_array(double fraction)
        {
            int[] return_val = new int[d_array.Length];
            for (int i = 0; i < d_array.Length; i++)
            {
                double temp = Math.Round(d_array[i] / fraction);
                if (temp > Int32.MaxValue)
                {
                    return_val[i] = Int32.MaxValue;
                }
                else if (temp < Int32.MinValue)
                {
                    return_val[i] = Int32.MinValue;
                }
                else
                {
                    return_val[i] = (int)temp;
                }                
            }
            return return_val;
        }

        /// <summary>
        /// Divided every number by the "fraction" provided and round
        /// the result to produce an integer array. Saturate this integer
        /// array according to the limits provided.
        /// </summary>
        public int[] to_int_array(double fraction, int upper_limit, int lower_limit)
        {
            int[] return_val = to_int_array(fraction);
            for (int i = 0; i < return_val.Length; i++)
            {
                if (return_val[i] < lower_limit)
                    return_val[i] = lower_limit;
                else if (return_val[i] > upper_limit)
                    return_val[i] = upper_limit;
            }
            return return_val;
        }

        #endregion

        #region Element by Element Operations
        //Element by element + - * /
        public static DVector operator +(DVector dv1, DVector dv2)
        {
            double[] result = new double[dv1.Length];
            for (int i = 0; i < dv1.Length; i++)
                result[i] = dv1[i] + dv2[i];
            return new DVector(result);
        }
        public static DVector operator -(DVector dv1, DVector dv2)
        {
            double[] result = new double[dv1.Length];
            for (int i = 0; i < dv1.Length; i++)
                result[i] = dv1[i] - dv2[i];
            return new DVector(result);
        }
        public static DVector operator *(DVector dv1, DVector dv2)
        {
            double[] result = new double[dv1.Length];
            for (int i = 0; i < dv1.Length; i++)
                result[i] = dv1[i] * dv2[i];
            return new DVector(result);
        }
        public static DVector operator /(DVector dv1, DVector dv2)
        {
            double[] result = new double[dv1.Length];
            for (int i = 0; i < dv1.Length; i++)
                result[i] = dv1[i] / dv2[i];
            return new DVector(result);
        }

        //Multiply or divide by a constant
        public static DVector operator *(DVector dv1, double d)
        {
            double[] result = new double[dv1.Length];
            for (int i = 0; i < dv1.Length; i++)
                result[i] = dv1[i] * d;
            return new DVector(result);
        }
        public static DVector operator *(double d, DVector dv1)
        {
            double[] result = new double[dv1.Length];
            for (int i = 0; i < dv1.Length; i++)
                result[i] = dv1[i] * d;
            return new DVector(result);
        }
        public static DVector operator /(DVector dv1, double d)
        {
            double[] result = new double[dv1.Length];
            for (int i = 0; i < dv1.Length; i++)
                result[i] = dv1[i] / d;
            return new DVector(result);
        }
        #endregion

        #region Vector Operations
        /// <summary>
        /// Returns the dot product of two vectors.
        /// </summary>        
        public double dot_product(DVector dv2)
        {
            double result = 0;
            for (int i = 0; i < d_array.Length; i++)
                result += d_array[i] * dv2[i];
            return result;
        }
        /// <summary>
        /// Returns the norm of a vector.
        /// </summary>
        public double Norm
        {
            get 
            {
                double result = 0;
                for (int i = 0; i < d_array.Length; i++)
                    result += d_array[i] * d_array[i];
                return Math.Sqrt(result);
            }
        }
        #endregion

        #region Vector Shifting and Reverse
        /// <summary>
        /// Shift the elements in the vector to the left (index 0) and pad
        /// the right end of the vector with zeros.
        /// </summary>
        public DVector shift_left(int n)
        {
            double[] result = new double[d_array.Length];

            //copy: d_array[n] to result[0], and so on...
            for (int i = n; i < d_array.Length; i++)
                result[i - n] = d_array[i];

            //copy a zero to last "n" items of "result"
            for (int i = result.Length - n; i < result.Length; i++)
                result[i] = 0;

            return new DVector(result);
        }

        /// <summary>
        /// Shift the elements in the vector to the right (last indexed element) 
        /// and pad the left end of the vector with zeros.
        /// </summary>
        public DVector shift_right(int n)
        {
            double[] result = new double[d_array.Length];

            //copy a zero to first "n" items of "result"
            for (int i = 0; i < n; i++)
                result[i] = 0;

            //copy: d_array[0] to result[n], and so on...
            for (int i = n; i < result.Length; i++)
                result[i] = d_array[i - n];

            return new DVector(result);
        }

        /// <summary>
        /// Reverse the array elements
        /// </summary>
        public DVector reverse()
        {
            double[] result = new double[d_array.Length];
            for(int i = 0; i < d_array.Length; i++)
                result[d_array.Length-1-i] = d_array[i];
            return new DVector(result);
        }
        #endregion

        #region DSP Operations
        /// <summary>
        /// This function computes the convolution of arrays x and h. The
        /// return value equals x * h.
        /// </summary>        
        private double[] conv(double[] x, double[] h)
        {
            int x_length = x.Length;
            int h_length = h.Length;
            int y_length = x_length + h_length - 1;

            double[] y = new double[y_length];

            for (int n = 0; n < y.Length; n++)
            {
                //For each n, the y(n) = sum of products: x[k] h[n-k]
                //The limit on k is calculated as: -1 < n-k < h_length
                //              -1-n < -k < h_length-n
                //              1+n > k > n-h_length
                //In addition, x[k] has to exist
                int k_low = n - h_length + 1;
                if (k_low < 0) k_low = 0;

                int k_high = n;
                if (k_high >= x_length) k_high = x_length - 1;

                y[n] = 0;

                for (int k = k_low; k <= k_high; k++)
                {
                    y[n] += x[k] * h[n - k];
                }
            }

            return y;
        }

        /// <summary>
        /// Computes the convolution of the current vector with another
        /// DVector dv2. The return value is the convolution result.
        /// </summary>
        public DVector conv(DVector dv2)
        {
            double[] results = conv(this.d_array, dv2.d_array);
            return new DVector(results);
        }


        /// <summary>
        /// Computes the DTFT (Discrete Time Fourier Transform), for the
        /// "data" provided, and at the frequency values "freq" provided. 
        /// </summary>
        public static Complex[] DTFT(double[] data, double[] freq)
        {
            Complex[] H_vals = new Complex[freq.Length];

            for (int i = 0; i < H_vals.Length; i++)
            {
                //H_vals[i] = sum of {data[m] * exp(-jwm)}
                Complex num = data[0];
                for (int m = 1; m < data.Length; m++)
                {
                    Complex exp_val = new Complex(0, -1 * freq[i] * m);
                    num = num + data[m] * Complex.Exp(exp_val);
                }

                H_vals[i] = num;
            }

            return H_vals;
        }


        /// <summary>
        /// Computes the DTFT (Discrete Time Fourier Transform) at the
        /// frequency values provided. 
        /// </summary>
        public Complex[] DTFT(double[] freq)
        {
            return DVector.DTFT(d_array, freq);
        }

        #endregion
    }
}
