﻿namespace FFT
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.xn_tabPage = new System.Windows.Forms.TabPage();
            this.xn_textbox = new System.Windows.Forms.TextBox();
            this.XK_tabPage = new System.Windows.Forms.TabPage();
            this.XK_textbox = new System.Windows.Forms.TextBox();
            this.twiddle_tabPage = new System.Windows.Forms.TabPage();
            this.twiddle_textbox = new System.Windows.Forms.TextBox();
            this.Transcript_tabPage = new System.Windows.Forms.TabPage();
            this.Transcript_textbox = new System.Windows.Forms.TextBox();
            this.Nios_tabPage = new System.Windows.Forms.TabPage();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.MainMenu_menuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.squareWave_menuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.randomData_menuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.makeHexFiles_MenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripSeparator();
            this.fftTest_menuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ifftTest_menuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.readMem_menuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.Nios_textbox = new System.Windows.Forms.TextBox();
            this.tabControl1.SuspendLayout();
            this.xn_tabPage.SuspendLayout();
            this.XK_tabPage.SuspendLayout();
            this.twiddle_tabPage.SuspendLayout();
            this.Transcript_tabPage.SuspendLayout();
            this.Nios_tabPage.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.xn_tabPage);
            this.tabControl1.Controls.Add(this.XK_tabPage);
            this.tabControl1.Controls.Add(this.twiddle_tabPage);
            this.tabControl1.Controls.Add(this.Transcript_tabPage);
            this.tabControl1.Controls.Add(this.Nios_tabPage);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabControl1.Location = new System.Drawing.Point(0, 40);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(610, 405);
            this.tabControl1.TabIndex = 0;
            // 
            // xn_tabPage
            // 
            this.xn_tabPage.Controls.Add(this.xn_textbox);
            this.xn_tabPage.Location = new System.Drawing.Point(4, 38);
            this.xn_tabPage.Name = "xn_tabPage";
            this.xn_tabPage.Padding = new System.Windows.Forms.Padding(3);
            this.xn_tabPage.Size = new System.Drawing.Size(602, 363);
            this.xn_tabPage.TabIndex = 0;
            this.xn_tabPage.Text = "x[n]";
            this.xn_tabPage.UseVisualStyleBackColor = true;
            // 
            // xn_textbox
            // 
            this.xn_textbox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.xn_textbox.Location = new System.Drawing.Point(3, 3);
            this.xn_textbox.Multiline = true;
            this.xn_textbox.Name = "xn_textbox";
            this.xn_textbox.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.xn_textbox.Size = new System.Drawing.Size(596, 357);
            this.xn_textbox.TabIndex = 0;
            this.xn_textbox.WordWrap = false;
            // 
            // XK_tabPage
            // 
            this.XK_tabPage.Controls.Add(this.XK_textbox);
            this.XK_tabPage.Location = new System.Drawing.Point(4, 38);
            this.XK_tabPage.Name = "XK_tabPage";
            this.XK_tabPage.Padding = new System.Windows.Forms.Padding(3);
            this.XK_tabPage.Size = new System.Drawing.Size(602, 363);
            this.XK_tabPage.TabIndex = 1;
            this.XK_tabPage.Text = "X[K]";
            this.XK_tabPage.UseVisualStyleBackColor = true;
            // 
            // XK_textbox
            // 
            this.XK_textbox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.XK_textbox.Location = new System.Drawing.Point(3, 3);
            this.XK_textbox.Multiline = true;
            this.XK_textbox.Name = "XK_textbox";
            this.XK_textbox.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.XK_textbox.Size = new System.Drawing.Size(596, 357);
            this.XK_textbox.TabIndex = 0;
            this.XK_textbox.WordWrap = false;
            // 
            // twiddle_tabPage
            // 
            this.twiddle_tabPage.Controls.Add(this.twiddle_textbox);
            this.twiddle_tabPage.Location = new System.Drawing.Point(4, 38);
            this.twiddle_tabPage.Name = "twiddle_tabPage";
            this.twiddle_tabPage.Padding = new System.Windows.Forms.Padding(3);
            this.twiddle_tabPage.Size = new System.Drawing.Size(602, 363);
            this.twiddle_tabPage.TabIndex = 3;
            this.twiddle_tabPage.Text = "Twiddle";
            this.twiddle_tabPage.UseVisualStyleBackColor = true;
            // 
            // twiddle_textbox
            // 
            this.twiddle_textbox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.twiddle_textbox.Location = new System.Drawing.Point(3, 3);
            this.twiddle_textbox.Multiline = true;
            this.twiddle_textbox.Name = "twiddle_textbox";
            this.twiddle_textbox.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.twiddle_textbox.Size = new System.Drawing.Size(596, 357);
            this.twiddle_textbox.TabIndex = 0;
            this.twiddle_textbox.WordWrap = false;
            // 
            // Transcript_tabPage
            // 
            this.Transcript_tabPage.Controls.Add(this.Transcript_textbox);
            this.Transcript_tabPage.Location = new System.Drawing.Point(4, 38);
            this.Transcript_tabPage.Name = "Transcript_tabPage";
            this.Transcript_tabPage.Padding = new System.Windows.Forms.Padding(3);
            this.Transcript_tabPage.Size = new System.Drawing.Size(602, 363);
            this.Transcript_tabPage.TabIndex = 4;
            this.Transcript_tabPage.Text = "Transcript";
            this.Transcript_tabPage.UseVisualStyleBackColor = true;
            // 
            // Transcript_textbox
            // 
            this.Transcript_textbox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Transcript_textbox.Location = new System.Drawing.Point(3, 3);
            this.Transcript_textbox.Multiline = true;
            this.Transcript_textbox.Name = "Transcript_textbox";
            this.Transcript_textbox.Size = new System.Drawing.Size(596, 357);
            this.Transcript_textbox.TabIndex = 0;
            this.Transcript_textbox.WordWrap = false;
            // 
            // Nios_tabPage
            // 
            this.Nios_tabPage.Controls.Add(this.Nios_textbox);
            this.Nios_tabPage.Location = new System.Drawing.Point(4, 38);
            this.Nios_tabPage.Name = "Nios_tabPage";
            this.Nios_tabPage.Padding = new System.Windows.Forms.Padding(3);
            this.Nios_tabPage.Size = new System.Drawing.Size(602, 363);
            this.Nios_tabPage.TabIndex = 2;
            this.Nios_tabPage.Text = "NIOS 2";
            this.Nios_tabPage.UseVisualStyleBackColor = true;
            // 
            // menuStrip1
            // 
            this.menuStrip1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MainMenu_menuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(610, 40);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // MainMenu_menuItem
            // 
            this.MainMenu_menuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.squareWave_menuItem,
            this.randomData_menuItem,
            this.makeHexFiles_MenuItem,
            this.toolStripMenuItem2,
            this.readMem_menuItem,
            this.fftTest_menuItem,
            this.ifftTest_menuItem});
            this.MainMenu_menuItem.Name = "MainMenu_menuItem";
            this.MainMenu_menuItem.Size = new System.Drawing.Size(90, 36);
            this.MainMenu_menuItem.Text = "&Menu";
            // 
            // squareWave_menuItem
            // 
            this.squareWave_menuItem.Name = "squareWave_menuItem";
            this.squareWave_menuItem.Size = new System.Drawing.Size(322, 36);
            this.squareWave_menuItem.Text = "&Square Wave";
            this.squareWave_menuItem.Click += new System.EventHandler(this.squareWave_menuItem_Click);
            // 
            // randomData_menuItem
            // 
            this.randomData_menuItem.Name = "randomData_menuItem";
            this.randomData_menuItem.Size = new System.Drawing.Size(322, 36);
            this.randomData_menuItem.Text = "&Random Data";
            this.randomData_menuItem.Click += new System.EventHandler(this.randomData_menuItem_Click);
            // 
            // makeHexFiles_MenuItem
            // 
            this.makeHexFiles_MenuItem.Name = "makeHexFiles_MenuItem";
            this.makeHexFiles_MenuItem.Size = new System.Drawing.Size(322, 36);
            this.makeHexFiles_MenuItem.Text = "Make &Hex Files";
            this.makeHexFiles_MenuItem.Click += new System.EventHandler(this.makeHexFiles_MenuItem_Click);
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(319, 6);
            // 
            // fftTest_menuItem
            // 
            this.fftTest_menuItem.Name = "fftTest_menuItem";
            this.fftTest_menuItem.Size = new System.Drawing.Size(322, 36);
            this.fftTest_menuItem.Text = "NIOS2 &FFT Test";
            this.fftTest_menuItem.Click += new System.EventHandler(this.fftTest_menuItem_Click);
            // 
            // ifftTest_menuItem
            // 
            this.ifftTest_menuItem.Name = "ifftTest_menuItem";
            this.ifftTest_menuItem.Size = new System.Drawing.Size(322, 36);
            this.ifftTest_menuItem.Text = "NIOS2 &iFFT Test";
            this.ifftTest_menuItem.Click += new System.EventHandler(this.ifftTest_menuItem_Click);
            // 
            // readMem_menuItem
            // 
            this.readMem_menuItem.Name = "readMem_menuItem";
            this.readMem_menuItem.Size = new System.Drawing.Size(322, 36);
            this.readMem_menuItem.Text = "NIOS 2 &Read Memory";
            this.readMem_menuItem.Click += new System.EventHandler(this.readMem_menuItem_Click);
            // 
            // Nios_textbox
            // 
            this.Nios_textbox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Nios_textbox.Location = new System.Drawing.Point(3, 3);
            this.Nios_textbox.Multiline = true;
            this.Nios_textbox.Name = "Nios_textbox";
            this.Nios_textbox.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.Nios_textbox.Size = new System.Drawing.Size(596, 357);
            this.Nios_textbox.TabIndex = 0;
            this.Nios_textbox.WordWrap = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(610, 445);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "FFT";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.tabControl1.ResumeLayout(false);
            this.xn_tabPage.ResumeLayout(false);
            this.xn_tabPage.PerformLayout();
            this.XK_tabPage.ResumeLayout(false);
            this.XK_tabPage.PerformLayout();
            this.twiddle_tabPage.ResumeLayout(false);
            this.twiddle_tabPage.PerformLayout();
            this.Transcript_tabPage.ResumeLayout(false);
            this.Transcript_tabPage.PerformLayout();
            this.Nios_tabPage.ResumeLayout(false);
            this.Nios_tabPage.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage xn_tabPage;
        private System.Windows.Forms.TabPage XK_tabPage;
        private System.Windows.Forms.TabPage twiddle_tabPage;
        private System.Windows.Forms.TabPage Nios_tabPage;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.TextBox xn_textbox;
        private System.Windows.Forms.TextBox XK_textbox;
        private System.Windows.Forms.TextBox twiddle_textbox;
        private System.Windows.Forms.ToolStripMenuItem MainMenu_menuItem;
        private System.Windows.Forms.ToolStripMenuItem squareWave_menuItem;
        private System.Windows.Forms.ToolStripMenuItem randomData_menuItem;
        private System.Windows.Forms.ToolStripMenuItem makeHexFiles_MenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem fftTest_menuItem;
        private System.Windows.Forms.ToolStripMenuItem ifftTest_menuItem;
        private System.Windows.Forms.TabPage Transcript_tabPage;
        private System.Windows.Forms.TextBox Transcript_textbox;
        private System.Windows.Forms.ToolStripMenuItem readMem_menuItem;
        private System.Windows.Forms.TextBox Nios_textbox;
    }
}

