﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.Numerics;

namespace FFT
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private CVector xn;
        private CVector XK;
        private Complex[] twiddle;
        private MyRS232 serial_port;
        

        #region Data Generation Functions

        /// <summary>
        /// The FFT size is constant in this application. So when the form
        /// loads, initialize the twiddle factor variable, and display it in
        /// the twiddle factor textbox.
        /// </summary>
        private void Form1_Load(object sender, EventArgs e)
        {
            int N = 256;
            twiddle = new Complex[N / 2];
            twiddle[0] = 1;
            for (int n = 1; n < twiddle.Length; n++)
            {
                double exponent = -2 * Math.PI / N * n;
                twiddle[n] = Complex.Exp(new Complex(0, exponent));
            }
            twiddle_textbox.Text = get_twiddle_factor_string();
            serial_port = new MyRS232();
        }

        /// <summary>
        /// Creates a basic square wave x[n], with 64 ones,
        /// 64 zeros, 64 ones, and finally 64 zeros.
        /// </summary>
        private void squareWave_menuItem_Click(object sender, EventArgs e)
        {
            Complex[] c_array = new Complex[256];                        
            for (int i = 0; i < 64; i++) c_array[i] = 1;
            for (int i = 64; i < 128; i++) c_array[i] = 0;
            for (int i = 128; i < 192; i++) c_array[i] = 1;
            for (int i = 192; i < 256; i++) c_array[i] = 0;                         
            xn = new CVector(c_array);

            run_fft();
        }

        /// <summary>
        /// Creates a random x[n] that is uniformly distributed
        /// between -1 to 1, for both real and imaginary numbers.
        /// This is done by creating a random integer from -255 to +255, 
        /// and then dividing by 256.
        /// </summary>
        private void randomData_menuItem_Click(object sender, EventArgs e)
        {
            Random rand = new Random();
            Complex[] c_array = new Complex[256];
            for (int i = 0; i < c_array.Length; i++)
                c_array[i] = new Complex(rand.Next(-255, 255) / (double)256, rand.Next(-255, 255) / (double)256);
            xn = new CVector(c_array);
            run_fft();
        }

        /// <summary>
        /// Runs FFT on "xn" and fills up the text boxes.
        /// </summary>
        private void run_fft()
        {
            if (xn.Length <= 256)
            {
                //create a transcript if xn is short
                Complex[] fft_out = new Complex[xn.Length];
                for (int i = 0; i < fft_out.Length; i++)
                    fft_out[i] = xn[i];
                Complex[,] butterfly_in, butterfly_out;
                CVector.FFT_transcript(fft_out, out butterfly_in, out butterfly_out);
                XK = new CVector(fft_out);
                xn_textbox.Text = print_complex_array(xn.c_array);
                XK_textbox.Text = print_complex_array(XK.c_array);
                //transcript format is meant for pasting into Excel and 
                //arranged for comparison with ModelSim waveforms
                StringBuilder sb = new StringBuilder();
                sb.Append("index\t\t1\t2\t3\t4\t5\t6\t7\t8\r\n");
                for (int i = 0; i < butterfly_in.GetLength(1); i = i + 2)
                {
                    /*the format for each "i":
                     * row 0: butter_fly_in[i].re
                     * row 1: butter_fly_in[i].imag
                     * row 2: butter_fly_in[i+1].re
                     * row 3: butter_fly_in[i+1].imag
                     * row 4: butter_fly_out[i].re
                     * row 5: butter_fly_out[i].imag
                     * row 6: butter_fly_out[i+1].re
                     * row 7: butter_fly_out[i+1].imag
                     * and one column for each stage
                    */
                    for (int row = 0; row < 8; row++)
                    {
                        //print butterfly pair value for the first and fourth row
                        if (row == 0)       sb.Append(i / 2 + " in\t");
                        else if (row == 4)  sb.Append(i / 2 + " out\t");
                        else                sb.Append("\t");
                        //print "real" or "imag" for the current row
                        if (row % 2 == 0)   sb.Append("real\t");
                        else                sb.Append("imag\t");

                        int num_stages = butterfly_in.GetLength(0);
                        for (int stage = 0; stage < num_stages; stage++)
                        {
                            int value = 0;
                            if (row == 0) value = double_to_int(butterfly_in[stage, i].Real);
                            else if (row == 1) value = double_to_int(butterfly_in[stage, i].Imaginary);
                            else if (row == 2) value = double_to_int(butterfly_in[stage, i + 1].Real);
                            else if (row == 3) value = double_to_int(butterfly_in[stage, i + 1].Imaginary);
                            else if (row == 4) value = double_to_int(butterfly_out[stage, i].Real);
                            else if (row == 5) value = double_to_int(butterfly_out[stage, i].Imaginary);
                            else if (row == 6) value = double_to_int(butterfly_out[stage, i + 1].Real);
                            else if (row == 7) value = double_to_int(butterfly_out[stage, i + 1].Imaginary);
                            sb.Append(value + "\t");
                        }
                        sb.Append("\r\n");
                    }
                }
                Transcript_textbox.Text = sb.ToString();
            }
            else
            {
                XK = xn.FFT();
                xn_textbox.Text = print_complex_array(xn.c_array);
                XK_textbox.Text = print_complex_array(XK.c_array);
            }
        }

        /// <summary>
        /// Prints the array of Complex values in a manner that includes
        /// both the double representation and the integer representation.
        /// The string is tab delimited for pasting into Excel.
        /// </summary>
        private string print_complex_array(Complex[] c_array)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("index\treal\timag\t\t|\t\treal\timag\r\n");
            for (int i = 0; i < c_array.Length; i++)
            {
                sb.Append(i + "\t" + c_array[i].Real.ToString("G6"));
                sb.Append("\t" + c_array[i].Imaginary.ToString("G6"));
                sb.Append("\t\t|\t\t");
                sb.Append(double_to_int(c_array[i].Real) + "\t");
                sb.Append(double_to_int(c_array[i].Imaginary) + "\r\n");
            }
            return sb.ToString();
        }

        /// <summary>
        /// Routine for converting from "double" to an "int" used by
        /// the entire FFT application (other than the twiddle factor). 
        /// So editing this one function 
        /// should be sufficient to deal with different fixed point
        /// conversion formats.
        /// </summary>
        private int double_to_int(double val)
        {
            double fraction = Math.Pow(2, -24);
            double int_val_d = val / fraction;
            if (int_val_d > Int32.MaxValue) return Int32.MaxValue;
            if (int_val_d < (Int32.MinValue + 1)) return Int32.MinValue + 1;
            return (int)Math.Round(int_val_d);
        }

        /// <summary>
        /// Routine for converting from "double" to an "int" used by
        /// the twiddle factor display routine "get_twiddle_factor_string()",
        /// and when producing a hex file for the twiddle factor.
        /// </summary>
        private int double_to_int_twiddle(double val)
        {
            double fraction = Math.Pow(2, -31);
            double int_val_d = val / fraction;
            if (int_val_d > Int32.MaxValue) return Int32.MaxValue;
            if (int_val_d < (Int32.MinValue + 1)) return Int32.MinValue + 1;
            return (int)Math.Round(int_val_d);
        }

        /// <summary>
        /// Returns a string representation of the twiddle factor for
        /// display in a textbox.
        /// </summary>
        private string get_twiddle_factor_string()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("index\treal\timag\t\t|\t\treal\timag\r\n");
            for (int i = 0; i < twiddle.Length; i++)
            {
                sb.Append(i + "\t" + twiddle[i].Real.ToString("G6"));
                sb.Append("\t" + twiddle[i].Imaginary.ToString("G6"));
                sb.Append("\t\t|\t\t");
                sb.Append(double_to_int_twiddle(twiddle[i].Real) + "\t");
                sb.Append(double_to_int_twiddle(twiddle[i].Imaginary) + "\r\n");
            }
            return sb.ToString();
        }

        /// <summary>
        /// Creates hex files for the x[n], X[k], and twiddle factors.
        /// </summary>
        private void makeHexFiles_MenuItem_Click(object sender, EventArgs e)
        {
            if (xn == null) return;
            if (XK == null) return;
            this.Cursor = Cursors.WaitCursor;
            make_hex_file_32bit(xn.c_array, "xn_real.hex", "xn_imag.hex");
            make_hex_file_32bit(XK.c_array, "XK_real.hex", "XK_imag.hex");
            make_hex_file_32bit_twiddle(twiddle, "twiddle_re.hex", "twiddle_im.hex");
            make_hex_file_64bit(twiddle, "twiddle.hex");
            this.Cursor = Cursors.Default;
        }

        /// <summary>
        /// Creates a hex file drawing the data from a Complex array. 
        /// The real part goes into one file, and the imaginary part goes
        /// into another file. This function uses the "double_to_int" for
        /// double to integer conversion.
        /// </summary>
        private void make_hex_file_32bit(Complex[] c_array, string real_file_name,
                    string imag_file_name)
        {
            int[] re = new int[c_array.Length];
            int[] im = new int[c_array.Length];
            for (int i = 0; i < re.Length; i++)
            {
                re[i] = double_to_int(c_array[i].Real);
                im[i] = double_to_int(c_array[i].Imaginary);
            }
            Hex_File h = new Hex_File(re);
            h.write_to(real_file_name);
            h = new Hex_File(im);
            h.write_to(imag_file_name);
        }

        /// <summary>
        /// This is a variant of the "make_hex_file_32bit" function. 
        /// The difference is that this function uses the 
        /// "double_to_int_twiddle" for double to integer conversion. It's
        /// meant for encoding the twiddle factor.
        /// </summary>
        private void make_hex_file_32bit_twiddle(Complex[] c_array, string real_file_name,
                    string imag_file_name)
        {
            int[] re = new int[c_array.Length];
            int[] im = new int[c_array.Length];
            for (int i = 0; i < re.Length; i++)
            {
                re[i] = double_to_int_twiddle(c_array[i].Real);
                im[i] = double_to_int_twiddle(c_array[i].Imaginary);
            }
            Hex_File h = new Hex_File(re);
            h.write_to(real_file_name);
            h = new Hex_File(im);
            h.write_to(imag_file_name);
        }

        /// <summary>
        /// Creates a hex file drawing the data from a Complex array. 
        /// Both real and imaginary parts go into the same file where the 
        /// data is 64 bit wide. The upper 32 bits is the real part, the
        /// lower 64 bit is the imaginary part. The conversion function used
        /// is "double_to_int_twiddle()" because the 64 bit format is for the
        /// twiddle factor.
        /// </summary>
        private void make_hex_file_64bit(Complex[] c_array, string file_name)
        {
            int[] data = new int[c_array.Length * 2];
            for (int i = 0; i < c_array.Length; i++)
            {
                data[2 * i] = double_to_int_twiddle(c_array[i].Real);
                data[2 * i + 1] = double_to_int_twiddle(c_array[i].Imaginary);
            }
            Hex_File h = new Hex_File(data);
            h.write_to64(file_name);
        }

        #endregion
        
        #region NIOS 2 Testing
        /// <summary>
        /// Read the shared memory content from the board and display it.
        /// </summary>
        private void readMem_menuItem_Click(object sender, EventArgs e)
        {
            serial_port.serial_port.ReadExisting();
            int[] real, imag;
            bool response = read_shared_mem(out real, out imag, 256, 2000);
            if (response == false)
                Nios_textbox.Text = "No response to read test";
            else
                Nios_textbox.Text = format_mem_output(real, imag);
        }

        /// <summary>
        /// Send the current "xn" to the board and have it compute the FFT.
        /// Print the FFT result and how it differs from the ideal values.
        /// </summary>
        private void fftTest_menuItem_Click(object sender, EventArgs e)
        {
            if (xn == null) return;
            this.Cursor = Cursors.WaitCursor;
            
            double[] real_d = xn.Real;
            double[] imag_d = xn.Imaginary;
            int[] real = new int[xn.Length];
            int[] imag = new int[xn.Length];
            for (int i = 0; i < xn.Length; i++)
            {
                real[i] = double_to_int(real_d[i]);
                imag[i] = double_to_int(imag_d[i]);
            }
            write_shared_mem(real, imag);
            serial_port.write_integer(3); //code to do FFT
            System.Threading.Thread.Sleep(1000);
            bool response = read_shared_mem(out real, out imag, real.Length, 2000);
            if (response == false)
                Nios_textbox.Text = "No response to read test";
            else
            {
                real_d = XK.Real;
                imag_d = XK.Imaginary;
                int[] exp_real = new int[real_d.Length];
                int[] exp_imag = new int[imag_d.Length];
                for (int i = 0; i < real_d.Length; i++)
                {
                    exp_real[i] = double_to_int(real_d[i]);
                    exp_imag[i] = double_to_int(imag_d[i]);
                }

                Nios_textbox.Text = format_difference_output(real, imag, exp_real, exp_imag);
            }
            
            this.Cursor = Cursors.Default;
        }

        /// <summary>
        /// Send the current "XK" to the board and have it compute the FFT.
        /// Print the FFT result and how it differs from the ideal values.
        /// </summary>
        private void ifftTest_menuItem_Click(object sender, EventArgs e)
        {
            if (XK == null) return;
            this.Cursor = Cursors.WaitCursor;

            double[] real_d = XK.Real;
            double[] imag_d = XK.Imaginary;
            int[] real = new int[xn.Length];
            int[] imag = new int[xn.Length];
            for (int i = 0; i < xn.Length; i++)
            {
                real[i] = double_to_int(real_d[i]);
                imag[i] = double_to_int(imag_d[i]);
            }
            write_shared_mem(real, imag);
            serial_port.write_integer(4); //code to do inverse FFT
            System.Threading.Thread.Sleep(1000);
            bool response = read_shared_mem(out real, out imag, real.Length, 2000);
            if (response == false)
                Nios_textbox.Text = "No response to read test";
            else
            {
                real_d = xn.Real;
                imag_d = xn.Imaginary;
                int[] exp_real = new int[real_d.Length];
                int[] exp_imag = new int[imag_d.Length];
                for (int i = 0; i < real_d.Length; i++)
                {
                    exp_real[i] = double_to_int(real_d[i]);
                    exp_imag[i] = double_to_int(imag_d[i]);
                }

                Nios_textbox.Text = format_difference_output(real, imag, exp_real, exp_imag);
            }

            this.Cursor = Cursors.Default;
        }

        /// <summary>
        /// This test sends a 1 to the serial port. The board will then
        /// return with 256*2 integers, in the order: memSr[0], memSi[0],
        /// memSr[1], memSi[1], memSr[2], memSi[2], etc. The memSr values
        /// go into the "real" array and the memSi values go into the
        /// "imag" array. The length is the length of just the "real" arrray.
        /// The "time_out" is in milliseconds.
        /// </summary>
        private bool read_shared_mem(out int[] real, out int[] imag, int length, int time_out)
        {
            serial_port.serial_port.ReadExisting();
            serial_port.write_integer(1);
            bool response = serial_port.wait_for_bytes(length * 2 * 4, time_out);
            if (response)
            {
                real = new int[length];
                imag = new int[length];
                for (int i = 0; i < length; i++)
                {
                    int val;
                    response = serial_port.read_integer(out val);
                    if (response) real[i] = val;
                    else break;
                    response = serial_port.read_integer(out val);
                    if (response) imag[i] = val;
                    else break;
                }
            }
            else
            {
                real = null;
                imag = null;
            }
            return response;
        }

        /// <summary>
        /// This test sends a 2 to the serial port. Then it will send
        /// 256 real, imaginary pairs, in the following order: real[0],
        /// imag[0], real[1], imag[1], ... real[255], imag[255]. The 
        /// board will store these values into memSr and memSi.
        /// </summary>
        private void write_shared_mem(int[] real, int[] imag)
        {
            serial_port.write_integer(2);
            for (int i = 0; i < real.Length; i++)
            {
                serial_port.write_integer(real[i]);
                serial_port.write_integer(imag[i]);
            }
        }

        /// <summary>
        /// Formats an array of real values and an array of imaginary values
        /// for output in an format meant for Excel. One column is the
        /// real value and a second column is the imaginary value.
        /// </summary>
        private string format_mem_output(int[] real, int[] imag)
        {
            if (real == null) return "";
            if (imag == null) return "";
            StringBuilder sb = new StringBuilder();
            sb.Append("MemSr\tMemSi\r\n");
            for (int i = 0; i < 256; i++)
                sb.Append(real[i] + "\t" + imag[i] + "\r\n");

            return sb.ToString();
        }

        /// <summary>
        /// Compares the "real" and "imag" arrays to the "exp_real" and "exp_imag" 
        /// arrays. Print out the result in a tab delimitd table format 
        /// suitable for pasting into Excel.
        /// </summary>        
        private string format_difference_output(int[] real, int[] imag, int[] exp_real, int[] exp_imag)
        {
            if (real == null) return "";
            if (imag == null) return "";
            if (exp_real == null) return "";
            if (exp_imag == null) return "";

            int max_diff_re = 0;
            int min_diff_re = 0;
            int max_diff_im = 0;
            int min_diff_im = 0;
            StringBuilder sb = new StringBuilder();
            sb.Append("Real\tImag\tExpected Real\tExpected Imag\tReal Diff\tImag Diff\r\n");
            for (int i = 0; i < real.Length; i++)
            {
                int diff_re = real[i] - exp_real[i];
                int diff_im = imag[i] - exp_imag[i];
                sb.Append(real[i] + "\t" + imag[i] + "\t" + exp_real[i] + "\t");
                sb.Append(exp_imag[i] + "\t" + diff_re + "\t" + diff_im + "\r\n");
                if (diff_re > max_diff_re) max_diff_re = diff_re;
                if (diff_re < min_diff_re) min_diff_re = diff_re;
                if (diff_im > max_diff_im) max_diff_im = diff_im;
                if (diff_im < min_diff_im) min_diff_im = diff_im;
            }
            sb.Append("\r\n");
            sb.Append("\tMax Diff\tMin Diff\r\n");
            sb.Append("Real\t" + max_diff_re + "\t" + min_diff_re + "\r\n");
            sb.Append("Imag\t" + max_diff_im + "\t" + min_diff_im + "\r\n");
            return sb.ToString();
        }
        #endregion 
     


    }
}
